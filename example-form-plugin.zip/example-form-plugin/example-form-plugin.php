<?php
/*
Plugin Name: My Contact Form Plugin
Plugin URI: http://example.com
Description: My first plugin demo. Use shortcut code [my_cf_form]
Version: 1.0
Author: Dheeraj Singh
Author URI: http://w3guy.com
Text Domain: my-basics-plugin
*/

function html_form_code_new() {?>
<form action="<?php esc_url( $_SERVER['REQUEST_URI'] ) ?> " method="post" class="php-email-form">
    <div class="row gy-4">
        <div class="col-md-6">
            <input class="form-control" type="text" placeholder="Your Name" 
            name="cf-name" pattern="[a-zA-Z0-9 ]+" 
            value="<?php echo isset($_POST["cf-name"]) ? esc_attr($_POST["cf-name"]) : ''; ?>" size="40" />

        </div>
        <div class="col-md-6">
            <input class="form-control" type="email" placeholder="Your Email" name="cf-email" value="<?php (isset( $_POST["cf-email"] ) ? esc_attr( $_POST["cf-email"] ) : '' ) ?> " size="40" />
        </div>
        <div class="col-md-12">
            <input class="form-control" type="text" placeholder="Subject"  
            name="cf-subject" pattern="[a-zA-Z ]+" 
            value="<?php echo isset($_POST["cf-subject"]) ? esc_attr($_POST["cf-subject"]) : ''; ?>" 
       size="40" />
        </div>
        <div class="col-md-12">
            <textarea class="form-control" rows="6" cols="35" name="cf-message" placeholder="Message"><?php echo isset($_POST["cf-message"]) ? esc_attr($_POST["cf-message"]) : '';?></textarea>
        </div>
        <div class="col-md-12 text-center">
            <input type="submit" name="cf-submitted" value="Send Message"  class="btn btn-default btn-block btn-primary mx-auto">
            <div class="error-message"></div>
        </div>
    </div>
</form>

<?php
}

function deliver_mail_new() {

    // if the submit button is clicked, send the email
    if ( isset( $_POST['cf-submitted'] ) ) {

        // sanitize form values
        $name    = sanitize_text_field( $_POST["cf-name"] );
        $email   = sanitize_email( $_POST["cf-email"] );
        $subject = sanitize_text_field( $_POST["cf-subject"] );
        $message = esc_textarea( $_POST["cf-message"] );

        // get the blog administrator's email address
        $to =get_option('admin_email');

        $headers = "From: $name <$email>" . "\r\n";
            
            //wp_mail( $to, $subject, $message, $headers );
        // If email has been process for sending, display a success message
        if (mail( $to, $subject, $message, $headers ) ) {?>
            <div class="row gy-4">
                <div class="col-md-12 text-center">
                      <div class="sent-message">Your message has been sent. Thank you!
                      </div>
                </div>
            <div>
        <?php } else {?>
         <div class="row gy-4">
                <div class="col-md-12 text-center">
                      <div class="sent-message">Opps!! An unexpected error occurred!
                      </div>
                </div>
            <div>
        <?php }
    }
}
function cf_shortcode_new() {
    ob_start();
    deliver_mail_new();
    html_form_code_new();
    return ob_get_clean();
}

add_shortcode( 'my_cf_form', 'cf_shortcode_new' );
?>