<?php get_header(); 
$con_banner_repeater=get_field('demo_banner_repeater');
?>
<!-- Bnner Section -->
 <?php if($con_banner_repeater){ ?>
    <section class="banner-section-two">
        <div class="banner-carousel owl-carousel owl-theme">
            <!-- Slide Item banner -->
            <?php 
                foreach($con_banner_repeater as $con_banner_rptr){
                    $con_banner_img=$con_banner_rptr['demo_banner_image'];
                    $con_banner_small_title=$con_banner_rptr['demo_banner_small_title'];
                    $con_banner_main_title=$con_banner_rptr['demo_banner_main_title'];
                    $con_banner_video_link=$con_banner_rptr['demo_banner_video_link'];
                    if($con_banner_img){
                    ?>
                    <div class="slide-item" style="background-image: url(<?php echo $con_banner_img;?>);">
                        <div class="auto-container">
                            <div class="content-box">
                                <?php if($con_banner_small_title){?>
                                    <span class="title"><?php echo $con_banner_small_title; ?></span>
                                    <?php } ?>
                                    <?php if($con_banner_main_title){?>
                                    <h2><?php echo $con_banner_main_title; ?></h2>
                                    <?php }
                                    if($con_banner_video_link){?>
                                    <div class="video-link">
                                        <a href="<?php echo $con_banner_video_link; ?>" data-fancybox="gallery" data-caption=""><i class="icon fa fa-play" aria-hidden="true"></i></a>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
            <?php }
            }?>
        </div>
    </section>
    <?php } ?>
    <!-- End Bnner Section -->

    <!-- Specialize Section -->
     <?php $con_services_relationship = get_field('demo_services_relathionship');
     $con_services_bg_title=get_field('demo_services_bg_title');
     $con_services_front_title=get_field('demo_services_front_title');
     if($con_services_relationship){
     ?>
    <section class="specialize-section">
        <div class="auto-container">
            <?php if($con_services_bg_title || $con_services_front_title){ ?>
            <div class="sec-title">
                <?php if($con_services_bg_title) { ?>
                <span class="float-text"><?php echo $con_services_bg_title; ?></span>
                <?php } if($con_services_front_title){ ?>
                <h2><?php echo $con_services_front_title; ?></h2>
                <?php } ?>
            </div>
            <?php } ?>
            <div class="services-carousel-two owl-carousel owl-theme">
                <?php foreach ($con_services_relationship as $post) {
                setup_postdata($post);
                $service_title = get_the_title();
                $service_link = get_permalink();
                $service_image = get_the_post_thumbnail_url(get_the_ID($post), 'full'); // Or any custom size
            ?>
                <!-- Service Block -->
                <div class="service-block-two">
                    <div class="inner-box">
                        <?php if($service_image){?>
                        <div class="image-box">
                            <figure class="image">
                                 <a href="<?php echo esc_url($service_link); ?>">
                                    <img src="<?php echo esc_url($service_image); ?>" alt="<?php echo esc_attr($service_title); ?>">
                                </a>
                            </figure>
                        </div>
                        <div class="caption-box">
                            <h3><a href="<?php echo esc_url($service_link); ?>"><?php echo esc_html($service_title); ?></a></h3>
                            <div class="link-box">
                                <a href="<?php echo esc_url($service_link); ?>">Read More <i class="fa fa-angle-double-right"></i></a>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <?php } wp_reset_postdata(); ?>
            </div>
        </div>
    </section>
    <?php } ?>
    <!-- End Specialize Section -->

    <!-- Fun Fact And Features -->
     <?php 
     $con_counter_section_bg_img=get_field("demo_counter_section_bg_img");
     ?>
    <section class="fun-fact-and-features"  style="background-image: url(<?php echo $con_counter_section_bg_img; ?>);">
        <div class="outer-box">
            <div class="auto-container">
                <?php
                $con_counter_section_repeater=get_field("demo_counter_section_repeater");
                
                if($con_counter_section_repeater){
                ?>
                <!-- Fact Counter -->
                <div class="fact-counter">
                    <div class="row">
                        <!--Column-->
                        <?php foreach($con_counter_section_repeater as $con_counter_section_rptr){
                        $con_counter_num=$con_counter_section_rptr["demo_counter_number"];
                        $con_counter_title=$con_counter_section_rptr["demo_counter_title"];
                        ?>
                        <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                            <div class="count-box">
                                <?php if($con_counter_num){ ?>
                                <div class="count"><span class="count-text" data-speed="5000" data-stop="<?php echo $con_counter_num; ?>"><?php echo $con_counter_num; ?></span></div>
                                <?php } 
                                if($con_counter_title){?>
                                <h4 class="counter-title"><?php echo $con_counter_title; ?></h4>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <?php } ?>
                <!-- Features -->
                <?php
                 $con_iconbox_repeater=get_field('demo_service_icon_box_repeater');
                 if($con_iconbox_repeater){
                 ?>
                <div class="features">
                    <div class="row">
                        <!-- Feature Block -->
                         <?php foreach($con_iconbox_repeater as $con_iconbox_rptr){
                            $con_iconbox_img=$con_iconbox_rptr['demo_service_iconbox_img'];
                            $con_iconbox_title=$con_iconbox_rptr['demo_service_iconbox_title'];
                            $con_iconbox_short_desc=$con_iconbox_rptr['demo_servic_iconbox_short_desc'];
                            $con_iconbox_btn_link=$con_iconbox_rptr['demo_service_iconbox_btn_link'];
                            if($con_iconbox_img){
                             ?>
                        <div class="feature-block col-lg-4 col-md-6 col-sm-12">
                            <div class="inner-box">
                                <div class="icon-box"><span class="icon flaticon-decorating"></span> <img src="<?php echo $con_iconbox_img;?>" /></div>
                                <?php if($con_iconbox_title){?>
                                <h3><a href="service-detail.html"><?php echo $con_iconbox_title; ?></a></h3>
                                <?php } 
                                if($con_iconbox_short_desc){?>
                                <div class="text"><?php echo $con_iconbox_short_desc; ?></div>
                                <?php } 
                                if($con_iconbox_btn_link){
                                $link_url = $con_iconbox_btn_link['url'];
                            $link_title = $con_iconbox_btn_link['title'] ? $con_iconbox_btn_link['title'] : 'Read More';
                            $link_target = $con_iconbox_btn_link['target'] ? $con_iconbox_btn_link['target'] : '_self';?>
                                
                                <div class="link-box">
                                    <a href="<?php echo esc_url($link_url); ?>" target="<?php echo esc_attr($link_target); ?>">
                                        <?php echo esc_html($link_title); ?>
                                    </a>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } 
                        }?>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <!--End Fun Fact Section -->

    <!-- Projects Section Two -->
     <?php 
$con_project_bg_title = get_field('demo_project_bg_title');
$con_project_front_title = get_field('demo_project_front_title');
$con_project_all_btn_txt = get_field('demo_all_project_button_text');
$con_all_project_btnlink = get_field('demo_all_project_button_link');

if ($con_project_bg_title || $con_project_front_title) { ?>
    <section class="projects-section-two">
        <div class="auto-container">
            <div class="upper-box clearfix">
                <div class="sec-title">
                    <?php if ($con_project_bg_title) { ?>
                        <span class="float-text"><?php echo esc_html($con_project_bg_title); ?></span>
                    <?php } 
                    if ($con_project_front_title) { ?>
                        <h2><?php echo esc_html($con_project_front_title); ?></h2>
                    <?php } ?>
                </div>
                <?php if ($con_project_all_btn_txt) { ?>
                    <div class="link-box">
                        <a href="<?php echo esc_url($con_all_project_btnlink); ?>">
                            <?php echo esc_html($con_project_all_btn_txt); ?> 
                            <i class="fa fa-long-arrow-right"></i>
                        </a>
                    </div>
                <?php } ?>
            </div>

            <?php
            $con_project_relationship = get_field('demo_project_relationship');
            if ($con_project_relationship) {
                $con_project_type_txt = get_field('demoi_project_type');
            ?>
                <div class="projects-carousel-two owl-carousel owl-theme">
                <?php foreach ($con_project_relationship as $post) {
                    setup_postdata($post);
                    if (has_post_thumbnail()) {
                        $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
                        $alt_text = get_the_title();
                    ?>
                        <!-- Project Block -->
                        <div class="project-block-two">
                            <div class="image-box">
                                <figure class="image">
                                    <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($alt_text); ?>">
                                </figure>
                            </div>
                            <div class="info-box">
                                <div class="inner-box">
                                    <span class="title"><?php echo esc_html($con_project_type_txt); ?></span>
                                    <h3><?php the_title(); ?></h3>
                                    <div class="text"><?php the_excerpt(); ?></div>
                                    <div class="link-box">
                                        <a href="<?php the_permalink(); ?>">View Project</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                <?php } ?>
                </div>
                <?php wp_reset_postdata(); ?>
            <?php } ?>
        </div>
    </section>
<?php } ?>

    <!--End Projects Section Two -->

    <!-- Offer Section -->
     <?php 
     $con_offer_section_bg_img=get_field('demo_special_offer_background_image');
     $con_offer_section_small_title=get_field('demo_special_offer_small_title');
     $con_offer_section_main_title=get_field('demo_special_offer_main_title');
     $con_offer_section_discount_amount=get_field('demo_special_offer_discount_amount');
     $con_offer_section_short_desc=get_field('demo_special_offer_short_description');
     $con_offer_section_form_shortcode=get_field('demo_special_offer_form_shortcode');

     if($con_offer_section_bg_img){
     ?>
    <section class="offer-section" style="background-image: url(<?php echo $con_offer_section_bg_img; ?>);">
        <div class="auto-container">
            <div class="row">
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <?php if($con_offer_section_small_title){?>
                        <span class="title"><?php echo $con_offer_section_small_title; ?></span>
                        <?php } 
                        if($con_offer_section_main_title) {?>
                        <h2><?php echo $con_offer_section_main_title;?></h2>
                        <?php } 
                        if($con_offer_section_discount_amount){?>
                        <span class="discount"><?php echo $con_offer_section_discount_amount;?></span>
                        <?php } 
                        if($con_offer_section_short_desc){?>
                        <div class="text"><?php echo $con_offer_section_short_desc;?></div>
                        <?php } ?>
                    </div>
                </div> 
                <?php if($con_offer_section_form_shortcode){?>
                <div class="form-column order-last col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="discount-form">
                            <!--Comment Form-->
                            <?php echo do_shortcode($con_offer_section_form_shortcode); ?>
                        </div>
                    </div>
                </div> 
                <?php } ?>
            </div>
        </div>
    </section>
    <?php } ?>
    <!--End Offer Section -->

    <!-- Products Section -->
     <?php 
     $con_product_bg_title = get_field('demo_product_bg_title');
     $con_product_front_title = get_field('demo_product_front_title');
     $con_product_small_title = get_field('demo_product_small_title');
     $con_product_short_desc = get_field('demo_product_short_desc');
     $con_product_btn_txt = get_field('demo_product_btn_text');
     $con_product_btn_link = get_field('demo_product_btn_link');
     $con_product_relationship=get_field('demo_product_relationship');

     if($con_product_bg_title || $con_product_front_title){
     ?>
    <section class="products-section">
        <div class="auto-container">
            <div class="sec-title">
                <?php if($con_product_bg_title){?>
                <span class="float-text"><?php echo $con_product_bg_title; ?></span>
                <?php } 
                if($con_product_front_title){?>
                <h2><?php echo $con_product_front_title; ?></h2>
                <?php }?>
            </div>
            <div class="row">
                <div class="title-column col-lg-3 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <?php if($con_product_small_title){ ?>
                        <h4><?php echo $con_product_small_title; ?></h4>
                        <?php }
                        if($con_product_short_desc){ ?>
                        <div class="text"><?php echo $con_product_short_desc; ?></div>
                        <?php } 
                        if($con_product_btn_txt){?>
                        <div class="btn-box"><a href="<?php echo $con_product_btn_link?>" class="theme-btn btn-style-one"><?php echo $con_product_btn_txt; ?></a></div>
                        <?php } ?>
                    </div>
                </div>
                <?php if ($con_product_relationship) : ?>
                <div class="products-column col-lg-9 col-md-12 col-sm-12">
                    <div class="products-carousel owl-carousel owl-theme">
                        <?php foreach ($con_product_relationship as $post) : 
                            setup_postdata($post); 
                            $postid=get_the_ID();
                            $product = wc_get_product($postid); // WooCommerce product object
                            if ($product) : ?>
                                <div class="product-block">
                                    <div class="inner-box">
                                        <div class="info-box">
                                            <h5 class="name"><?php the_title(); ?></h5>
                                            <span class="price"><?php echo $product->get_price_html(); ?></span>
                                        </div>
                                        <div class="image-box">
                                            <figure class="image">
                                                <?php if (has_post_thumbnail()) : ?>
                                                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                                                <?php else : ?>
                                                    <img src="https://via.placeholder.com/300x300?text=No+Image" alt="No image">
                                                <?php endif; ?>
                                            </figure>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; wp_reset_postdata(); ?>
                    </div>
                </div>
            <?php else : ?>
                <p>No products found.</p>
            <?php endif; ?>
            </div>
        </div>
    </section>
    <?php } ?>
    <!--End Products Section -->

    <!--Clients Section-->
    <?php 
    $con_flexi_client_layout=get_field('demo_flexible_content_layout');
    if ( have_rows('demo_flexible_content_layout') ) {
        while ( have_rows('demo_flexible_content_layout') ) {
          the_row();
          if ( get_row_layout() == 'client_section_layout' ){
            $background_image = get_sub_field('demo_section_background_image');
            $gallery_images = get_sub_field('demo_client_gallery_image');
    ?>
    <section class="clients-section style-two" style="background-image: url(<?php echo $background_image; ?>);">
        <div class="auto-container">
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <?php if ( $gallery_images ) {
                         foreach ( $gallery_images as $image ) { ?>
                    <li class="slide-item">
                        <figure class="image-box">
                            <a href="#"><img src="<?php echo esc_url($image); ?>" alt=""></a>
                        </figure>
                    </li>
                    <?php
                    }
                }?>
                </ul>
            </div>
        </div>
    </section>
    <?php } 
        }
    }?>
    <!--End Clients Section-->
    

    <!-- News Section -->
     <?php 
     $con_news_bgtitle=get_field('demo_news_bg_title');
     $con_news_front_title=get_field('demo_news_front_title');
     if($con_news_bgtitle || $con_news_front_title){
     ?>
    <section class="news-section alternate">
        <div class="auto-container">
            <?php if($con_news_bgtitle || $con_news_front_title){?>
            <div class="sec-title">
                <?php if($con_news_bgtitle){?>
                <span class="float-text"><?php echo $con_news_bgtitle; ?></span>
                <?php } 
                if($con_news_front_title){?>
                <h2><?php echo $con_news_front_title?></h2>
                <?php } ?>
            </div>
            <?php } ?>
            <div class="row">
                <?php
                    $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => 4,
                    );
                    $the_query = new WP_Query($args);
                    if ($the_query->have_posts()) {
                    while ($the_query->have_posts()) {
                     $the_query->the_post(); ?>
                <!-- News Block -->
                <div class="news-block-two col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure class="image"><img src="<?php the_post_thumbnail_url(); ?>" alt=""></figure>
                            <div class="overlay-box"><a href="<?php echo get_the_permalink(); ?>"><i class="fa fa-link"></i></a></div>
                        </div>
                        <div class="caption-box">
                            <div class="inner">
                                <h3><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
                                <ul class="info">
                                    <li><?php echo get_the_date('d M'); ?></li>
                                    <li><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_author(); ?></a></li>
                                    <li><a href="<?php echo get_the_permalink(); ?>"><?php comments_number('0 Comments', '1 Comment', '% Comments'); ?></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }
                    wp_reset_postdata();
                }?>
            </div>
        </div>
    </section>
    <!--End News Section -->
    <?php }?>

   <?php get_footer(); ?>