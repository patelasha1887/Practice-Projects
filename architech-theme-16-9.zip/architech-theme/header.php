<!DOCTYPE html>
<html lang="en">

<!-- index-226:42-->
<head>
<meta charset="utf-8">
<title>Contra - Interior Creator HTML Template | Home Page 02</title>
<!-- Stylesheets -->
<link href="<?php echo THEMEPATH; ?>/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo THEMEPATH; ?>/css/style.css" rel="stylesheet">
<link href="<?php echo THEMEPATH; ?>/css/responsive.css" rel="stylesheet">   
<!--Color Switcher Mockup-->
<link href="<?php echo THEMEPATH; ?>/css/color-switcher-design.css" rel="stylesheet">
<!--Color Themes-->
<link id="theme-color-file" href="<?php echo THEMEPATH; ?>/css/color-themes/default-theme.css" rel="stylesheet">

<link rel="shortcut icon" href="<?php echo THEMEPATH; ?>/images/favicon.png" type="image/x-icon">
<link rel="icon" href="<?php echo THEMEPATH; ?>/images/favicon.png" type="image/x-icon">
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>
<?php wp_head(); ?>
<body>
<?php 
$con_address= get_field('demo_address','option');
$con_email= get_field('demo_email','option');
$con_iconset_repeater=get_field('demo_social_icon_repeater','option');
$con_iconset_group=get_field('demo_social_icon_group','option');
$con_site_logo=get_field('demo_site_logo','option');
?>
<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader"></div>
    
    <!-- Main Header-->
    <header class="main-header header-style-two">
        <!--Header Top-->
        <div class="header-top">
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <div class="top-left">
                        <ul class="contact-list clearfix">
                            <li><i class="fa fa-volume-control-phone"></i> 
                                <?php if($con_address) { echo $con_address; }?></li>
                            <li><i class="fa fa-envelope"></i><a href="#"><?php if($con_email) { echo $con_email; }?></a></li>
                        </ul>
                    </div>
                    <?php 
                    if($con_iconset_group){
                            // foreach($con_iconset_repeater as $con_social_icon_rptr){
                            //    $con_social_icon_rptr_img =$con_social_icon_rptr['demo_social_icon_img']; 
                            //    $con_social_icon_rptr_link =$con_social_icon_rptr['demo_icon_link'];?>
                    <div class="top-right">
                        <ul class="social-icon-four clearfix">
                            <?php if($con_iconset_group['demo_whatsapp_link']){ ?>
                            <li>
                                <a href="<?php echo $con_iconset_group['demo_whatsapp_link']; ?>">
                                    <i class="fa fa-whatsapp"></i>
                                </a>
                            </li>
                            <?php } if($con_iconset_group['demo_facebook_link']){ ?>
                            <li>
                                <a href="<?php  echo $con_iconset_group['demo_facebook_link']; ?>">
                                    <i class="fa fa-facebook-f"></i>
                                </a>
                            </li>
                            <?php } if($con_iconset_group['demo_instagram_link']){ ?>
                            <li><a href="<?php  echo $con_iconset_group['demo_instagram_link']; ?>">
                                <i class="fa fa-instagram"></i>
                                </a>
                            </li>
                            <?php }
                             if($con_iconset_group['demo_twiter_link']){ ?>
                            <li><a href="<?php echo $con_iconset_group['demo_twiter_link']; ?>">
                                <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <?php } 
                             if($con_iconset_group['demo_google_plus_link']){ ?>
                            <li>
                                <a href="<?php echo $con_iconset_group['demo_google_plus_link']; ?>">
                                <i class="fa fa-google-plus"></i>
                                </a>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <!-- End Header Top -->

        <div class="header-lower">
            <div class="auto-container">
                <div class="main-box clearfix">
                    <div class="logo-box">
                        <div class="logo">
                            <a href="<?php echo home_url(); ?>">
                                <img src="<?php if($con_site_logo){ echo esc_url($con_site_logo); } ?>" 
                                    alt="<?php echo esc_attr(get_bloginfo('name')); ?>" 
                                    title="<?php echo esc_attr(get_bloginfo('name')); ?>">
                            </a>
                        </div>
                    </div>

                    <div class="nav-outer clearfix">
                        <!-- Main Menu -->
                        <nav class="main-menu navbar-expand-md ">
                            <div class="navbar-header">
                                <!-- Toggle Button -->      
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="icon flaticon-menu-button"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse clearfix" id="navbarSupportedContent">
                                <?php
                                wp_nav_menu( array(
                                    'theme_location' => 'main-menu',
                                    'menu_class'     => 'navigation clearfix',
                                    
                                ) );
                                ?>
                            </div>
                        </nav><!-- Main Menu End-->                        

                        <!-- Outer Box-->
                        <div class="outer-box">
                            <!-- Cart Btn -->
                            <div class="cart-btn">
                                <a href="shop.html" title="">
                                    <i class="fa fa-shopping-basket"></i>
                                    <span class="count">2</span>
                                </a>
                            </div>

                            <!--Search Box-->
                            <div class="search-box-outer">
                                <div class="dropdown">
                                    <button class="search-box-btn dropdown-toggle" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="fa fa-search"></span></button>
                                    <ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
                                        <li class="panel-outer">
                                            <div class="form-container">
                                                <form method="post" action="#">
                                                    <div class="form-group">
                                                        <input type="search" name="field-name" value="" placeholder="Search Here" required>
                                                        <button type="submit" class="search-btn"><span class="fa fa-search"></span></button>
                                                    </div>
                                                </form>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sticky Header  -->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index-2.html" title=""><img src="<?php echo THEMEPATH; ?>/images/logo-small.png" alt="" title=""></a>
                </div>
                <!--Right Col-->
                <div class="pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-collapse show collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current dropdown"><a href="#">Home</a>
                                    <ul>
                                        <li class="dropdown"><a href="#">Header Styles</a>
                                            <ul>
                                                <li><a href="index-2.html">Header Style One</a></li>
                                                <li><a href="index-3.html">Header Style Two</a></li>
                                                <li><a href="index-4.html">Header Style Three</a></li>
                                                <li><a href="index-5.html">Header Style Four</a></li>
                                                <li><a href="index-6.html">Header Style Five</a></li>
                                                <li><a href="index-7.html">Header Style Six</a></li>
                                                <li><a href="about.html">Header Style Seven</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="index-2.html">Home page 01</a></li>
                                        <li><a href="index-3.html">Home page 02</a></li>
                                        <li><a href="index-4.html">Home page 03</a></li>
                                        <li><a href="index-5.html">Home page 04</a></li>
                                        <li><a href="index-6.html">Home page 05</a></li>
                                        <li><a href="index-7.html">Home page 06</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">About</a>
                                    <ul>
                                        <li><a href="about.html">About Us</a></li>
                                        <li><a href="faq.html">FAQ's</a></li>
                                        <li><a href="team.html">Our Team</a></li>
                                        <li><a href="coming-soon.html">Coming Soon</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">Services</a>
                                    <ul>
                                        <li><a href="services.html">All Services</a></li>
                                        <li><a href="service-detail.html">Commercial Design</a></li>
                                        <li><a href="service-detail.html">Landescape Design</a></li>
                                        <li><a href="service-detail.html">Interior Design</a></li>
                                        <li><a href="service-detail.html">Complete Interior</a></li>
                                        <li><a href="service-detail.html">House Interior</a></li>
                                        <li><a href="service-detail.html">Service Detail</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">Projects</a>
                                    <ul>
                                        <li><a href="projects.html">Projects</a></li>
                                        <li><a href="project-detail.html">Project Detail</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">Blog</a>
                                    <ul>
                                        <li><a href="blog.html">Blog</a></li>
                                        <li><a href="blog-classic.html">Blog Classic</a></li>
                                        <li><a href="blog-detail.html">Blog Detail 01</a></li>
                                        <li><a href="blog-detail-2.html">Blog Detail 02</a></li>
                                        <li><a href="error-page.html">Error Page</a></li>
                                    </ul>
                                </li>
                                <li class="dropdown"><a href="#">Shop</a>
                                    <ul>
                                        <li><a href="shop.html">Shop</a></li>
                                        <li><a href="shop-single.html">Product Details</a></li>
                                        <li><a href="shoping-cart.html">Cart Page</a></li>
                                        <li><a href="checkout.html">Checkout Page</a></li>
                                        <li><a href="login.html">Registration Page</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact</a></li>
                                <li class="dropdown has-mega-menu"><a href="#">Pages</a>
                                    <div class="mega-menu">
                                        <div class="mega-menu-bar row clearfix">
                                            <div class="column col-lg-3 col-md-3 col-sm-12">
                                                <h3>About</h3>
                                                <ul>
                                                    <li><a href="about.html">About Us</a></li>
                                                    <li><a href="faq.html">FAQ's</a></li>
                                                    <li><a href="team.html">Our Team</a></li>
                                                    <li><a href="coming-soon.html">Coming Soon</a></li>
                                                    <li><a href="login.html">Login</a></li>
                                                </ul>
                                            </div>
                                            <div class="column col-lg-3 col-md-3 col-sm-12">
                                                <h3>Services</h3>
                                                <ul>
                                                    <li><a href="services.html">All Services</a></li>
                                                    <li><a href="service-detail.html">Commercial Design</a></li>
                                                    <li><a href="service-detail.html">Landescape Design</a></li>
                                                    <li><a href="service-detail.html">Complete Interior</a></li>
                                                    <li><a href="service-detail.html">Service Detail</a></li>
                                                </ul>
                                            </div>
                                            <div class="column col-lg-3 col-md-3 col-sm-12">
                                                <h3>Projects</h3>
                                                <ul>
                                                    <li><a href="projects.html">Projects</a></li>
                                                    <li><a href="projects.html">Commercial Projects</a></li>
                                                    <li><a href="projects.html">Landescape Projects</a></li>
                                                    <li><a href="project-detail.html">Project Detail</a></li>
                                                    <li><a href="contact.html">Contact</a></li>
                                                </ul>
                                            </div>
                                            <div class="column col-lg-3 col-md-3 col-sm-12">
                                                <h3>Blog</h3>
                                                <ul>
                                                    <li><a href="blog.html">Blog Grid</a></li>
                                                    <li><a href="blog-classic.html">Blog Classic</a></li>
                                                    <li><a href="blog-detail.html">Blog Detail 01</a></li>
                                                    <li><a href="blog-detail-2.html">Blog Detail 01</a></li>
                                                    <li><a href="error-page.html">Error Page</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul> 
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
            </div>
        </div><!-- End Sticky Menu -->
    </header>
    <!--End Main Header -->
