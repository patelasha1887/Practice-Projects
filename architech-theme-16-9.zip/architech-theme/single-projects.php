<?php get_header(); 
 if ( function_exists('demo_inner_page_banner') ) {
    echo demo_inner_page_banner();
}
 ?>
<?php 
$featured_img = get_the_post_thumbnail_url(get_the_ID(), 'large');
$con_project_img_gallery=get_field('demo_project_img_gallery');
$con_project_desc=get_field('project_description');
$con_project_info_desc=get_field('demo_project_info');
$con_project_cs_small_title=get_field('demo_small_title');
$con_project_cs_main_title=get_field('demo_main_title');
$con_project_cs_short_desc=get_field('demo_short_content');
$con_project_cs_btn_link=get_field('demo_quick_btn_link');
$con_project_cs_btn_name=$con_project_cs_btn_link['title'];
$con_project_cs_btn_url=$con_project_cs_btn_link['url'];
?>
<!--Project Detail Section-->
    <section class="project-details-section">
        <div class="project-detail">
            <div class="auto-container">
                <!-- Upper Box -->
				 <?php if ($featured_img || $con_project_img_gallery){ ?>
                <div class="upper-box">
					<div class="project-tabs tabs-box clearfix">
						<!-- Tab Buttons -->
						<ul class="tab-btns tab-buttons clearfix">
							<?php 
							$i = 1;
							// Featured Image First
							if ($featured_img){ ?>
								<li data-tab="#tab-<?php echo $i; ?>" class="tab-btn active-btn">
									<img src="<?php echo esc_url($featured_img); ?>" alt="">
								</li>
								<?php $i++; ?>
							<?php }?>

							<!-- Gallery Thumbnails -->
							<?php if ($con_project_img_gallery){ 
								foreach ($con_project_img_gallery as $image){ ?>
									<li data-tab="#tab-<?php echo $i; ?>" class="tab-btn">
										<img src="<?php echo esc_url($image['sizes']['thumbnail']); ?>" alt="">
									</li>
									<?php $i++; ?>
								<?php }
							}?>
						</ul>

						<!-- Tabs Container -->
						<div class="tabs-content">
							<?php 
							$i = 1;

							// Featured Image First
							if ($featured_img){ ?>
								<div class="tab active-tab" id="tab-<?php echo $i; ?>">
									<figure class="image">
										<a href="<?php echo esc_url($featured_img); ?>" class="lightbox-image" data-fancybox="images">
											<img src="<?php echo esc_url($featured_img); ?>" alt="">
										</a>
									</figure>
								</div>
								<?php $i++; ?>
							<?php }?>

							<!-- Gallery Full Images -->
							<?php if ($con_project_img_gallery){ 
								foreach ($con_project_img_gallery as $image){ ?>
									<div class="tab" id="tab-<?php echo $i; ?>">
										<figure class="image">
											<a href="<?php echo esc_url($image['url']); ?>" class="lightbox-image" data-fancybox="images">
												<img src="<?php echo esc_url($image['sizes']['large']); ?>" alt="">
											</a>
										</figure>
									</div>
									<?php $i++; ?>
								<?php }
							}?>
						</div>
					</div>
				</div>
                <?php } ?>
                <!--Lower Content-->
                <div class="lower-content"> 
                    <div class="row clearfix">
						<?php if($con_project_desc){ ?>
                        <!--Content Column-->
                        <div class="content-column col-lg-8 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <?php echo $con_project_desc; ?>
                            </div>
                        </div>
                        <?php } ?>
                        <!--Info Column-->
                        <div class="info-column col-lg-4 col-md-12 col-sm-12 ">
						<div class="inner-column wow fadeInRight">
                            <?php echo $con_project_info_desc;
							 if($con_project_cs_main_title || $con_project_cs_small_title){
							 ?>
                                <!--Help Box-->
                                <div class="help-box-two">
                                    <div class="inner">
										<?php if($con_project_cs_small_title) {?>
                                        <span class="title"><?php echo $con_project_cs_small_title; ?></span>
										<?php } 
										if($con_project_cs_main_title){?>
                                        <h2><?php echo $con_project_cs_main_title; ?></h2>
										<?php } 
										if($con_project_cs_short_desc){ ?>
                                        <div class="text"><?php echo $con_project_cs_short_desc; ?></div>
                                        <?php } 
										if($con_project_cs_btn_link){ ?>
										<a class="theme-btn btn-style-two" href="<?php echo $con_project_cs_btn_url; ?>"><?php echo $con_project_cs_btn_name; ?></a>
										<?php } ?>
                                    </div>
                                </div>
								<?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Portfolio Details-->
<?php
get_footer();
