 <?php 
 $con_site_logo=get_field('demo_site_logo','option'); 
 $con_footer_desc=get_field('demo_footer_description','option');
 ?>
 <!-- Main Footer -->
    <footer class="main-footer alternate" style="background-image: url(<?php echo THEMEPATH; ?>/images/background/5.jpg);">
        <div class="auto-container">
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row">
                    <!--Big Column-->
                    <div class="big-column col-xl-7 col-lg-12 col-md-12 col-sm-12">
                        <div class="row">
                            <!--Footer Column-->
                            <div class="footer-column col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget about-widget">
                                    <div class="footer-logo">
                                        <figure>
                                            <a href="<?php echo home_url(); ?>">
                                                <img src="<?php if($con_site_logo){ echo esc_url($con_site_logo); } ?>" 
                                                    alt="<?php echo esc_attr(get_bloginfo('name')); ?>" 
                                                    title="<?php echo esc_attr(get_bloginfo('name')); ?>">
                                            </a>
                                        </figure>
                                    </div>
                                    <div class="widget-content">
                                    <?php if($con_footer_desc){?>    
                                        <div class="text">
                                            <?php echo $con_footer_desc; ?>
                                        </div>
                                    <?php } ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!--Footer Column-->
                            <div class="footer-column col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget recent-posts">
                                    <h2 class="widget-title">Recent Posts</h2>
                                     <!--Footer Column-->
                                    <div class="widget-content">
                                    <?php
                                        $args = array(
                                            'post_type' => 'post',
                                            'posts_per_page' => 5,
                                        );
                                        $the_query = new WP_Query($args);
                                        if ($the_query->have_posts()) {
                                            while ($the_query->have_posts()) {
                                                $the_query->the_post(); ?>
                                                <div class="post">
                                                    <div class="thumb">
                                                        <a href="<?php echo get_the_permalink(); ?>">
                                                            <?php the_post_thumbnail('full'); ?>
                                                        </a>
                                                    </div>
                                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                                    <ul class="info">
                                                        <li><?php echo get_the_date('d M'); ?></li>
                                                        <li><?php comments_number('0 Comments', '1 Comment', '% Comments'); ?></li>
                                                    </ul>
                                                </div>
                                            <?php }
                                            wp_reset_postdata();
                                        } ?>
                                    </div>
                                </div>
                            </div>         
                        </div>
                    </div>
                    
                    <!--Big Column-->
                    <div class="big-column col-xl-5 col-lg-12 col-md-12 col-sm-12">
                        <div class="row clearfix">
                            <div class="footer-column col-xl-5 col-lg-6 col-md-6 col-sm-12">
                                 <div class="footer-widget links-widget">
                                    <h2 class="widget-title">Useful links</h2>
                                    <div class="widget-content">
                                        <?php
                                        wp_nav_menu( array(
                                            'theme_location' => 'main-menu',
                                            'menu_class'     => 'list',
                                        ) );
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <!--Footer Column-->
                            <div class="footer-column col-xl-7 col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget gallery-widget">
                                    <h2 class="widget-title">Recent Works</h2>
                                    <div class="widget-content">
                                        <div class="outer clearfix">
                                    <?php
                                    $args = array(
                                        'post_type' => 'projects',
                                        'posts_per_page' => 6,
                                    );
                                    $the_query = new WP_Query($args);
                                    if ($the_query->have_posts()) {
                                        while ($the_query->have_posts()) {
                                            $the_query->the_post();
                                            if (has_post_thumbnail()) {
                                                $thumbnail_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                                $alt_text = get_the_title();
                                                ?>
                                                <figure class="image">
                                                    <a href="<?php echo esc_url($thumbnail_url); ?>" class="lightbox-image" title="<?php echo esc_attr($alt_text); ?>">
                                                        <img src="<?php echo esc_url($thumbnail_url); ?>" alt="<?php echo esc_attr($alt_text); ?>">
                                                    </a>
                                                </figure>
                                                <?php
                                            }
                                        }
                                        wp_reset_postdata();
                                    }
                                    ?>
                                    </div>
                                    </div>       
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $con_iconset_group=get_field('demo_social_icon_group','option'); ?>
        <!--Footer Bottom-->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <?php if($con_iconset_group){ ?>
                    <div class="social-links">
                        <ul class="social-icon-two">
                            <?php if($con_iconset_group['demo_whatsapp_link']){ ?>
                            <li>
                                <a href="<?php echo $con_iconset_group['demo_whatsapp_link']; ?>">
                                    <i class="fa fa-whatsapp"></i>
                                </a>
                            </li>
                            <?php } if($con_iconset_group['demo_facebook_link']){ ?>
                            <li>
                                <a href="<?php  echo $con_iconset_group['demo_facebook_link']; ?>">
                                    <i class="fa fa-facebook-f"></i>
                                </a>
                            </li>
                            <?php } if($con_iconset_group['demo_instagram_link']){ ?>
                            <li><a href="<?php  echo $con_iconset_group['demo_instagram_link']; ?>">
                                <i class="fa fa-instagram"></i>
                                </a>
                            </li>
                            <?php }
                             if($con_iconset_group['demo_twiter_link']){ ?>
                            <li><a href="<?php echo $con_iconset_group['demo_twiter_link']; ?>">
                                <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <?php } 
                             if($con_iconset_group['demo_google_plus_link']){ ?>
                            <li>
                                <a href="<?php echo $con_iconset_group['demo_google_plus_link']; ?>">
                                <i class="fa fa-google-plus"></i>
                                </a>
                            </li>
                            <?php } ?>
                        </ul>
                    </div>
                    <?php } ?>
                    <div class="copyright-text">
                     
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Main Footer -->
<?php wp_footer(); ?>
</div>



<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-circle-o-up"></span></div>
<script src="<?php echo THEMEPATH; ?>/js/jquery.<?php echo THEMEPATH; ?>/js"></script> 
<script src="<?php echo THEMEPATH; ?>/js/popper.min.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/bootstrap.min.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/jquery.fancybox.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/owl.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/jquery.mCustomScrollbar.concat.min.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/wow.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/appear.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/mixitup.<?php echo THEMEPATH; ?>/js"></script>
<script src="<?php echo THEMEPATH; ?>/js/script.<?php echo THEMEPATH; ?>/js"></script>
<!-- Color Setting -->
<script src="<?php echo THEMEPATH; ?>/js/color-settings.<?php echo THEMEPATH; ?>/js"></script>
</body>

<!-- index-226:55-->
</html>