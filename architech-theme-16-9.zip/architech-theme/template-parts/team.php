<?php
/*
Template Name:Our Team 
*/
get_header();?>

<?php if(function_exists('demo_inner_page_banner')) echo demo_inner_page_banner();?>

<!-- Team Section -->
<?php 
$con_team_member_relationship = get_field('add_team_members_relationship');

if( $con_team_member_relationship ){ ?>
    <section class="team-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!-- Team Block -->
                <?php foreach( $con_team_member_relationship as $post ): 
                    setup_postdata($post); // correctly sets global $post
                    $post_id = is_object($post) ? $post->ID : $post;

                    // ACF Fields
                    $con_team_member_name = get_field('demo_team_member_name', $post_id);
                    $con_team_member_desig = get_field('demo_team_designation', $post_id);
                    $con_team_profile_img  = get_field('demo_team_profile_img', $post_id);
                    $con_team_social_link_grp = get_field('demo_team_social_links_grp', $post_id);

                    $con_team_social_link_facebook   = $con_team_social_link_grp['demo_team_social_links_facebook'] ?? '';
                    $con_team_social_link_twitter    = $con_team_social_link_grp['demo_team_social_links_twiter'] ?? '';
                    $con_team_social_link_googleplus = $con_team_social_link_grp['demo_team_social_links_google_plus'] ?? '';
                    $con_team_social_link_insta      = $con_team_social_link_grp['demo_team_social_links_insta'] ?? '';
                    $con_team_social_link_whatsapp   = $con_team_social_link_grp['demo_team_social_links_whatsapp'] ?? '';
                ?>
                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <div class="image">
                                <a href="<?php the_permalink($post_id); ?>">
                                    <?php if ( $con_team_profile_img ){ ?>
                                       <img src="<?php echo $con_team_profile_img;  ?>" alt="<?php echo esc_attr(get_the_title($post_id)); ?>">
                                   <?php  } else { ?>
                                        <img src="<?php echo get_template_directory_uri(); ?>/images/default-team.jpg" alt="<?php echo esc_attr(get_the_title($post_id)); ?>">
                                    <?php } ?>
                                </a>
                            </div>
                            <ul class="social-links">
                                <?php if($con_team_social_link_facebook){ ?><li><a href="<?php echo esc_url($con_team_social_link_facebook); ?>"><i class="fa fa-facebook"></i></a></li><?php } ?>
                                <?php if($con_team_social_link_twitter){ ?><li><a href="<?php echo esc_url($con_team_social_link_twitter); ?>"><i class="fa fa-twitter"></i></a></li><?php } ?>
                                <?php if($con_team_social_link_googleplus){ ?><li><a href="<?php echo esc_url($con_team_social_link_googleplus); ?>"><i class="fa fa-google-plus"></i></a></li><?php } ?>
                                <?php if($con_team_social_link_insta){ ?><li><a href="<?php echo esc_url($con_team_social_link_insta); ?>"><i class="fa fa-instagram"></i></a></li><?php } ?>
                                <?php if($con_team_social_link_whatsapp){ ?><li><a href="<?php echo esc_url($con_team_social_link_whatsapp); ?>"><i class="fa fa-whatsapp"></i></a></li><?php } ?>
                            </ul>
                            <h3 class="name"><a href="<?php echo get_permalink($post_id); ?>"><?php echo get_the_title($post_id); ?></a></h3>
                        </div>
                        <?php if($con_team_member_desig){ ?>
                            <span class="designation"><?php echo esc_html($con_team_member_desig); ?></span>
                        <?php } ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php } wp_reset_postdata(); ?>

    <!--End Team Section -->
<?php get_footer(); ?>