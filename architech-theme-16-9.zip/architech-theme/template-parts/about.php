<?php
/*
Template Name: About Us
*/
get_header();

if ( function_exists('demo_inner_page_banner') ) {
    echo demo_inner_page_banner();
}

/**
 * Helpers to safely get image URL / link parts from ACF fields
 */
if ( ! function_exists('acf_get_image_url') ) {
    function acf_get_image_url( $field ) {
        if ( empty( $field ) ) return '';
        if ( is_array( $field ) ) {
            if ( ! empty( $field['url'] ) ) return $field['url'];
            // sometimes ACF returns [0] => url (rare). fallback:
            return reset($field) ?: '';
        }
        return $field; // string URL already
    }
}

if ( ! function_exists('acf_get_link') ) {
    function acf_get_link( $field ) {
        $out = array( 'url' => '', 'title' => '', 'target' => '' );
        if ( empty( $field ) ) return $out;
        if ( is_array( $field ) ) {
            $out['url']    = ! empty( $field['url'] ) ? $field['url'] : ( ! empty($field[0]) ? $field[0] : '' );
            $out['title']  = ! empty( $field['title'] ) ? $field['title'] : '';
            $out['target'] = ! empty( $field['target'] ) ? $field['target'] : '';
        } elseif ( is_string( $field ) ) {
            $out['url'] = $field;
        }
        return $out;
    }
}

/* Toggle to true while debugging layout output (prints HTML comments) */
$debug = false;

if ( have_rows('demo_about_page_layouts') ) {
    while ( have_rows('demo_about_page_layouts') ) {
        the_row();
        $layout = get_row_layout();
        if ( $debug ) echo "\n<!-- About template layout: {$layout} -->\n";

        /* ----------------- About Content ----------------- */
        if ( $layout === 'demo_about_content_layout' ) {
            $con_about_section_bg_img = get_sub_field('demo_about_section_bg_img');
            $bg_url = acf_get_image_url( $con_about_section_bg_img );

            $con_about_section_img1 = get_sub_field('demo_about_section_img1');
            $img1_url = acf_get_image_url( $con_about_section_img1 );

            $con_about_section_img2 = get_sub_field('demo_about_section_img2');
            $img2_url = acf_get_image_url( $con_about_section_img2 );

            $con_about_main_title  = get_sub_field('demo_about_main_title');
            $con_about_small_title = get_sub_field('demo_about_small_title');
            $con_about_desc        = get_sub_field('demo_about_desc');
            $con_about_btnlink     = acf_get_link( get_sub_field('demo_about_button_link') );
            ?>
            <!-- About Section -->
            <section class="about-section" style="background-image: url('<?php echo esc_url($bg_url); ?>');">
                <div class="auto-container">
                    <div class="row no-gutters">
                        <div class="image-column col-lg-6 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <?php if ( $con_about_main_title ) : ?>
                                    <div class="title-box wow fadeInLeft animated" data-wow-delay="1200ms">
                                        <h2><?php echo esc_html( $con_about_main_title ); ?></h2>
                                    </div>
                                <?php endif; ?>

                                <div class="image-box wow fadeInRight animated" data-wow-delay="600ms">
                                    <?php if ( $img1_url ) : ?>
                                        <figure class="alphabet-img"><img src="<?php echo esc_url($img1_url); ?>" alt=""></figure>
                                    <?php endif; ?>
                                    <?php if ( $img2_url ) : ?>
                                        <figure class="image"><img src="<?php echo esc_url($img2_url); ?>" alt=""></figure>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="content-column col-lg-6 col-md-12 col-sm-12">
                            <div class="inner-column wow fadeInLeft animated">
                                <div class="content-box">
                                    <?php if ( $con_about_small_title ) : ?>
                                        <div class="title"><h2><?php echo esc_html( $con_about_small_title ); ?></h2></div>
                                    <?php endif; ?>

                                    <?php if ( $con_about_desc ) : ?>
                                        <div class="text"><?php echo wp_kses_post( $con_about_desc ); ?></div>
                                    <?php endif; ?>

                                    <?php if ( ! empty( $con_about_btnlink['url'] ) ) : ?>
                                        <div class="link-box">
                                            <a href="<?php echo esc_url( $con_about_btnlink['url'] ); ?>" class="theme-btn btn-style-one"><?php echo esc_html( $con_about_btnlink['title'] ?: 'Learn More' ); ?></a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- End About Section -->
        <?php }

        /* ----------------- Counter & Feature ----------------- */
        elseif ( $layout === 'demo_counter_&_feature_section_layout' ) {
            $con_counter_section_bg_img = get_sub_field('demo_counter_section_bg_img');
            $bg_url = acf_get_image_url( $con_counter_section_bg_img );

            $con_counter_section_repeater = get_sub_field('demo_counter_section');
            $con_counter_feature_section_repeater = get_sub_field('demo_feature_section_iconbox_repeater');
            ?>
            <section class="fun-fact-and-features alternate" style="background-image: url('<?php echo esc_url($bg_url); ?>');">
                <div class="outer-box">
                    <div class="auto-container">
                        <?php if ( $con_counter_section_repeater && is_array($con_counter_section_repeater) ) : ?>
                            <div class="fact-counter">
                                <div class="row">
                                    <?php foreach ( $con_counter_section_repeater as $item ) :
                                        $num = $item['demo_counter_section_number'] ?? '';
                                        $title = $item['demo_counter_section_title'] ?? '';
                                        ?>
                                        <div class="counter-column col-lg-3 col-md-6 col-sm-12 wow fadeInUp">
                                            <?php if ( $num ) : ?>
                                                <div class="count-box">
                                                    <div class="count"><span class="count-text" data-speed="5000" data-stop="<?php echo esc_attr($num); ?>"><?php echo esc_html($num); ?></span></div>
                                                    <h4 class="counter-title"><?php echo esc_html($title); ?></h4>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ( $con_counter_feature_section_repeater && is_array($con_counter_feature_section_repeater) ) : ?>
                            <div class="features">
                                <div class="row">
                                    <?php foreach ( $con_counter_feature_section_repeater as $f ) :
                                        $f_img = acf_get_image_url( $f['demo_feature_icon_img'] ?? '' );
                                        $f_title = $f['demo_feature_section_title'] ?? '';
                                        $f_desc = $f['demo_feature_section_short_desc'] ?? '';
                                        $f_link = acf_get_link( $f['demo_feature_button_link'] ?? '' );
                                        ?>
                                        <div class="feature-block col-lg-4 col-md-6 col-sm-12">
                                            <div class="inner-box">
                                                <?php if ( $f_img ) : ?><div class="icon-box"><img src="<?php echo esc_url($f_img); ?>" alt=""></div><?php endif; ?>
                                                <?php if ( $f_title ) : ?><h3><a href="<?php echo esc_url($f_link['url'] ?: '#'); ?>"><?php echo esc_html($f_title); ?></a></h3><?php endif; ?>
                                                <?php if ( $f_desc ) : ?><div class="text"><?php echo wp_kses_post($f_desc); ?></div><?php endif; ?>
                                                <?php if ( ! empty($f_link['url']) ) : ?><div class="link-box"><a href="<?php echo esc_url($f_link['url']); ?>"><?php echo esc_html($f_link['title'] ?: 'Read More'); ?></a></div><?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </section>
            <!-- End Fun Fact Section -->
        <?php }

        /* ----------------- Clients ----------------- */
        elseif ( $layout === 'demo_client_section_layout' ) {
            $con_client_img_repeater = get_sub_field('demo_client_img_repeater');
            if ( $con_client_img_repeater && is_array($con_client_img_repeater) ) : ?>
                <section class="clients-section style-two">
                    <div class="auto-container">
                        <div class="sponsors-outer">
                            <ul class="sponsors-carousel owl-carousel owl-theme">
                                <?php foreach ( $con_client_img_repeater as $c ) :
                                    $logo = acf_get_image_url( $c['demo_client_img'] ?? '' );
                                    if ( ! $logo ) continue;
                                    ?>
                                    <li class="slide-item">
                                        <figure class="image-box"><a href="#"><img src="<?php echo esc_url($logo); ?>" alt=""></a></figure>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </section>
            <?php endif;
        }

        /* ----------------- Work Process ----------------- */
        elseif ( $layout === 'demo_work_process_layout' ) {
            $con_work_bg_title = get_sub_field('demo_work_process_bg_title');
            $con_work_front_title = get_sub_field('demo_work_process_front_title');
            $con_process_img_repeater = get_sub_field('demo_process_content_repeater');
            ?>
            <section class="process-section" style="background-image: url(images/background/8.jpg);">
                <div class="auto-container">
                    <div class="sec-title light">
                        <?php if ( $con_work_bg_title ) : ?><span class="float-text"><?php echo esc_html($con_work_bg_title); ?></span><?php endif; ?>
                        <?php if ( $con_work_front_title ) : ?><h2><?php echo esc_html($con_work_front_title); ?></h2><?php endif; ?>
                    </div>
                    <div class="row">
                        <?php if ( $con_process_img_repeater && is_array($con_process_img_repeater) ) :
                            foreach ( $con_process_img_repeater as $p ) :
                                $step = $p['demo_work_process_step_number'] ?? '';
                                $title = $p['demo_work_process_title'] ?? '';
                                $short = $p['demo_work_process_short_desc'] ?? '';
                                $plink = acf_get_link( $p['demo_work_process_button_link'] ?? '' );
                                ?>
                                <div class="process-block col-lg-3 col-md-6 col-sm-12">
                                    <div class="inner-box">
                                        <?php if ( $step ) : ?><span class="count"><?php echo esc_html($step); ?></span><?php endif; ?>
                                        <?php if ( $title ) : ?><h4><a href="<?php echo esc_url($plink['url'] ?: '#'); ?>"><?php echo esc_html($title); ?></a></h4><?php endif; ?>
                                        <?php if ( $short ) : ?><div class="text"><?php echo wp_kses_post($short); ?></div><?php endif; ?>
                                        <?php if ( ! empty($plink['url']) ) : ?><div class="link-box"><a href="<?php echo esc_url($plink['url']); ?>"><?php echo esc_html($plink['title'] ?: 'Learn More'); ?></a></div><?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach;
                        endif; ?>
                    </div>
                </div>
            </section>
            <!-- End Process Section -->
        <?php }

        /* ----------------- Special Offer ----------------- */
        elseif ( $layout === 'demo_special_offer_section_layout' ) {
            $con_special_offer_bg_img = get_sub_field('demo_special_background_image');
            $bg_url = acf_get_image_url( $con_special_offer_bg_img );
            $con_special_offer_small_title = get_sub_field('demo_special_offer_small_title');
            $con_special_offer_main_title  = get_sub_field('demo_special_offer_main_title');
            $con_special_offer_discount    = get_sub_field('demo_special_offer_discount_amount');
            $con_special_offer_short_desc  = get_sub_field('demo_special_offer_short_desc');
            $con_special_offer_contact_form = get_sub_field('demo_contact_form_shortcode');
            ?>
            <section class="offer-section" style="background-image: url('<?php echo esc_url($bg_url); ?>');">
                <div class="auto-container">
                    <div class="row">
                        <div class="content-column col-lg-6 col-md-12 col-sm-12">
                            <div class="inner-column">
                                <?php if ( $con_special_offer_small_title ) : ?><span class="title"><?php echo esc_html($con_special_offer_small_title); ?></span><?php endif; ?>
                                <?php if ( $con_special_offer_main_title ) : ?><h2><?php echo esc_html($con_special_offer_main_title); ?></h2><?php endif; ?>
                                <?php if ( $con_special_offer_discount ) : ?><span class="discount"><?php echo esc_html($con_special_offer_discount); ?></span><?php endif; ?>
                                <?php if ( $con_special_offer_short_desc ) : ?><div class="text"><?php echo wp_kses_post($con_special_offer_short_desc); ?></div><?php endif; ?>
                            </div>
                        </div>

                        <?php if ( $con_special_offer_contact_form ) : ?>
                            <div class="form-column order-last col-lg-6 col-md-12 col-sm-12">
                                <div class="inner-column">
                                    <div class="discount-form">
                                        <?php echo do_shortcode( $con_special_offer_contact_form ); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </section>
            <!-- End Offer Section -->
        <?php }

        /* ----------------- Video Section ----------------- */
        elseif ( $layout === 'demo_video_section_layout' ) {
            $con_video_section_bg_title   = get_sub_field('demo_video_section_bg_title');
            $con_video_section_front_title= get_sub_field('demo_video_section_front_title');
            $con_video_section_special_title = get_sub_field('demo_video_section_special_title');
            $con_video_section_desc       = get_sub_field('demo_video_section_desc');
            $con_video_section_bg_img     = get_sub_field('demo_bg_image_for_video');
            $video_bg_url = acf_get_image_url( $con_video_section_bg_img );
            $con_video_link = get_sub_field('demo_video_link'); // usually a URL
            ?>
            <section class="video-section style-two">
                <div class="outer-box">
                    <div class="auto-container">
                        <div class="row">
                            <div class="content-column col-lg-6 col-md-12 col-sm-12">
                                <div class="inner-column">
                                    <div class="sec-title">
                                        <?php if ( $con_video_section_bg_title ) : ?><span class="float-text"><?php echo esc_html($con_video_section_bg_title); ?></span><?php endif; ?>
                                        <?php if ( $con_video_section_front_title ) : ?><h2><?php echo esc_html($con_video_section_front_title); ?></h2><?php endif; ?>
                                    </div>
                                    <?php if ( $con_video_section_special_title ) : ?><span class="title"><?php echo esc_html($con_video_section_special_title); ?></span><?php endif; ?>
                                    <?php if ( $con_video_section_desc ) : ?><div class="text"><?php echo wp_kses_post($con_video_section_desc); ?></div><?php endif; ?>
                                </div>
                            </div>

                            <div class="video-column col-lg-6 col-md-12 col-sm-12">
                                <div class="inner-column">
                                    <div class="video-box">
                                        <figure class="image"><img src="<?php echo esc_url($video_bg_url); ?>" alt="">
                                            <a href="<?php echo esc_url( $con_video_link ); ?>" class="link" data-fancybox="gallery"><span class="icon fa fa-play"></span></a>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- End Video Section -->
        <?php }

        /* ----------------- Team Section ----------------- */
        elseif ( $layout === 'demo_team_section_layout' ) {
            $con_team_section_bg_title   = get_sub_field('demo_team_section_bg_title');
            $con_team_section_front_title= get_sub_field('demo_team_section_front_title');
            $con_team_section_relationship = get_sub_field('demo_team_member_relationship');

            if ( $con_team_section_relationship && is_array($con_team_section_relationship) ) : ?>
                <section class="team-section">
                    <div class="auto-container">
                        <div class="sec-title">
                            <?php if ( $con_team_section_bg_title ) : ?><span class="float-text"><?php echo esc_html($con_team_section_bg_title); ?></span><?php endif; ?>
                            <?php if ( $con_team_section_front_title ) : ?><h2><?php echo esc_html($con_team_section_front_title); ?></h2><?php endif; ?>
                        </div>

                        <div class="row clearfix">
                            <?php foreach ( $con_team_section_relationship as $post ) : 
                                setup_postdata( $post );
                                $postid=get_the_ID();
                                $con_team_profile_img = get_field('demo_team_profile_img', $postid);
                                $profile_img_url = acf_get_image_url( $con_team_profile_img );
                                $con_team_designation = get_field('demo_team_designation', $postid);
                                $con_team_social_link_grp = get_field('demo_team_social_links_grp', $postid);
                                if ( ! $profile_img_url ) continue;
                                ?>
                                <div class="team-block col-lg-4 col-md-6 col-sm-12">
                                    <div class="inner-box">
                                        <div class="image-box">
                                            <div class="image"><a href="<?php echo esc_url( get_permalink( $postid ) ); ?>"><img src="<?php echo esc_url($profile_img_url); ?>" alt=""></a></div>
                                            <?php if ( $con_team_social_link_grp ) :
                                                $con_facebook = $con_team_social_link_grp['demo_team_social_links_facebook'] ?? '';
                                                $con_twiter   = $con_team_social_link_grp['demo_team_social_links_twiter'] ?? '';
                                                $con_google_plus = $con_team_social_link_grp['demo_team_social_links_facebook'] ?? '';
                                                $con_insta    = $con_team_social_link_grp['demo_team_social_links_insta'] ?? '';
                                                $con_whatsapp = $con_team_social_link_grp['demo_team_social_links_whatsapp'] ?? '';
                                                ?>
                                                <ul class="social-links">
                                                    <?php if ( $con_facebook ) : ?><li><a href="<?php echo esc_url($con_facebook); ?>"><i class="fa fa-facebook"></i></a></li><?php endif; ?>
                                                    <?php if ( $con_twiter ) : ?><li><a href="<?php echo esc_url($con_twiter); ?>"><i class="fa fa-twitter"></i></a></li><?php endif; ?>
                                                    <?php if ( $con_google_plus ) : ?><li><a href="<?php echo esc_url($con_google_plus); ?>"><i class="fa fa-google-plus"></i></a></li><?php endif; ?>
                                                    <?php if ( $con_insta ) : ?><li><a href="<?php echo esc_url($con_insta); ?>"><i class="fa fa-instagram"></i></a></li><?php endif; ?>
                                                    <?php if ( $con_whatsapp ) : ?><li><a href="<?php echo esc_url($con_whatsapp); ?>"><i class="fa fa-whatsapp"></i></a></li><?php endif; ?>
                                                </ul>
                                            <?php endif; ?>

                                            <h3 class="name"><a href="<?php echo esc_url( get_permalink( $postid ) ); ?>"><?php echo esc_html( get_the_title( $postid ) ); ?></a></h3>
                                        </div>

                                        <?php if ( $con_team_designation ) : ?><span class="designation"><?php echo esc_html( $con_team_designation ); ?></span><?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach;
                            wp_reset_postdata(); ?>
                        </div>
                    </div>
                </section>
            <?php endif;
        }

        /* ----------------- Testimonial Section ----------------- */
        elseif ( $layout === 'demo_testimonial_section_layout' ) {
            $con_testimonial_section_bg_title = get_sub_field('demo_testimonial_bg_title');
            $con_testimonial_section_front_title = get_sub_field('demo__front_title'); // note: preserve your original field key
            $con_testimonial_section_relationship = get_sub_field('demo_testimonials_relationship');

            if ( $con_testimonial_section_relationship && is_array($con_testimonial_section_relationship) ) : ?>
                <section class="testimonial-section-two">
                    <div class="auto-container">
                        <div class="sec-title">
                            <?php if ( $con_testimonial_section_bg_title ) : ?><span class="float-text"><?php echo esc_html($con_testimonial_section_bg_title); ?></span><?php endif; ?>
                            <?php if ( $con_testimonial_section_front_title ) : ?><h2><?php echo esc_html($con_testimonial_section_front_title); ?></h2><?php endif; ?>
                        </div>

                        <div class="testimonial-carousel-two owl-carousel owl-theme">
                            <?php foreach ( $con_testimonial_section_relationship as $post ) : setup_postdata( $post );
                                    $postid=get_the_ID(); ?>
                                <div class="testimonial-block-two">
                                    <div class="inner-box">
                                        <div class="text"><?php echo wp_kses_post( get_the_content( null, false, $post ) ); ?></div>
                                        <div class="info-box">
                                            <div class="thumb"><img src="<?php echo esc_url( get_the_post_thumbnail_url( $postid ) ); ?>" alt=""></div>
                                            <h5 class="name"><?php echo esc_html( get_the_title( $postid ) ); ?></h5>
                                            <span class="date"><?php echo esc_html( get_the_date( '', $postid ) ); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach;
                            wp_reset_postdata(); ?>
                        </div>
                    </div>
                </section>
            <?php endif;
        }

        /* other layouts could be added here... */

    } // end while have_rows
} else {
    if ( $debug ) echo "\n<!-- No rows found for demo_about_page_layouts -->\n";
}

get_footer();
