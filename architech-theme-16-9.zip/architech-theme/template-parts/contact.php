<?php
/*
Template Name: Contact
*/
get_header();?>

<?php if(function_exists('demo_inner_page_banner')) echo demo_inner_page_banner();

$con_cs_bg_title=get_field('demo_contact_bg_title');
$con_cs_front_title=get_field('demo_contact_front_title');
$con_cs_form_shortcode=get_field('demo_contact_form_shortcode');
$con_cs_google_map_link=get_field('demo_contact_google_map_link');
$con_cs_address_title=get_field('demo_contact_section_title');
$con_cs_address_txt=get_field('Demo_contact_location_txt');
$con_cs_phone_title=get_field('demo_contact_phone_section_title');
$con_cs_phone_txt_1=get_field('demo_phn_section_txt_1');
$con_cs_phone_txt_2=get_field('demo_phn_section_txt_2');
$con_cs_email_title=get_field('demo_contact_email_title');
$con_cs_email_txt1=get_field('demo_contact_email_1');
$con_cs_email_txt2=get_field('demo_contact_email_2');
$con_cs_client_section_repeater=get_field('demo_contact_client_img');
?>
<!-- Contact Page Section -->
    <section class="contact-page-section">
        <div class="auto-container">
            <div class="row">
                <!-- Form Column -->
                <div class="form-column col-lg-7 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <?php if($con_cs_bg_title || $con_cs_front_title) { ?>
                        <div class="sec-title">
                            <?php if($con_cs_bg_title){?>
                            <span class="float-text"><?php echo $con_cs_bg_title; ?></span>
                            <?php } 
                            if($con_cs_front_title){?>
                            <h2><?php echo $con_cs_front_title; ?></h2>
                            <?php } ?>
                        </div>
                        <?php } ?>
                        <div class="contact-form">
                            <?php echo do_shortcode($con_cs_form_shortcode); ?>
                        </div>
                        <div class="contact-info">
                            <div class="row">
                                <?php if($con_cs_address_title){?>
                                <div class="info-block col-lg-4 col-md-4 col-sm-12">
                                    <div class="inner">
                                        <h4><?php echo $con_cs_address_title; ?></h4>
                                        <p><?php echo $con_cs_address_txt; ?></p>
                                    </div>
                                </div>
                                <?php } 
                                if($con_cs_phone_title){ ?>
                                <div class="info-block col-lg-4 col-md-4 col-sm-12">
                                    <div class="inner">
                                        <h4><?php echo $con_cs_phone_title; ?></h4>
                                        <?php if($con_cs_phone_txt_1){ ?><p><?php echo $con_cs_phone_txt_1; ?></p><?php } ?>
                                        <?php if($con_cs_phone_txt_2){ ?><p><?php echo $con_cs_phone_txt_2; ?></p><?php } ?>
                                    </div>

                                </div>
                                <?php } 
                                if($con_cs_email_title){?>
                                <div class="info-block col-lg-4 col-md-4 col-sm-12">
                                    <div class="inner">
                                        <?php if($con_cs_email_title){ ?><h4><?php echo $con_cs_email_title; ?></h4> <?php } ?>
                                        <?php if($con_cs_email_txt1){?><p><a href="<?php echo $con_cs_email_txt1; ?>"><?php echo $con_cs_email_txt1; ?></a></p> <?php } ?>
                                        <?php if($con_cs_email_txt2){?><p><a href="<?php echo $con_cs_email_txt2; ?>"><?php echo $con_cs_email_txt2; ?></a></p><?php } ?>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($con_cs_google_map_link){?>
                <div class="map-column col-lg-5 col-md-12 col-sm-12">
                    <div class="inner-column">
                         <div class="map-outer">
                            <?php echo $con_cs_google_map_link; ?>
                            </div>
                        </div>
                    </div>
                </div>  
                <?php } ?>              
            </div>
        </div>
    </section>
    <!--End Contact Page Section -->

    <!--Clients Section-->
    <?php if($con_cs_client_section_repeater){ ?>
    <section class="clients-section style-two">
        <div class="auto-container">
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <?php foreach($con_cs_client_section_repeater as $con_cs_client_section_rptr){ 
                        $con_cs_client_rptr_img=$con_cs_client_section_rptr['demo_contact_client_img']; 
                    ?>
                    <li class="slide-item"><figure class="image-box"><a href="<?php echo $con_cs_client_rptr_img; ?>"><img src="<?php echo $con_cs_client_rptr_img; ?>" alt=""></a></figure></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </section>
    <?php } ?>
    <!--End Clients Section-->

<?php get_footer(); ?>