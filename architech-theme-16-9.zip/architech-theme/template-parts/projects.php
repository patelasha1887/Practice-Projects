<?php
/*
Template Name: Projects
*/
get_header();?>

<?php if(function_exists('demo_inner_page_banner')) echo demo_inner_page_banner();?>

<!-- Projects Section -->
    <section class="projects-section alternate">
        <div class="auto-container">
             <!--MixitUp Galery-->
            <div class="mixitup-gallery">
                <!--Filter-->
                <div class="filters text-center clearfix">                     
                    <?php 
                        $terms = get_terms( array(
                            'taxonomy' => 'project_category',
                            'hide_empty' => true,
                        ) );

                        if ( !empty($terms) && !is_wp_error($terms) ) { ?>
                            <ul class="filter-tabs filter-btns clearfix">
                                <li class="active filter" data-role="button" data-filter="all">All</li>
                                <?php foreach( $terms as $term ): ?>
                                    <li class="filter" data-role="button" data-filter=".<?php echo esc_attr($term->slug); ?>">
                                        <?php echo esc_html($term->name); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php } ?>                         
                </div>
                                            
                <div class="filter-list row">
                <?php 
                $args = array(
                    'post_type' => 'projects',
                    'posts_per_page' => -1,
                );
                $projects = new WP_Query($args);

                if ( $projects->have_posts() ) :
                    while ( $projects->have_posts() ) : $projects->the_post();

                        $terms = get_the_terms( get_the_ID(), 'project_category' );
                        $term_slugs = '';
                        if ( $terms && !is_wp_error($terms) ) {
                            foreach( $terms as $term ) {
                                $term_slugs .= ' ' . $term->slug;
                            }
                        }
                ?>
                    <div class="project-block all mix<?php echo esc_attr($term_slugs); ?> col-lg-4 col-md-6 col-sm-12">
                        <div class="image-box">
                            <figure class="image"><?php the_post_thumbnail('medium'); ?></figure>
                            <div class="overlay-box">
                                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                <div class="btn-box">
                                    <a href="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(),'large')); ?>" class="lightbox-image" data-fancybox="gallery">
                                        <i class="fa fa-search"></i>
                                    </a>
                                    <a href="<?php the_permalink(); ?>"><i class="fa fa-external-link"></i></a>
                                </div>
                                <?php if($terms): ?>
                                    <span class="tag"><?php echo esc_html($terms[0]->name); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php 
                    endwhile; 
                    wp_reset_postdata();
                endif;
                ?>
            </div>
            </div>

            <!--Post Share Options-->
            <div class="styled-pagination">
                <ul class="clearfix">
                    <li class="prev-post"><a href="#"><span class="fa fa-long-arrow-left"></span> Prev</a></li>
                    <li><a href="#">1</a></li>
                    <li class="active"><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li class="next-post"><a href="#"> Next <span class="fa fa-long-arrow-right"></span> </a></li>
                </ul>
            </div>
        </div>
    </section>


<?php get_footer(); ?>