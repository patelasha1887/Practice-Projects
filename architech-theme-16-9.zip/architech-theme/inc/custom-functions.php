<?php
// Exit If Accessed Directly
 if( !defined( 'ABSPATH' ) ) exit;

if( !defined( 'THEMEPATH' ) ){
    define( 'THEMEPATH', get_template_directory_uri().'/assets' );
}
/**
 * Enqueue scripts and styles.
 */
function woocommerce_theme_scripts() {
	/* enqueue theme css files*/
	
	wp_enqueue_style( 'bootstrap-css', get_template_directory_uri().'/assets/css/bootstrap.css', array(), time(),'all' );
	wp_enqueue_style( 'style-css', get_template_directory_uri().'/assets/css/style.css', array(), time(),'all' );
	wp_enqueue_style( 'responsive-css', get_template_directory_uri().'/assets/css/responsive.css', array(), time(),'all' );
	wp_enqueue_style( 'color-switcher-design', get_template_directory_uri().'/assets/css/color-switcher-design.css', array(), time(),'all' );
	wp_enqueue_style( 'default-theme-css', get_template_directory_uri().'/assets/css/color-themes/default-theme.css', array(), time(),'all' );
    wp_enqueue_style( 'animate-css', get_template_directory_uri().'/assets/css/animate.css', array(), time(),'all' );
    wp_enqueue_style( 'flaticon-css', get_template_directory_uri().'/assets/css/flaticon.css', array(), time(),'all' );
    wp_enqueue_style( 'font-awesome-css', get_template_directory_uri().'/assets/css/font-awesome.css', array(), time(),'all' );
    wp_enqueue_style( 'jquery-bootstrap-touchspin-css', get_template_directory_uri().'/assets/css/jquery.bootstrap-touchspin.css', array(), time(),'all' );
    wp_enqueue_style( 'jquery-fancybox-min-css', get_template_directory_uri().'/assets/css/jquery.fancybox.min.css', array(), time(),'all' );
    wp_enqueue_style( 'jquery-mCustomScrollbar-min-css', get_template_directory_uri().'/assets/css/jquery.mCustomScrollbar.min.css', array(), time(),'all' );
    wp_enqueue_style( 'jquery-ui-css', get_template_directory_uri().'/assets/css/jquery-ui.css', array(), time(),'all' );
    wp_enqueue_style( 'owl-css', get_template_directory_uri().'/assets/css/owl.css', array(), time(),'all' );
	
     /* enqueue theme scripts*/
	wp_enqueue_script('jquery-js', get_template_directory_uri().'/assets/js/jquery.js', array(), _S_VERSION, true );
	wp_enqueue_script('popper-min-js', get_template_directory_uri().'/assets/js/popper.min.js', array(), _S_VERSION, true );
	wp_enqueue_script('bootstrap-min-js', get_template_directory_uri().'/assets/js/bootstrap.min.js', array(), _S_VERSION, true );
	wp_enqueue_script('jquery-fancybox-js', get_template_directory_uri().'/assets/js/jquery.fancybox.js', array(), _S_VERSION, true );
	wp_enqueue_script('owl-js', get_template_directory_uri().'/assets/js/owl.js', array(), _S_VERSION, true );
	wp_enqueue_script('jquery-mCustomScrollbar-concat-min-js', get_template_directory_uri().'/assets/js/jquery.mCustomScrollbar.concat.min.js', array(), _S_VERSION, true );
	wp_enqueue_script('wow-js', get_template_directory_uri().'/assets/js/wow.js', array(), _S_VERSION, true );
	wp_enqueue_script('appear-js', get_template_directory_uri().'/assets/js/appear.js', array(), _S_VERSION, true );
	wp_enqueue_script('mixitup-js', get_template_directory_uri().'/assets/js/mixitup.js', array(), _S_VERSION, true );
	wp_enqueue_script('script-js', get_template_directory_uri().'/assets/js/script.js', array(), _S_VERSION, true );
	wp_enqueue_script('color-settings-js', get_template_directory_uri().'/assets/js/color-settings.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'woocommerce_theme_scripts' );

function mytheme_register_menus() {
    register_nav_menus(
        array(
            'main-menu' => __( 'Primary Menu', 'mytheme' ),
            'footer_menu'  => __( 'Footer Menu', 'mytheme' ),
        )
    );
}
add_action( 'after_setup_theme', 'mytheme_register_menus' );

remove_filter('the_content', 'wpautop');

function demo_inner_page_banner(){
	global $post;
    $con_page_banner_img=get_field("demo_inner_banner_image");
    $con_page_banner_title=get_field("demo_inner_page_title");
    $con_page_banner_short_desc=get_field("demo_inner_page_short_desc");
    if($con_page_banner_img){?>
    <section class="page-title" style="background-image:url(<?php echo $con_page_banner_img; ?>);">
        <div class="auto-container">
            <div class="inner-container clearfix">
                <div class="title-box">
                    <?php if($con_page_banner_title){?>
                    <h1><?php echo $con_page_banner_title; ?></h1>
                    <?php }else{?>
                        <h1><?php echo get_the_title();?></h1>
                        <?php }
                        if($con_page_banner_short_desc){?>
                    <span class="title"><?php echo $con_page_banner_short_desc; ?></span>
                    <?php } ?>
                </div>
                <ul class="bread-crumb clearfix">
                    <li><a href="<?php echo home_url(); ?>">Home</a></li>
                    <?php
                    if (is_single()) {
                        echo '<li>';
                        the_category(', ');
                        echo '</li>';
                        echo '<li>' . get_the_title() . '</li>';
                    } elseif (is_page()) {
                        if ($post->post_parent) {
                            $parent_id  = $post->post_parent;
                            $breadcrumbs = array();
                            while ($parent_id) {
                                $page = get_page($parent_id);
                                $breadcrumbs[] = '<li><a href="' . get_permalink($page->ID) . '">' . get_the_title($page->ID) . '</a></li>';
                                $parent_id  = $page->post_parent;
                            }
                            $breadcrumbs = array_reverse($breadcrumbs);
                            foreach ($breadcrumbs as $crumb) echo $crumb;
                        }
                        echo '<li>' . get_the_title() . '</li>';
                    } elseif (is_category()) {
                        echo '<li>Category: ' . single_cat_title('', false) . '</li>';
                    } elseif (is_search()) {
                        echo '<li>Search Results for: "' . get_search_query() . '"</li>';
                    } elseif (is_404()) {
                        echo '<li>404 Not Found</li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </section>
    <?php } 
	}
    function register_project_taxonomy() {
    register_taxonomy(
        'project_category',
        'projects',
        array(
            'label' => __( 'Project Categories' ),
            'rewrite' => array( 'slug' => 'project-category' ),
            'hierarchical' => true,
        )
    );
}
add_action( 'init', 'register_project_taxonomy' );
?>