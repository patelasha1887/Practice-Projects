<!DOCTYPE html>
<html <?php echo language_attributes(); ?>>

<head>
  <meta charset="<?php echo get_bloginfo('charset'); ?>">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo get_bloginfo('name'); ?>|<?php echo get_bloginfo('description');?></title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo get_bloginfo('template_url'); ?>/assets/img/favicon.png" rel="icon">
  <link href="<?php echo get_bloginfo('template_url'); ?>/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">


  <!-- =======================================================
  * Template Name: FlexStart
  * Updated: Jan 09 2024 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/flexstart-bootstrap-startup-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
<?php wp_head(); ?>
</head>
<body>

  <?php
  //code for custom logo display
  $img= get_bloginfo('template_url').'/assets/img/logo.png';
  $custom_logo_id=get_theme_mod('custom_logo');
          $logo=wp_get_attachment_image_src($custom_logo_id,'full');
          if(has_custom_logo()){
            $img=esc_url($logo[0]);
          }
  ?>
  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
      <a href="<?php echo site_url(); ?>" class="logo d-flex align-items-center">
        <img src="<?php echo $img; ?>" alt="">
        <span></span>
      </a>
      <nav id="navbar" class="navbar">  
        <?php 
        if(has_nav_menu("primary-menu")){
          wp_nav_menu(array(
            'theme_location'=>"primary-menu",
            'menu_class'=>'navbar',
            'container'=>'div',
            'menu_id'=>'menu-menu-1',
            'items_wrap'=>'<ul id="%1$s" class="%2$s">%3$s</ul>'
              ));

        } 
        //alternate option
        // $locationdetails = get_nav_menu_locations();
        // $menuID = $locationdetails['primary-menu'];//primary-menu= menu-items=7 & locations =2
        // $mainmenu= wp_get_nav_menu_items($menuID);
        //print_r($mainmenu);
        ?>
         <!-- <ul class="navbar"> 
           <?php foreach($mainmenu as $key=>$value){ ?> 
            <li>
              <a class="nav-link scrollto dropdown" data-hover=<?php echo $value->title; ?>
              href="<?php echo $value->url; ?>" > <?php echo $value->title; ?></a></li> -->
          <!-- <?php
          }
         ?>
        </ul> -->
        <a class="getstarted scrollto" href="#about" style="background: <?php echo get_option('custom_theme_link_color_picker'); ?>;">Get Started</a>
        <i class="bi bi-list mobile-nav-toggle"></i>
        <div class="col-sm">
      </nav><!-- .navbar -->
      </div>
  
  </div>  
  </header><!-- End Header -->
  