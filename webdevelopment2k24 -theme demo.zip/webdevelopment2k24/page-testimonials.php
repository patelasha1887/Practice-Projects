<?php 
get_header();
the_post();
?>
<h6>page-testimonials.php</h6>
  <main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2><?php the_title(); ?></h2>
          <p>What they are saying about us</p>
        </header>
        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="200">
          <div class="swiper-wrapper">
            <?php
            $query = new WP_Query(array(
            'post_type' => 'testimonials',
            'post_status' => 'publish'
          ));              
          ?>
          <?php 
            if($query->have_posts()){
              while ($query->have_posts()) {
                $query->the_post();
                $postid=get_the_ID();
              ?>
            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="stars">
                  <?php
                    $star=get_post_meta($postid,"ct_testimonials_rating_key",true);
                    for ($i=0; $i <$star ; $i++) {?> 
                      <i class="bi bi-star-fill"></i>
                  <?php  }
                  ?>
                </div>
                <p> <?php echo get_the_content(); ?>
                </p>
                <div class="profile mt-auto ">
                  <?php 
                  global $post;
                  $image = the_post_thumbnail();
                  ?>
                  <a href="<?php echo get_the_permalink(); ?>">
                    <img src="<?php echo esc_attr( esc_url( $image ) ); ?>" class="testimonial-img" alt="">
                  <h3><?php the_title(); ?></h3>
                  <h4><?php
                echo get_post_meta($postid, 'ct_testimonials_desig_key', true);?></h4>
                </a>
                </div>
              </div>
            </div><!-- End testimonial item -->
            <?php
               }
               
            }wp_reset_postdata();
          ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section><!-- End Testimonials Section -->
</main>

<?php
get_footer();
?>