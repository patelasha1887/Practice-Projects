<!-- home page work as blog page -->
<?php get_header(); ?>
<!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php single_post_title(); ?></li>
        </ol>
        <h2><?php single_post_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->  
<?php
  $dbquery= new wp_query(array('post_type'=>'post','post_status'=>'publish'));
?>
<!-- ends -->
<h2>home.php</h2>
    <!-- ======= Recent Blog Posts Section ======= -->
    <section id="recent-blog-posts" class="recent-blog-posts">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <p>Recent posts form our Blog</p>
        </header>

        <div class="row">
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
                get_template_part("template-parts/content",get_post_format());
                
              }
            }
          ?>
        </div>
      </div>

    </section><!-- End Recent Blog Posts Section -->

   
  </main><!-- End #main -->
<?php get_footer(); ?>
