jQuery(function($){

    $('body').on('click', '.cpt_upload_image_button', function(e){
        e.preventDefault();
        var button = $(this),
        cp_uploader = wp.media({
            title: 'Custom image',
            library : {
                uploadedTo : wp.media.view.settings.post.id,
                type : 'image'
            },
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).on('select', function() {
            var attachment = cp_uploader.state().get('selection').first().toJSON();
            $('#ct_banner_bgimg_key').val(attachment.url);
            
        })
        .open();
    });
});