jQuery(function($){

    $('body').on('click', '.cpt_upload_image_button', function(e){
        e.preventDefault();
        var button = $(this),
        cp_uploader = wp.media({
            title: 'Custom image',
            library : {
                uploadedTo : wp.media.view.settings.post.id,
                type : 'image'
            },
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).on('select', function() {
            var attachment = cp_uploader.state().get('selection').first().toJSON();
            $('#ct_price_plan1_img_key').val(attachment.url);
            
        })
        .open();
    });

    $('body').on('click', '.cpt_upload_image_button_plan2', function(e){
        e.preventDefault();
        var button = $(this),
        cp_uploader = wp.media({
            title: 'Custom image',
            library : {
                uploadedTo : wp.media.view.settings.post.id,
                type : 'image'
            },
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).on('select', function() {
            var attachment = cp_uploader.state().get('selection').first().toJSON();
            $('#ct_price_plan2_img_key').val(attachment.url);
        })
        .open();
    });

    $('body').on('click', '.cpt_upload_image_button_plan3', function(e){
        e.preventDefault();
        var button = $(this),
        cp_uploader = wp.media({
            title: 'Custom image',
            library : {
                uploadedTo : wp.media.view.settings.post.id,
                type : 'image'
            },
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).on('select', function() {
            var attachment = cp_uploader.state().get('selection').first().toJSON();
            $('#ct_price_plan3_img_key').val(attachment.url);
        })
        .open();
    });

    $('body').on('click', '.cpt_upload_image_button_plan4', function(e){
        e.preventDefault();
        var button = $(this),
        cp_uploader = wp.media({
            title: 'Custom image',
            library : {
                uploadedTo : wp.media.view.settings.post.id,
                type : 'image'
            },
            button: {
                text: 'Use this image'
            },
            multiple: false
        }).on('select', function() {
            var attachment = cp_uploader.state().get('selection').first().toJSON();
            $('#ct_price_plan4_img_key').val(attachment.url);
        })
        .open();
    });
});

