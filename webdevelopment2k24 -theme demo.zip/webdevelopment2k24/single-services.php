<?php 
get_header(); 
?>
<main id="main">

<!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
    <h2>single-services.php</h2>
    <!-- ======= Blog Single Section ======= -->
    <section id="team" class="team">

      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Team</h2>
          <p>Our hard working team</p>
        </header>
        <div class="row gy-4">
          <?php
            //$dbquery= new wp_query(array('post_type'=>'team','post_status'=>'publish'));?>
          <?php 
            if(have_posts()){
              while (have_posts()) {
                the_post();
              ?>
              <h3><?php echo get_the_title(); ?></h3>
              <h4><?php echo get_the_content(); ?></h4>
          <?php
               }
            }
          ?>
        </div>
      </div>

    </section><!-- End Team Section -->
  </main><!-- End #main -->
<?php 
get_footer(); 
?>