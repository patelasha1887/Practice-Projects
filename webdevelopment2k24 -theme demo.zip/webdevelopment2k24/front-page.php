<?php get_header(); ?>
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center">  
    <div class="container">
      <?php
    $query = new WP_Query( array( 'post_type' => 'banner','posts_per_page' => -1,
        'post_status' => 'publish'));
    if ( $query->have_posts() ) {
      while ( $query->have_posts() ) { 
        $query->the_post();
        wp_nonce_field( 'ct_banner_statuskey', 'ct_banner_statuskey_nonce' );
        $value = get_post_meta( $post->ID, 'ct_banner_statuskey', true );
        if($value=='Active'){
          $postid = get_the_ID();
          $value = get_post_meta( $postid, 'ct_banner_statuskey', true );
          ?> 
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up"><?php echo get_the_title(); ?></h1>
          <h2 data-aos="fade-up" data-aos-delay="400">
            <?php echo get_post_meta($post->ID, 'ct_banner_subtitle_txt_key', true);?> 
          </h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <?php
              $btntxt=get_post_meta($post->ID, 'ct_banner_btn_txt_key', true);
              if(!empty($btntxt)){
                ?>
            <div class="text-center text-lg-start">
              <a href="<?php echo get_post_meta($post->ID, 'ct_banner_btn_link_key', true)?>" class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                <span><?php echo $btntxt; ?></span>
                <i class="bi bi-arrow-right"></i>
              </a>
            </div>
          <?php }?>
          </div>
        </div>
        <div class="col-lg-6 banner-img" data-aos="zoom-out" data-aos-delay="200">
             <?php  get_post_meta($post->ID,"ct_banner_bgimg_key",true); ?>
             <?php echo the_post_thumbnail('banner-image');?>
        </div>
      </div>
      <?php
        }
      }
    }
      ?>
    </div>
  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <h6>front-page.php</h6>
        <div class="row gx-0">
          <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="200">
            <div class="content">
              <h3>Who We Are</h3>
              <h2>Expedita voluptas omnis cupiditate totam eveniet nobis sint iste. Dolores est repellat corrupti reprehenderit.</h2>
              <p>
                Quisquam vel ut sint cum eos hic dolores aperiam. Sed deserunt et. Inventore et et dolor consequatur itaque ut voluptate sed et. Magnam nam ipsum tenetur suscipit voluptatum nam et est corrupti.
              </p>
              <div class="text-center text-lg-start">
                <a href="#" class="btn-read-more d-inline-flex align-items-center justify-content-center align-self-center">
                  <span>Read More</span>
                  <i class="bi bi-arrow-right"></i>
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-6 d-flex align-items-center" data-aos="zoom-out" data-aos-delay="200">
            <img src="<?php echo get_bloginfo('template_url'); ?>/assets/img/about.jpg" class="img-fluid" alt="">
          </div>
        </div>
      </div>
    </section><!-- End About Section -->
    
<!-- services -->
<section id="services" class="services">
  <div class="container" data-aos="fade-up">
   <?php
   $query = new WP_Query( array( 'post_type' => 'services'));
   if( $query->have_posts() ) { 
    while ( $query->have_posts() ) { $query->the_post();
        $the_query = new WP_Query('showposts=1'); 
      wp_nonce_field( 'ct_services_statuskey', 'ct_services_statuskey_nonce');
      $value = get_post_meta(get_the_ID(), 'ct_services_statuskey', true );
      if($value=='Active'){
       $postid = get_the_ID();
       $value = get_post_meta(get_the_ID(), 'ct_services_statuskey', true );
       ?>
       <header class="section-header">
        <h3><?php the_title(); ?></h3>
        <p><?php echo get_post_meta( get_the_ID(), 'ct_services_subtitle_key', true );?></p>
      </header>
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200" >
          <div class="service-box blue">
            <i class="<?php echo get_post_meta( get_the_ID(), 'ct_services_box1_icon_key', true );?> icon"></i>
            <h3><?php echo get_post_meta( get_the_ID(), 'ct_services_box1_title_key', true );?></h3>
            <p><?php echo get_post_meta( get_the_ID(), 'ct_services_box1_shortdesc_key', true );?></p>
            <a href="<?php echo get_post_meta( get_the_ID(), 'ct_services_box1_linkurl_key', true );?>" class="read-more"><span><?php echo get_post_meta( get_the_ID(), 'ct_services_box1_linktext_key', true );?></span> <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300" >
          <div class="service-box orange">
            <i class="<?php echo get_post_meta( get_the_ID(), 'ct_services_box2_icon_key', true );?> icon"></i>
            <h3><?php echo get_post_meta( get_the_ID(), 'ct_services_box2_title_key', true );?></h3>
            <p><?php echo get_post_meta( get_the_ID(), 'ct_services_box2_shortdesc_key', true );?></p>
            <a href="<?php echo get_post_meta( get_the_ID(), 'ct_services_box2_linkurl_key', true );?>" class="read-more"><span><?php echo get_post_meta( get_the_ID(), 'ct_services_box2_linktext_key', true );?></span> <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
          <div class="service-box green">
            <i class="<?php echo get_post_meta( get_the_ID(), 'ct_services_box3_icon_key', true );?> icon"></i>
            <h3><?php echo get_post_meta( get_the_ID(), 'ct_services_box3_title_key', true );?></h3>
            <p><?php echo get_post_meta( get_the_ID(), 'ct_services_box3_shortdesc_key', true );?></p>
            <a href="<?php echo get_post_meta( get_the_ID(), 'ct_services_box3_linkurl_key', true );?>" class="read-more"><span><?php echo get_post_meta( get_the_ID(), 'ct_services_box3_linktext_key', true );?></span> <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
      </div> 
    <?php }wp_reset_postdata();
  }
}
  ?>    
</div>
</section><br>
<!-- end services -->
<!-- ======= Pricing Section ======= -->
<section id="pricing" class="pricing">
  <div class="container" data-aos="fade-up">
    <?php
    $query = new WP_Query( array( 'post_type' => 'price'));
    if( $query->have_posts() ) { 
      while ( $query->have_posts() ) { $query->the_post();
      $the_query = new WP_Query('showposts=1'); 
        wp_nonce_field( 'ct_price_statuskey', 'ct_price_statuskey_nonce');
        $value = get_post_meta( $post->ID, 'ct_price_statuskey', true );
        if($value=='Active'){
          $postid = get_the_ID();
//$value = get_post_meta( $postid, 'ct_price_statuskey', true );
          ?>
          <header class="section-header">
            <h3><?php the_title(); ?></h3>
            <p><?php echo get_post_meta( $postid, 'ct_price_subtitle_key', true );?></p>
          </header>
          <div class="row gy-4" data-aos="fade-left"><?php $plan1_title = get_post_meta( $postid, 'ct_price_plan1_title_key', true );
          if(!empty($plan1_title)){ ?>
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="100">
              <div class="box">
                <h3 style="color: #07d5c0;"><?php echo $plan1_title;?></h3>
                <div class="price"><sup><i class="<?php echo get_post_meta(get_the_ID(), 'ct_price_plan1_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta(get_the_ID(), 'ct_price_plan1_amount_key', true );?><span> / mo</span></div>
                <img src="<?php echo get_post_meta(get_the_ID(), 'ct_price_plan1_img_key', true)?>" class="img-fluid" alt="">
                <ul>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem1_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem2_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem3_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem4_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem5_key', true );?></li>
                </ul>
                <a href="<?php echo get_post_meta( $postid, 'ct_price_plan1_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan1_btntxt_key', true );?></a>
              </div>
            </div>
            <?php 
          }
          ?>
          <?php  $plan2_title = get_post_meta( $postid, 'ct_price_plan2_title_key', true );
          if(!empty($plan2_title)){
            ?>
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="200">
              <div class="box">
                <h3 style="color: #65c600;"><?php echo $plan2_title; ?></h3>
                <div class="price"><sup><i class="<?php echo get_post_meta( $postid, 'ct_price_plan2_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta( $postid, 'ct_price_plan2_amount_key', true );?><span> / mo</span>
                </div>
                <img src="<?php echo get_post_meta($postid, 'ct_price_plan2_img_key', true)?>" class="img-fluid" alt="">
                <ul>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem1_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem2_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem3_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem4_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem5_key', true );?></li>
                </ul>
                <a href="<?php echo get_post_meta( $postid, 'ct_price_plan2_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan2_btntxt_key', true );?></a>
              </div>
            </div>
            <?php 
          }
          ?> 
          <?php  $plan3_title = get_post_meta( $postid, 'ct_price_plan3_title_key', true );
          if(!empty($plan3_title)){
           ?>         
           <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="300">
            <div class="box">
              <h3 style="color: #ff901c;"><?php echo get_post_meta( $postid, 'ct_price_plan3_title_key', true );?></h3>
              <div class="price"><sup><i class="<?php echo get_post_meta( $postid, 'ct_price_plan3_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta( $postid, 'ct_price_plan3_amount_key', true );?><span> / mo</span>
              </div>
              <img src="<?php echo get_post_meta($postid, 'ct_price_plan3_img_key', true)?>" class="img-fluid" alt="">
              <ul>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem1_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem2_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem3_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem4_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem5_key', true );?></li>
              </ul>
              <a href="<?php echo get_post_meta( $postid, 'ct_price_plan3_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan3_btntxt_key', true );?></a>
            </div>
          </div>
          <?php 
        }
        ?>
        <?php $plan4_title = get_post_meta( $postid, 'ct_price_plan4_title_key', true );
        if(!empty($plan4_title)){ ?>
          <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="400">
            <div class="box">
              <h3 style="color: #ff0071;"><?php echo get_post_meta( $postid, 'ct_price_plan4_title_key', true );?></h3>
              <div class="price"><sup><i class="<?php echo get_post_meta( $postid, 'ct_price_plan4_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta( $postid, 'ct_price_plan4_amount_key', true );?><span> / mo</span>
              </div>
              <img src="<?php echo get_post_meta($postid, 'ct_price_plan4_img_key', true)?>" class="img-fluid" alt="">
              <ul>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem1_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem2_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem3_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem4_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem5_key', true );?></li>
              </ul>
              <a href="<?php echo get_post_meta( $postid, 'ct_price_plan4_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan4_btntxt_key', true );?></a>
            </div>
          </div>
          <?php 
        }
        ?>
      </div>
    <?php }wp_reset_postdata();
  }
}
?>
</div>
</section><!-- End Pricing Section -->
    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">
        <header class="section-header">          
          <h2>Portfolio</h2>
          <p>Check our latest work</p>
        </header>
        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <?php
                  $terms = get_terms('portfolio_categories');
                  foreach ($terms as $term) {?>
                    <li data-filter=".<?php echo $term->slug;?>"><?php echo $term->name;?></li>
               <?php   }
              ?>
              <!-- <li data-filter=".filter-app">App</li>
              <li data-filter=".filter-card">Card</li>
              <li data-filter=".filter-web">Web</li> -->
            </ul>
          </div>
        </div>

        <div class="row gy-4 portfolio-container" data-aos="fade-up" data-aos-delay="200">
          <?php
            $args=array(
              'post_type' => 'portfolio',
              'posts_per_page' => 8,
              'post_status' => 'publish'
            );
            $query=new wp_query($args);
            while($query->have_posts()){
              $query->the_post();
              $termsArray = get_the_terms($post->ID,'portfolio_categories');
              $termsSlug = "";
              foreach ($termsArray as $term) {
                $termsSlug.=$term->slug.'';
              }
               ?>
          <div class="col-lg-4 col-md-6 portfolio-item <?php echo $termsSlug;?>">
            <div class="portfolio-wrap">
              <img src="<?php the_post_thumbnail_url();?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><?php echo get_the_title();?></h4>
                <p><?php echo $termsSlug;?>
              </p>
                <div class="portfolio-links">
                  <a href="<?php the_post_thumbnail_url();?>" data-gallery="portfolioGallery" class="portfokio-lightbox" title="App 1"><i class="bi bi-plus"></i></a>
                  <a href="<?php echo get_post_meta(get_the_ID(),'ct_portfolio_url_key',true); ?>" title="More Details"><i class="bi bi-link"></i></a>
                </div>
              </div>
            </div>
          </div>
          <?php    
            }
          ?>
        </div>
      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Testimonials Section ======= -->
    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Testimonials</h2>
          <p>What they are saying about us</p>
        </header>
        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="200">
          <div class="swiper-wrapper">
            <?php
            $query = new WP_Query(array(
            'post_type' => 'testimonials',
            'post_status' => 'publish'
          ));              
          ?>
          <?php 
            if($query->have_posts()){
              while ($query->have_posts()) {
                $query->the_post();
                //get_the_ID()=get_the_ID();
              ?>
            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="stars">
                  <?php
                    $star=get_post_meta(get_the_ID(),"ct_testimonials_rating_key",true);
                    for ($i=0; $i <$star ; $i++) {?> 
                      <i class="bi bi-star-fill"></i>
                  <?php  }
                  ?>
                </div>
                <p> <?php echo get_the_content(); ?>
                </p>
                <div class="profile mt-auto ">
                  <?php 
                  global $post;
                  $image = the_post_thumbnail();
                  ?>
                  <a href="<?php echo get_the_permalink(); ?>">
                    <img src="<?php echo esc_attr( esc_url( $image ) ); ?>" class="testimonial-img" alt="">
                  <h3><?php the_title(); ?></h3>
                  <h4><?php
                echo get_post_meta($postid, 'ct_testimonials_desig_key', true);?></h4>
                </a>
                </div>
              </div>
            </div><!-- End testimonial item -->
            <?php
               }
               
            }wp_reset_postdata();
          ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section><!-- End Testimonials Section --><!-- End Testimonials Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Team</h2>
          <p>Our hard working team</p>
        </header>
        <div class="row gy-4">
          <?php
            $dbquery= new wp_query(array('post_type'=>'team','post_status'=>'publish'));?>
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
              ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <?php the_post_thumbnail('small-image'); ?>
                <div class="social">
                  <a href="<?php the_field('twitter'); ?>"><i class="bi bi-twitter"></i></a>
                  <a href="<?php the_field('facebook'); ?>"><i class="bi bi-facebook"></i></a>
                  <a href="<?php the_field('instagram'); ?>"><i class="bi bi-instagram"></i></a>
                  <a href="<?php the_field('linkedin'); ?>"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
                <span><?php the_field('designation'); ?></span>
                <p><?php the_content(); ?></p>
              </div>
            </div>
          </div>
          <?php
               }
               
            }
          ?>
        </div>
      </div>
    </section><!-- End Team Section -->

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <h2>Our Clients</h2>
          <p>Temporibus omnis officia</p>
        </header>

        <div class="clients-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <?php
            $dbquery= new wp_query(array('post_type'=>'clients','post_status'=>'publish'));?>
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
              ?>
            <div class="swiper-slide"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid" alt=""></div>
            <?php
          }
        }
            ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>

    </section><!-- End Clients Section -->
  <!-- post area -->
  <?php
    $dbquery= new wp_query(array('post_type'=>'post','post_status'=>'publish'));
  ?>
  <!-- ends -->
    <!-- ======= Recent Blog Posts Section ======= -->
    <section id="recent-blog-posts" class="recent-blog-posts">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <h2>Blog</h2>
          <p>Recent posts form our Blog</p>
        </header>

        <div class="row">
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
                get_template_part("template-parts/content",get_post_format());
                
              }
            }
          ?>
        </div>
      </div>
    </section><!-- End Recent Blog Posts Section -->
  </main><!-- End #main -->
<?php get_footer(); ?>
