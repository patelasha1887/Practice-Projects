<?php
function ct_register_banner_post_type() {
$labels = array(
	'name' => __( 'Banners' ),
	'singular_name' => __( 'banner' ),
	'add_new' => __( 'New banner' ),
	'add_new_item' => __( 'Add New banner' ),
	'edit_item' => __( 'Edit banner' ),
	'new_item' => __( 'New banner' ),
	'view_item' => __( 'View banner' ),
	'search_items' => __( 'Search banners' ),
	'featured_image' => __( 'Banner Image' ),
    'set_featured_image' => __( 'Upload Banner Image' ),
     'remove_featured_image' => __( 'Remove Banner Images' ),
	'not_found' =>  __( 'No banner Found' ),
	'not_found_in_trash' => __( 'No banner found in Trash' ),
);
$args = array(
	'labels'             => $labels,
	'description'        => 'Banner custom post type.',
	'public'             => true,
	'publicly_queryable' => true,
	'show_ui'            => true,
	'show_in_menu'       => true,
	'query_var'          => true,
	'rewrite'            => array( 'slug' => 'banner' ),
	'capability_type'    => 'post',
	'has_archive'        => true,
	'hierarchical'       => false,
	'menu_position'      => 20,
	'menu_icon'			=>'dashicons-slides',
	'supports'           => array( 'title','author', 'thumbnail' ),
	'show_in_rest'       => true
);
register_post_type( 'banner', $args );//register banner cpt
}
add_action( 'init', 'ct_register_banner_post_type' );
function ct_register_banner_metabox(){
add_meta_box("ct-banner-id","Set Button ","ct_banner_btn_call","banner","normal","high");
add_meta_box("ct-banner-titleid","Sub Title","ct_banner_subtitle_call","banner","normal","high");
add_meta_box("ct-banner-bgimgid","Banner Background Image ","ct_banner_bgimg_call","banner","side","default");
add_meta_box("ct-banner-status","Banner Status ","ct_banner_status_call","banner","side","default");
}
add_action('add_meta_boxes','ct_register_banner_metabox');
function ct_banner_subtitle_call($post){?>
<table>
    <tr>
    	<td><?php $banner_subtitle_txt=get_post_meta(get_the_ID(),"ct_banner_subtitle_txt_key",true); ?>
    	<input type="text" name="banner_subtitle_txt"  placeholder="Add Sub title" value="<?php echo $banner_subtitle_txt; ?>" size="100%" ></td>
    </tr>
</table>

<?php
}
function ct_save_banner_subtitle_metabox_value($post_id, $post){
$banner_subtitle_txt=isset($_POST['banner_subtitle_txt']) ? $_POST['banner_subtitle_txt'] : "";
update_post_meta($post_id,"ct_banner_subtitle_txt_key",$banner_subtitle_txt);
}
add_action("save_post","ct_save_banner_subtitle_metabox_value",10,2);
//end sub title metabox
function ct_banner_btn_call($post){
?>
<table>
    <tr>
    	
        <td><?php $btn_txt=get_post_meta(get_the_ID(),"ct_banner_btn_txt_key",true); ?><strong> Button Name : </strong></td>
        <td><input type="text" name="banner_btn_txt" value="<?php echo $btn_txt; ?>" placeholder="example" size="30"> </td>
        <td><?php $btn_link=get_post_meta(get_the_ID(),"ct_banner_btn_link_key",true); ?><strong>Button Link :</strong></td>
        <td><input type="url" name="banner_btn_link" value="<?php echo $btn_link; ?>" placeholder="https://example.com" size="30"></td>
    </tr>
</table>
<?php
}

function ct_save_banner_metabox_value($post_id, $post){
$banner_btn_txt=isset($_POST['banner_btn_txt']) ? $_POST['banner_btn_txt'] : "";
$banner_btn_link=isset($_POST['banner_btn_link']) ? $_POST['banner_btn_link'] : "";
update_post_meta($post_id,"ct_banner_btn_txt_key",$banner_btn_txt);
update_post_meta($post_id,"ct_banner_btn_link_key",$banner_btn_link);
}
add_action("save_post","ct_save_banner_metabox_value",10,2);
/*end metabox 2*/
function ct_banner_bgimg_call($post){
	
?>

<table>
	<tr>
		<td>
		<img src="<?php echo $ct_banner_img; ?>" heigth="150px" width="150px"> 		
	</td>
	</tr>
	<tr>
		<td>
			<a href="#" class="cpt_upload_image_button button button-secondary"><?php _e('Upload Image'); ?></a>
		</td>
	</tr>
	<?php $ct_banner_img=get_post_meta(get_the_ID(),"ct_banner_bgimg_key",true);?>
	<tr>
		<td><input type="hidden" name="ct_banner_bgimg_key" id="ct_banner_bgimg_key" value="<?php echo $ct_banner_img; ?>" style="width:250px;" /></td>
	</tr>
	<tr>
		<td>
		<img src="<?php echo $ct_banner_img; ?>" heigth="150px" width="150px"> 		
	</td>
	</tr>
</table>

<?php }
// for feature img required
function ct_save_banner_bgimg_metabox_value($post_id, $post){
	if(!empty($_POST['ct_banner_bgimg_key'])){
		if (array_key_exists('ct_banner_bgimg_key', $_POST)) {
			update_post_meta(
				$post_id,
				'ct_banner_bgimg_key',
				$_POST['ct_banner_bgimg_key']
			);
		}
	}
}
add_action("save_post","ct_save_banner_bgimg_metabox_value",10,2);
/*end bg-img metabox*/

/*banner status is active or not*/
function ct_banner_status_call($post){
wp_nonce_field( 'ct_banner_statuskey', 'ct_banner_statuskey_nonce' );
$value = get_post_meta( get_the_ID(), 'ct_banner_statuskey', true ); 
?>
<table>
	<tr>
		<td ><input type="radio" class="radioBtnClass" name="statusbtn" id="active" value="Active" <?php checked( $value,'Active'); ?> > <label for="active" class="rlable">Active</label>
			<input type="radio" class="radioBtnClass" name="statusbtn" id="deactive" value="Deactive" <?php checked( $value,'Deactive'); ?> > <label for="deactive" >Deactive</label>
		</td>
	</tr>
	<tr>
		<td >
			<label for="statusbtn" class="error" style="display: none;"></label>
		</td>		
	</tr>
</table>
<?php
}
function ct_banner_status_save_data( $post_id ) {
    /*
     * We need to verify this came from our screen and with proper authorization,
     * because the save_post action can be triggered at other times.
     */
    // Check if our nonce is set.
    if ( !isset( $_POST['ct_banner_statuskey_nonce'] ) ) {
    	return;
    }
    // Verify that the nonce is valid.
    if ( !wp_verify_nonce( $_POST['ct_banner_statuskey_nonce'], 'ct_banner_statuskey' ) ) {
    	return;
    }
    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
    	return;
    }
    // Check the user's permissions.
    if ( !current_user_can( 'edit_post', $post_id ) ) {
    	return;
    }
    // Sanitize user input.
    $new_meta_value = ( isset( $_POST['statusbtn'] ) ? sanitize_html_class( $_POST['statusbtn'] ) : '' );
    global $wpdb;
    $meta_key = 'ct_banner_statuskey';
    	// $data = $wpdb->get_results($wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type = 'banner'") , ARRAY_N  );
    $data = $wpdb->get_results($wpdb->prepare( "SELECT meta_value, post_id FROM $wpdb->postmeta WHERE meta_value = 'Active'", $meta_key) , ARRAY_N  );
    
    if($new_meta_value == 'Active') {
    	foreach ($data as $key => $postid) {
    		echo update_post_meta( $postid[1], 'ct_banner_statuskey', 'Deactive' );
    	}
    }
    update_post_meta( $post_id, 'ct_banner_statuskey', $new_meta_value );
}
add_action( 'save_post', 'ct_banner_status_save_data' );

//**** create custom column in cpt table***

function ct_banner_custom_columns($columns){
$columns= array(
	"cb"=>"<input type='checkbox' />",
	"banner_img"=>"Banner Image",
	"title"=> "Banner Title",
	"status"=>"Status",
	"date"=>"Date"
);
return $columns;
}
add_action("manage_banner_posts_columns","ct_banner_custom_columns");

function ct_banner_custom_columns_data($column, $post_id){
switch ($column) {
	case 'banner_img':
	$post_thumbnail_id = get_post_thumbnail_id($post_id);
	if ($post_thumbnail_id) {
		$post_thumbnail_img = wp_get_attachment_image_src( $post_thumbnail_id, 'thumbnail' );
		echo '<img width="100" src="' . $post_thumbnail_img[0] . '" />';
	}
	break;
	case 'status':
	wp_nonce_field( 'ct_banner_statuskey', 'ct_banner_statuskey_nonce' );
	$value = get_post_meta( $post_id, 'ct_banner_statuskey', true ); ?>
	<label for="column_radio" id="radio_lbl"><?php echo $value; ?></label>     
<?php }
}
add_action("manage_banner_posts_custom_column","ct_banner_custom_columns_data",10,2);
// code for column sortable ac/dc
function ct_banner_sortable_column(){
$column['title']='title';
$column['banner_img']='banner_img';
$column['status']='status';
$column['date']='date';
return $column;
}
add_action("manage_edit-banner_sortable_columns","ct_banner_sortable_column");

// for shortcode notice
function general_banner_admin_notice(){
    global $typenow;
    if ( $typenow == 'banner' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Use <strong> [banner] </strong> shortcode for display this Custom Post Type.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_banner_admin_notice');

//shortcode
function display_banner_shortcode(){
	?>
<!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center">  
    <div class="container">
      <?php
    $query = new WP_Query( array( 'post_type' => 'banner','posts_per_page' => -1,
        'post_status' => 'publish'));
    if ( $query->have_posts() ) {
      while ( $query->have_posts() ) { 
        $query->the_post();
        wp_nonce_field( 'ct_banner_statuskey', 'ct_banner_statuskey_nonce' );
        $value = get_post_meta( get_the_ID(), 'ct_banner_statuskey', true );
        if($value=='Active'){
          $postid = get_the_ID();
          $value = get_post_meta( get_the_ID(), 'ct_banner_statuskey', true );
          ?> 
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up"><?php echo get_the_title(); ?></h1>
          <h2 data-aos="fade-up" data-aos-delay="400">
            <?php echo get_post_meta(get_the_ID(), 'ct_banner_subtitle_txt_key', true);?> 
          </h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <?php
              $btntxt=get_post_meta(get_the_ID(), 'ct_banner_btn_txt_key', true);
              if(!empty($btntxt)){
                ?>
            <div class="text-center text-lg-start">
              <a href="<?php echo get_post_meta(get_the_ID(), 'ct_banner_btn_link_key', true)?>" class="btn-get-started scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                <span><?php echo $btntxt; ?></span>
                <i class="bi bi-arrow-right"></i>
              </a>
            </div>
          <?php }?>
          </div>
        </div>
        <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
              <?php  get_post_meta(get_the_ID(),"ct_banner_bgimg_key",true); ?>
             <?php echo the_post_thumbnail('banner-image');?>
            </div>
      </div>
      <?php
        }
      }
    }
      ?>
    </div>
  </section><!-- End Hero -->
<?php
}
add_shortcode( 'banner','display_banner_shortcode');
?>