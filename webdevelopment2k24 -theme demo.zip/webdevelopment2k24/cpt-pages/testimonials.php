
<?php
function register_custom_posttype_testimonials(){
	$args=array(
		'labels'=>array(
			'name'=>__('Testimonials'),
			'singular_name'=>__('testimonials')),
		'public'=>true,
		"show_in_nav_menu"=>true,
		'has_archive'=>false,
    'menu_icon'=>'dashicons-testimonial',
		'supports'=>array('title','editor','thumbnail')
	);
	register_post_type('testimonials',$args);
}
//attach with action hook
add_action("init","register_custom_posttype_testimonials");

function ct_register_testimonials_metabox(){
	add_meta_box("ct-testimonials-id","testimonials Section","ct_testimonials_call","testimonials","normal","high");
// add_meta_box("ct-testimonials-status","Status ","ct_testimonials_status_call","testimonials","side","default");
}
add_action('add_meta_boxes','ct_register_testimonials_metabox');
function ct_testimonials_call($post){?>
	<table>
		<tr>
			<td><label>Designation :</label></td>
		<td><?php $ct_testimonials_desig= get_post_meta(get_the_ID(),"ct_testimonials_desig_key",true); ?>
		<input type="text" name="ct_testimonials_desig" value="<?php echo $ct_testimonials_desig; ?>" placeholder="designation" size="40">
		</td>
		<td> &nbsp;</td>
		<td><label>Rating:</label></td>
		<td><?php $ct_testimonials_rating= get_post_meta(get_the_ID(),"ct_testimonials_rating_key",true); ?>
		<input type="number" name="ct_testimonials_rating" value="<?php echo $ct_testimonials_rating; ?>" placeholder="Rating between 1 to 5" max="5">
		<?php 
			$i;
			for($i=0;$i<$ct_testimonials_rating;$i++){?>
			<i class="fa fa-star" aria-hidden="true" style="color: #ffc107;"></i>
		<?php }
		?>
		</td>
		
	</tr>
</table>
<?php		
}
function ct_save_testimonials_section_call($post_id, $post){
	$ct_testimonials_desig= isset($_POST['ct_testimonials_desig']) ? $_POST['ct_testimonials_desig']:"";
	update_post_meta($post_id,"ct_testimonials_desig_key",$ct_testimonials_desig);

	$ct_testimonials_rating=isset($_POST['ct_testimonials_rating']) ? $_POST['ct_testimonials_rating'] : "";
update_post_meta($post_id,"ct_testimonials_rating_key",$ct_testimonials_rating);

}
add_action("save_post","ct_save_testimonials_section_call",10,2);
// for shortcode notice
function general_testimonials_admin_notice(){
    global $typenow;
    if ( $typenow == 'testimonials' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Use <strong> [testimonials] </strong> shortcode for display this Custom Post Type.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_testimonials_admin_notice');
// shortcode
add_shortcode( 'testimonials', 'display_testimonials_shortcode' );
function display_testimonials_shortcode(){ ?>
	<!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Testimonials</h2>
          <p>What they are saying about us</p>
        </header>
        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="200">
          <div class="swiper-wrapper">
            <?php
            $query = new WP_Query(array(
            'post_type' => 'testimonials',
            'post_status' => 'publish'
          ));              
          ?>
          <?php 
            if($query->have_posts()){
              while ($query->have_posts()) {
                $query->the_post();
                $postid=get_the_ID();
              ?>
            <div class="swiper-slide">
              <div class="testimonial-item">
                <div class="stars">
                  <?php
                    $star=get_post_meta($postid,"ct_testimonials_rating_key",true);
                    for ($i=0; $i <$star ; $i++) {?> 
                      <i class="bi bi-star-fill"></i>
                  <?php  }
                  ?>
                </div>
                <p> <?php echo get_the_content(); ?>
                </p>
                <div class="profile mt-auto ">
                  <?php 
                  global $post;
                  $image = the_post_thumbnail();
                  ?>
                  <a href="<?php echo get_the_permalink(); ?>">
                    <img src="<?php echo esc_attr( esc_url( $image ) ); ?>" class="testimonial-img" alt="">
                  <h3><?php the_title(); ?></h3>
                  <h4><?php
                echo get_post_meta($postid, 'ct_testimonials_desig_key', true);?></h4>
                </a>
                </div>
              </div>
            </div><!-- End testimonial item -->
            <?php
               }
               
            }wp_reset_postdata();
          ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </section><!-- End Testimonials Section -->
<?php 
}	
?>