<?php 
function ct_register_clients_post_type() {
	$labels = array(
		'name' => __( 'Clients' ),
		'singular_name' => __('clients'),
		'edit_item' => __( 'Edit '),
		'new_item' => __( 'New Item'),
		'view_item' => __( 'View ' ),
		'search_items' => __( 'Search' ),
		'not_found' =>  __( 'No  Found' ),
		'not_found_in_trash' => __( 'No  found in Trash' ),
	);
	$args = array(
		'labels'             => $labels,
		'description'        => 'clients custom post type.',
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'clients' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'menu_icon' 		 =>'dashicons-image-filter',
		'supports'           => array( 'title','thumbnail'),
	//'taxonomies'         => array( 'category',),
		'show_in_rest'       => true
	);
register_post_type( 'clients', $args );//register clients cpt
}
add_action( 'init', 'ct_register_clients_post_type' );
function general_clients_admin_notice(){
    global $typenow;
    if ( $typenow == 'clients' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Use <strong> [clients] </strong> shortcode for display this Custom Post Type.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_clients_admin_notice');
//shortcode 
function display_clients_shortcode(){ ?>
<!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <h2>Our Clients</h2>
          <p>Temporibus omnis officia</p>
        </header>

        <div class="clients-slider swiper">
          <div class="swiper-wrapper align-items-center">
            <?php
            $dbquery= new wp_query(array('post_type'=>'clients','post_status'=>'publish'));?>
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
              ?>
            <div class="swiper-slide"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid" alt=""></div>
            <?php
          }
        }
            ?>
          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>

    </section><!-- End Clients Section -->	

<?php
}
add_shortcode( 'clients', 'display_clients_shortcode' );

?>