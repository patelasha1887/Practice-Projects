<?php
function register_custom_posttype_services(){
	$args=array(
			'labels'=>array(
			'name'=>__('Services'),
			'singular_name'=>__('services')),
			'public'=>true,
			"show_in_nav_menu"=>true,
			'has_archive'=>false,
			'menu_icon'=>'dashicons-admin-generic',
			'supports'=>array('title','editor')
	);
	register_post_type('services',$args);
}
//attach with action hook
add_action("init","register_custom_posttype_services");
function ct_register_services_metabox(){
  add_meta_box("ct-services-subtitle-id","Sub Title ","ct_services_subtitle_call","services","normal","high");
  add_meta_box("ct-services-box1id","Services Box 1","ct_services_box1_call","services","normal","high");
  add_meta_box("ct-services-box2id","Services Box 2","ct_services_box2_call","services","normal","high");
  add_meta_box("ct-services-box3id","Services Box 3","ct_services_box3_call","services","normal","high");
  add_meta_box("ct-services-status","Status","ct_services_status_call","services","side","default");
}
add_action('add_meta_boxes','ct_register_services_metabox');
function ct_services_box1_call($post){?>
  <table>
    <tr>
      <td><?php $services_box1_icon= get_post_meta(get_the_ID(),"ct_services_box1_icon_key",true); ?>
      <input type="text" name="services_box1_icon" value="<?php echo $services_box1_icon; ?>" placeholder="icon" size="30">
      </td>
      <td><?php $services_box1_title= get_post_meta(get_the_ID(),"ct_services_box1_title_key",true); ?>
      <input type="text" name="services_box1_title" value="<?php echo $services_box1_title; ?>" placeholder="title" size="30">
      </td>
      <td><?php $services_box1_shortdesc= get_post_meta(get_the_ID(),"ct_services_box1_shortdesc_key",true); ?>
      <input type="text" name="services_box1_shortdesc" value="<?php echo $services_box1_shortdesc; ?>" placeholder="description" size="30">
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td><?php $services_box1_linktext= get_post_meta(get_the_ID(),"ct_services_box1_linktext_key",true); ?>
      <input type="text" name="services_box1_linktext" value="<?php echo $services_box1_linktext; ?>" placeholder="link text" size="30">
      </td>
      <td><?php $services_box1_linkurl= get_post_meta(get_the_ID(),"ct_services_box1_linkurl_key",true); ?>
      <input type="url" name="services_box1_linkurl" value="<?php echo $services_box1_linkurl; ?>" placeholder="link url" size="30">
      </td>
    </tr>
  </table>
  <?php
}
function ct_save_services_box1_metabox_value($post_id, $post){
  $services_box1_icon=isset($_POST['services_box1_icon']) ? $_POST['services_box1_icon'] : "";
  update_post_meta($post_id,"ct_services_box1_icon_key",$services_box1_icon);
  $services_box1_title=isset($_POST['services_box1_title']) ? $_POST['services_box1_title'] : "";
  update_post_meta($post_id,"ct_services_box1_title_key",$services_box1_title);

  $services_box1_shortdesc=isset($_POST['services_box1_shortdesc']) ? $_POST['services_box1_shortdesc'] : "";
  update_post_meta($post_id,"ct_services_box1_shortdesc_key",$services_box1_shortdesc);

  $services_box1_linktext=isset($_POST['services_box1_linktext']) ? $_POST['services_box1_linktext'] : "";
  update_post_meta($post_id,"ct_services_box1_linktext_key",$services_box1_linktext);
  $services_box1_linkurl=isset($_POST['services_box1_linkurl']) ? $_POST['services_box1_linkurl'] : "";
  update_post_meta($post_id,"ct_services_box1_linkurl_key",$services_box1_linkurl);     
}
add_action("save_post","ct_save_services_box1_metabox_value",10,2);
function ct_services_box2_call($post){?>
  <table>
    <tr>
      <td><?php $services_box2_icon= get_post_meta(get_the_ID(),"ct_services_box2_icon_key",true); ?>
      <input type="text" name="services_box2_icon" value="<?php echo $services_box2_icon; ?>" placeholder="icon" size="30">
      </td>
      <td><?php $services_box2_title= get_post_meta(get_the_ID(),"ct_services_box2_title_key",true); ?>
      <input type="text" name="services_box2_title" value="<?php echo $services_box2_title; ?>" placeholder="title" size="30">
      </td>
      <td><?php $services_box2_shortdesc= get_post_meta(get_the_ID(),"ct_services_box2_shortdesc_key",true); ?>
      <input type="text" name="services_box2_shortdesc" value="<?php echo $services_box2_shortdesc; ?>" placeholder="description" size="30">
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td><?php $services_box2_linktext= get_post_meta(get_the_ID(),"ct_services_box2_linktext_key",true); ?>
      <input type="text" name="services_box2_linktext" value="<?php echo $services_box2_linktext; ?>" placeholder="link text" size="30">
      </td>
      <td><?php $services_box2_linkurl= get_post_meta(get_the_ID(),"ct_services_box2_linkurl_key",true); ?>
      <input type="url" name="services_box2_linkurl" value="<?php echo $services_box2_linkurl; ?>" placeholder="link url" size="30">
      </td>
    </tr>
  </table>
  <?php
}
function ct_save_services_box2_metabox_value($post_id, $post){
  $services_box2_icon=isset($_POST['services_box2_icon']) ? $_POST['services_box2_icon'] : "";
  update_post_meta($post_id,"ct_services_box2_icon_key",$services_box2_icon);
  $services_box2_title=isset($_POST['services_box2_title']) ? $_POST['services_box2_title'] : "";
  update_post_meta($post_id,"ct_services_box2_title_key",$services_box2_title);

  $services_box2_shortdesc=isset($_POST['services_box2_shortdesc']) ? $_POST['services_box2_shortdesc'] : "";
  update_post_meta($post_id,"ct_services_box2_shortdesc_key",$services_box2_shortdesc);

  $services_box2_linktext=isset($_POST['services_box2_linktext']) ? $_POST['services_box2_linktext'] : "";
  update_post_meta($post_id,"ct_services_box2_linktext_key",$services_box2_linktext);
  $services_box2_linkurl=isset($_POST['services_box2_linkurl']) ? $_POST['services_box2_linkurl'] : "";
  update_post_meta($post_id,"ct_services_box2_linkurl_key",$services_box2_linkurl);     
}
add_action("save_post","ct_save_services_box2_metabox_value",10,2);
function ct_services_box3_call($post){?>
  <table>
    <tr>
      <td><?php $services_box3_icon= get_post_meta(get_the_ID(),"ct_services_box3_icon_key",true); ?>
      <input type="text" name="services_box3_icon" value="<?php echo $services_box3_icon; ?>" placeholder="icon" size="30">
      </td>
      <td><?php $services_box3_title= get_post_meta(get_the_ID(),"ct_services_box3_title_key",true); ?>
      <input type="text" name="services_box3_title" value="<?php echo $services_box3_title; ?>" placeholder="title" size="30">
      </td>
      <td><?php $services_box3_shortdesc= get_post_meta(get_the_ID(),"ct_services_box3_shortdesc_key",true); ?>
      <input type="text" name="services_box3_shortdesc" value="<?php echo $services_box3_shortdesc; ?>" placeholder="description" size="30">
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td><?php $services_box3_linktext= get_post_meta(get_the_ID(),"ct_services_box3_linktext_key",true); ?>
      <input type="text" name="services_box3_linktext" value="<?php echo $services_box3_linktext; ?>" placeholder="link text" size="30">
      </td>
      <td><?php $services_box3_linkurl= get_post_meta(get_the_ID(),"ct_services_box3_linkurl_key",true); ?>
      <input type="url" name="services_box3_linkurl" value="<?php echo $services_box3_linkurl; ?>" placeholder="link url" size="30">
      </td>
    </tr>
  </table>
  <?php
}
function ct_save_services_box3_metabox_value($post_id, $post){
  $services_box3_icon=isset($_POST['services_box3_icon']) ? $_POST['services_box3_icon'] : "";
  update_post_meta($post_id,"ct_services_box3_icon_key",$services_box3_icon);
  $services_box3_title=isset($_POST['services_box3_title']) ? $_POST['services_box3_title'] : "";
  update_post_meta($post_id,"ct_services_box3_title_key",$services_box3_title);

  $services_box3_shortdesc=isset($_POST['services_box3_shortdesc']) ? $_POST['services_box3_shortdesc'] : "";
  update_post_meta($post_id,"ct_services_box3_shortdesc_key",$services_box3_shortdesc);

  $services_box3_linktext=isset($_POST['services_box3_linktext']) ? $_POST['services_box3_linktext'] : "";
  update_post_meta($post_id,"ct_services_box3_linktext_key",$services_box3_linktext);
  $services_box3_linkurl=isset($_POST['services_box3_linkurl']) ? $_POST['services_box3_linkurl'] : "";
  update_post_meta($post_id,"ct_services_box3_linkurl_key",$services_box3_linkurl);     
}
add_action("save_post","ct_save_services_box3_metabox_value",10,2);

function ct_services_subtitle_call($post){?>
  <table>
  <tr>
    <td><?php $services_subtitle= get_post_meta(get_the_ID(),"ct_services_subtitle_key",true); ?>
    <input type="text" name="services_subtitle" value="<?php echo $services_subtitle; ?>" placeholder="service sub-title" size="100%">
    </td>     
  </tr>
  </table>
<?php
}

function ct_save_services_subtitle_metabox_value($post_id, $post){
  $services_subtitle=isset($_POST['services_subtitle']) ? $_POST['services_subtitle'] : "";
  update_post_meta($post_id,"ct_services_subtitle_key",$services_subtitle);
}
add_action("save_post","ct_save_services_subtitle_metabox_value",10,2);
function ct_services_status_call($post){
 wp_nonce_field( 'ct_services_statuskey', 'ct_services_statuskey_nonce' );
 $value = get_post_meta( get_the_ID(), 'ct_services_statuskey', true ); 
 ?>
 <table class="tableclass">
  <tr>
    <td ><input type="radio" class="radioBtnClass" name="statusbtn" id="active" value="Active" <?php checked( $value, 'Active' ); ?> > <label for="active" class="rlable">Active</label>
      <input type="radio" class="radioBtnClass" name="statusbtn" id="deactive" value="Deactive" <?php checked( $value, 'Deactive' ); ?> > <label for="deactive" >Deactive</label>
    </td>
  </tr>
    <tr>
    <td >
      <label for="statusbtn" class="error" style="display: none;"></label>
    </td>   
  </tr>
 </table>
<?php
}
function ct_save_services_status_metabox_value($post_id, $post){
  if ( !isset( $_POST['ct_services_statuskey_nonce'] ) ) {
    return;
  }
        // Verify that the nonce is valid.
  if ( !wp_verify_nonce( $_POST['ct_services_statuskey_nonce'], 'ct_services_statuskey' ) ) {
    return;
  }
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
    return;
  }
        // Check the user's permissions.
  if ( !current_user_can( 'edit_post', $post_id ) ) {
    return;
  }
        // Sanitize user input.
  $new_meta_value = ( isset( $_POST['statusbtn'] ) ? sanitize_html_class( $_POST['statusbtn'] ) : '' );
  global $wpdb;
  $meta_key = 'ct_services_statuskey';
  $data = $wpdb->get_results($wpdb->prepare( "SELECT meta_value, post_id FROM $wpdb->postmeta WHERE meta_value = 'Active'", $meta_key) , ARRAY_N  );
  if($new_meta_value == 'Active') {
    foreach ($data as $key => $postid) {
      echo update_post_meta( $postid[1], 'ct_services_statuskey', 'Deactive' );
    }
  }
  update_post_meta( $post_id, 'ct_services_statuskey', $new_meta_value );
}
add_action("save_post","ct_save_services_status_metabox_value",10,2);
function ct_services_custom_columns($columns){// create custom column in cpt table
  $columns= array(
    "cb"=>"<input type='checkbox' />",
    "title"=> "services Title",
    "status"=>"Status",
    "author"=>"Author",
    "date"=>"Date"
  );
  return $columns;
}
add_action("manage_services_posts_columns","ct_services_custom_columns");
function ct_services_custom_columns_data($column, $post_id){
  switch ($column) {
    case 'status':
    wp_nonce_field( 'ct_services_statuskey', 'ct_services_statuskey_nonce' );
    $value = get_post_meta( $post_id, 'ct_services_statuskey', true ); ?>
    <label for="column_radio" id="radio_lbl"><?php echo $value; ?></label>          
  <?php }
}
add_action("manage_services_posts_custom_column","ct_services_custom_columns_data",10,2);
add_action("manage_edit-services_sortable_columns","ct_services_sortable_column");
function ct_services_sortable_column(){
  $column['title']='title';
  $column['status']='status';
  $column['author']='author';
  $column['date']='date';
  return $column;
}
// for shortcode notice
function general_services_admin_notice(){
    global $typenow;
    if ( $typenow == 'services' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Use <strong> [services] </strong> shortcode for display this Custom Post Type.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_services_admin_notice');
//******** shortcode *********
function display_services_shortcode(){ ?>
<!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <p>Services</p>
        </header>       
        <div class="row gy-4">
          <?php
            $dbquery= new wp_query(array('post_type'=>'services','post_status'=>'publish'));?>
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
              ?>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="service-box blue">
              <i class="<?php echo get_post_meta(get_the_ID(), 'ct_services_box1_icon_key', true );?> icon"></i>
              <h3><?php echo get_post_meta(get_the_ID(), 'ct_services_box1_title_key', true );?></h3>
              <p><?php echo get_post_meta(get_the_ID(), 'ct_services_box1_shortdesc_key', true );?></p>
              <a href="<?php echo get_post_meta(get_the_ID(), 'ct_services_box1_linkurl_key', true );?>" class="read-more"><span>Read More</span> <i class="bi bi-arrow-right"></i></a>
            </div>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300" >
          <div class="service-box orange">
            <i class="<?php echo get_post_meta(get_the_ID(), 'ct_services_box2_icon_key', true );?> icon"></i>
            <h3><?php echo get_post_meta(get_the_ID(), 'ct_services_box2_title_key', true );?></h3>
            <p><?php echo get_post_meta(get_the_ID(), 'ct_services_box2_shortdesc_key', true );?></p>
            <a href="<?php echo get_post_meta(get_the_ID(), 'ct_services_box2_linkurl_key', true );?>" class="read-more"><span><?php echo get_post_meta(get_the_ID(), 'ct_services_box2_linktext_key', true );?></span> <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
        <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
          <div class="service-box green">
            <i class="<?php echo get_post_meta(get_the_ID(), 'ct_services_box3_icon_key', true );?> icon"></i>
            <h3><?php echo get_post_meta(get_the_ID(), 'ct_services_box3_title_key', true );?></h3>
            <p><?php echo get_post_meta(get_the_ID(), 'ct_services_box3_shortdesc_key', true );?></p>
            <a href="<?php echo get_post_meta(get_the_ID(), 'ct_services_box3_linkurl_key', true );?>" class="read-more"><span><?php echo get_post_meta(get_the_ID(), 'ct_services_box3_linktext_key', true );?></span> <i class="bi bi-arrow-right"></i></a>
          </div>
        </div>
          <?php
               }
            }
          ?>
        </div>
      </div>
    </section><!-- End Services Section -->

<?php 
}
add_shortcode( 'services', 'display_services_shortcode' );

?>