<?php
function register_custom_posttype_team(){
	$args=array(
		'labels'=>array(
			'name'=>__('Our Team'),
			'singular_name'=>__('team')),
		'public'=>true,
		"show_in_nav_menu"=>true,
		'has_archive'=>false,
    'menu_icon'=>'dashicons-groups',
		'supports'=>array('title','editor','thumbnail')
	);
	register_post_type('team',$args);
}
//attach with action hook
add_action("init","register_custom_posttype_team");
// for shortcode notice
function general_team_admin_notice(){
    global $typenow;
    if ( $typenow == 'team' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Use <strong> [team] </strong> shortcode for display this Custom Post Type.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_team_admin_notice');
//shortcode 
add_shortcode( 'team', 'display_custom_post_type' );
function display_custom_post_type(){?>
<!-- ======= Team Section ======= -->
    <section id="team" class="team">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Team</h2>
          <p>Our hard working team</p>
        </header>
        <div class="row gy-4">
          <?php
            $dbquery= new wp_query(array('post_type'=>'team','post_status'=>'publish'));?>
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
              ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <?php the_post_thumbnail('small-image'); ?>
                <div class="social">
                  <a href="<?php the_field('twitter'); ?>"><i class="bi bi-twitter"></i></a>
                  <a href="<?php the_field('facebook'); ?>"><i class="bi bi-facebook"></i></a>
                  <a href="<?php the_field('instagram'); ?>"><i class="bi bi-instagram"></i></a>
                  <a href="<?php the_field('linkedin'); ?>"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
                <span><?php the_field('designation'); ?></span>
                <p><?php the_content(); ?></p>
              </div>
            </div>
          </div>
          <?php
               }
               
            }
          ?>
        </div>
      </div>
    </section><!-- End Team Section -->
<?php 
}
?>