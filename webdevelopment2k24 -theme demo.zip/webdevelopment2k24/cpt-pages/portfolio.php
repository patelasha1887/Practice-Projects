<?php
function ct_register_portfolio_post_type() {
	$labels = array(
		'name' => __( 'Portfolio' ),
		'singular_name' => __('portfolio'),
		'add_new' => _x('Add Portfolio','','your_text_domain'),
		'add_new_item' => __('Add New Portfolio','your_text_domain'),
		'edit_item' => __( 'Edit Portfolio','your_text_domain'),
		'new_item' => __( 'New Portfolio','your_text_domain'),
		'all_items' => __( 'All Portfolios','your_text_domain'),
		'view_item' => __( 'View Portfolios','your_text_domain'),
		'search_items' => __( 'Search Portfolio','your_text_domain'),
		'not_found' =>  __( 'No Portfolio Found','your_text_domain'),
		'not_found_in_trash' => __( 'No Portfolios on Trash','your_text_domain'),
		'parent_item_colon'=>'',
		'menu_name'=>__('portfolio','your_text_domain')
	);
	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'portfolio' ),
		'capability_type'    => 'page',
		'has_archive'        => true,
		'hierarchical'       => true,
		'menu_position'      => null,
		'menu_icon' 		 =>'dashicons-portfolio',
		'supports'           => array( 'title','thumbnail'),
	//'taxonomies'         => array( 'category',),
		'show_in_rest'       => true
	);
register_post_type( 'portfolio', $args );//register portfolio cpt
}
add_action( 'init', 'ct_register_portfolio_post_type' );
function create_portfolio_taxonomies() {
	$labels = array(
		'name'              => _x( 'Categories', 'taxonomy general name' ),
		'singular_name'     => _x( 'Category', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Categories' ),
		'popular_items'		=> __('More Used'),
		'all_items'         => __( 'All Categories' ),
		'parent_item'       => null,
		'parent_item_colon' => null,
		'edit_item'         => __( 'Edit Category' ),
		'update_item'       => __( 'Update Category' ),
		'add_new_item'      => __( 'Add New Category' ),
		'new_item_name'     => __( 'New Category Name' ),
		'menu_name'         => __( 'Categories' ),
	);
	$args = array(
    'hierarchical'      => true, // Set this to 'false' for non-hierarchical taxonomy (like tags)
    'labels'            => $labels,
    'singular_label'	=>'portfolio_category',
    'all_items'			=>'Category',
    'query_var'         => true,
    'rewrite'           => array( 'slug' => 'categories' ),
);
register_taxonomy( 'portfolio_categories', array( 'portfolio' ), $args );
}
add_action( 'init', 'create_portfolio_taxonomies', 0 );

// add metabox
function ct_register_portfolio_metabox(){
	add_meta_box("ct-portfolio-id","portfolio Section","ct_portfolio_metabox_section","portfolio","normal","high");
}
add_action('add_meta_boxes','ct_register_portfolio_metabox');

function ct_portfolio_metabox_section($post){?>
<table>
		<tr>
			<td><?php $ct_portfolio_url= get_post_meta(get_the_ID(),"ct_portfolio_url_key",true); ?>
			<input type="text" name="ct_portfolio_url" value="<?php echo $ct_portfolio_url; ?>" placeholder="portfolio link" size="40">
		</td>
	</tr>
</table>
<?php 
}
function ct_save_portfolio_metabox_section($post_id,$post){
	$ct_portfolio_url=isset($_POST['ct_portfolio_url']) ? $_POST['ct_portfolio_url'] : "";
	update_post_meta($post_id,"ct_portfolio_url_key",$ct_portfolio_url);
}
add_action("save_post","ct_save_portfolio_metabox_section",10,2);
// for shortcode notice
function general_portfolio_admin_notice(){
    global $typenow;
    if ( $typenow == 'portfolio' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Use <strong> [portfolio] </strong> shortcode for display this Custom Post Type.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_portfolio_admin_notice');
//shortcode
add_shortcode( 'portfolio', 'display_portfolio_shortcode' );
function display_portfolio_shortcode(){ ?>
	<!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">
        <header class="section-header">          
          <h2>Portfolio</h2>
          <p>Check our latest work</p>
        </header>
        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <?php
                  $terms = get_terms('portfolio_categories');
                  foreach ($terms as $term) {?>
                    <li data-filter=".<?php echo $term->slug;?>"><?php echo $term->name;?></li>
               <?php   }
              ?>
              <!-- <li data-filter=".filter-app">App</li>
              <li data-filter=".filter-card">Card</li>
              <li data-filter=".filter-web">Web</li> -->
            </ul>
          </div>
        </div>
        <div class="row gy-4 portfolio-container" data-aos="fade-up" data-aos-delay="200">
          <?php
            $args=array(
              'post_type' => 'portfolio',
              'posts_per_page' => 8,
              'post_status' => 'publish'
            );
            $query=new wp_query($args);
            while($query->have_posts()){
              $query->the_post();
              $termsArray = get_the_terms($post->ID,'portfolio_categories');
              $termsSlug = "";
              foreach ($termsArray as $term) {
                $termsSlug.=$term->slug.'';
              }
               ?>
          <div class="col-lg-4 col-md-6 portfolio-item <?php echo $termsSlug;?>">
            <div class="portfolio-wrap">
              <img src="<?php the_post_thumbnail_url();?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><?php echo get_the_title();?></h4>
                <p><?php echo $termsSlug;?>
              </p>
                <div class="portfolio-links">
                  <a href="<?php the_post_thumbnail_url();?>" data-gallery="portfolioGallery" class="portfokio-lightbox" title="App 1"><i class="bi bi-plus"></i></a>
                  <a href="<?php echo get_post_meta(get_the_ID(),'ct_portfolio_url_key',true); ?>" title="More Details"><i class="bi bi-link"></i></a>
                </div>
              </div>
            </div>
          </div>
          <?php    
            }
          ?>
        </div>
      </div>
    </section><!-- End Portfolio Section -->

<?php 
}
?>