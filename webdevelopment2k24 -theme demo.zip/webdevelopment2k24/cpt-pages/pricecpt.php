<?php
function ct_register_price_post_type() {
	$labels = array(
		'name' => __( 'Pricing Plans' ),
		'singular_name' => __('price'),
		'edit_item' => __( 'Edit '),
		'new_item' => __( 'New Item'),
		'view_item' => __( 'View ' ),
		'search_items' => __( 'Search' ),
		'not_found' =>  __( 'No  Found' ),
		'not_found_in_trash' => __( 'No  found in Trash' ),
	);
	$args = array(
		'labels'             => $labels,
		'description'        => 'price custom post type.',
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'price' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'menu_icon' 		 =>'dashicons-menu-alt2',
		'supports'           => array( 'title', 'author'),
		'show_in_rest'       => true,
		'map_meta_cap'        => true,
		// 'capabilities' => array(
		// 	'create_posts' => 'do_not_allow'
		// ),
	);
 register_post_type( 'price', $args );//register price cpt
}
add_action( 'init', 'ct_register_price_post_type' );
function disable_new_price_posts() {
// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=price'][10]);
// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'price') {
		echo '<style type="text/css">
    #favorite-actions, .add-new-h2, .tablenav { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_new_price_posts');
function ct_register_price_metabox(){
	add_meta_box("ct-price-subtitle-id","Sub Title ","ct_price_subtitle_call","price","normal","high");
	add_meta_box("ct-price-plan1id","Plan 1","ct_price_plan1_call","price","normal","high");
	add_meta_box("ct-price-plan2id","Plan 2","ct_price_plan2_call","price","normal","high");
	add_meta_box("ct-price-plan3id","Plan 3","ct_price_plan3_call","price","normal","high");
	add_meta_box("ct-price-plan4id","Plan 4","ct_price_plan4_call","price","normal","high");
	add_meta_box("ct-price-status","Status ","ct_price_status_call","price","side","default");
}
add_action('add_meta_boxes','ct_register_price_metabox');
function ct_price_subtitle_call($post){?>
	<table>
	<tr>
		<td><?php $price_subtitle= get_post_meta(get_the_ID(),"ct_price_subtitle_key",true); ?>
		<input type="text" name="price_subtitle" value="<?php echo $price_subtitle; ?>" placeholder="price sub-title" size="100%">
		</td>			
	</tr>
	</table>
<?php
}
function ct_save_price_subtitle_metabox_value($post_id, $post){
	$price_subtitle=isset($_POST['price_subtitle']) ? $_POST['price_subtitle'] : "";
	update_post_meta($post_id,"ct_price_subtitle_key",$price_subtitle);
}
add_action("save_post","ct_save_price_subtitle_metabox_value",10,2);
function ct_price_plan1_call($post){ ?>
	<table>
	<tr>
		<td><?php $ct_price_plan1_title= get_post_meta(get_the_ID(),"ct_price_plan1_title_key",true); ?>
		<input type="text" name="ct_price_plan1_title" value="<?php echo $ct_price_plan1_title; ?>" placeholder="title" size="30">
		</td>
		<td><?php $price_plan1_currency_icon= get_post_meta(get_the_ID(),"ct_price_plan1_currency_icon_key",true); ?>
		<input type="text" name="price_plan1_currency_icon" value="<?php echo $price_plan1_currency_icon; ?>" placeholder="currency icon-class" size="30">
		</td>
		<td><?php $ct_price_plan1_amount= get_post_meta(get_the_ID(),"ct_price_plan1_amount_key",true); ?>
		<input type="number" name="ct_price_plan1_amount" value="<?php echo $ct_price_plan1_amount; ?>" placeholder="amount" size="30">
		</td>
	</tr>
	<tr>
		<td>
		<a href="#" class="cpt_upload_image_button           
		button button-secondary"><?php _e('Upload Image'); ?></a>
		<?php $ct_price_plan1_img=get_post_meta(get_the_ID(),"ct_price_plan1_img_key",true); ?>
		<input type="hidden" name="ct_price_plan1_img_key" id="ct_price_plan1_img_key" value="<?php echo $ct_price_plan1_img; ?>" />
		<small> <img src=" <?php echo $ct_price_plan1_img; ?>" heigth="40px" width="30px"> 
		</small>
		</td>
		<td><?php $ct_price_plan1_btntxt= get_post_meta(get_the_ID(),"ct_price_plan1_btntxt_key",true); ?>
		<input type="text" name="ct_price_plan1_btntxt" value="<?php echo $ct_price_plan1_btntxt; ?>" placeholder="button text" size="30">
		</td>
		<td><?php $ct_price_plan1_btnurl= get_post_meta(get_the_ID(),"ct_price_plan1_btnurl_key",true); ?>
		<input type="url" name="ct_price_plan1_btnurl" value="<?php echo $ct_price_plan1_btnurl; ?>" placeholder="button link" size="30">
		</td>
	</tr>
	<tr>
		<td><?php $ct_price_plan1_listitem1= get_post_meta(get_the_ID(),"ct_price_plan1_listitem1_key",true); ?>
		<input type="text" name="ct_price_plan1_listitem1" value="<?php echo $ct_price_plan1_listitem1; ?>" placeholder="list-item1" size="30">
		</td>
		<td><?php $ct_price_plan1_listitem2= get_post_meta(get_the_ID(),"ct_price_plan1_listitem2_key",true); ?>
		<input type="text" name="ct_price_plan1_listitem2" value="<?php echo $ct_price_plan1_listitem2; ?>" placeholder="list-item2" size="30">
		</td>
		<td><?php $ct_price_plan1_listitem3= get_post_meta(get_the_ID(),"ct_price_plan1_listitem3_key",true); ?>
		<input type="text" name="ct_price_plan1_listitem3" value="<?php echo $ct_price_plan1_listitem3; ?>" placeholder="list-item3" size="30">
		</td>
		</tr>
		<tr>
		<td><?php $ct_price_plan1_listitem4= get_post_meta(get_the_ID(),"ct_price_plan1_listitem4_key",true); ?>
		<input type="text" name="ct_price_plan1_listitem4" value="<?php echo $ct_price_plan1_listitem4; ?>" placeholder="list-item4" size="30">
		</td>
		<td><?php $ct_price_plan1_listitem5= get_post_meta(get_the_ID(),"ct_price_plan1_listitem5_key",true); ?>
		<input type="text" name="ct_price_plan1_listitem5" value="<?php echo $ct_price_plan1_listitem5; ?>" placeholder="list-item5" size="30">
		</td>
	</tr>
</table>
<?php 
}
function ct_save_price_plan1_metabox_value($post_id, $post){
	$ct_price_plan1_title=isset($_POST['ct_price_plan1_title']) ? $_POST['ct_price_plan1_title'] : "";
	update_post_meta(get_the_ID(),"ct_price_plan1_title_key",$ct_price_plan1_title);
	$price_plan1_currency_icon=isset($_POST['price_plan1_currency_icon']) ? $_POST['price_plan1_currency_icon'] : "";
	update_post_meta(get_the_ID(),"ct_price_plan1_currency_icon_key",$price_plan1_currency_icon);
	$ct_price_plan1_amount=isset($_POST['ct_price_plan1_amount']) ? $_POST['ct_price_plan1_amount'] : "";
	update_post_meta(get_the_ID(),"ct_price_plan1_amount_key",$ct_price_plan1_amount);
	if(!empty($_POST['ct_price_plan1_img_key'])){
		if (array_key_exists('ct_price_plan1_img_key', $_POST)) {
			update_post_meta(get_the_ID(),
				'ct_price_plan1_img_key',
				$_POST['ct_price_plan1_img_key']
			);
		}
	}
	$ct_price_plan1_listitem1=isset($_POST['ct_price_plan1_listitem1']) ? $_POST['ct_price_plan1_listitem1'] : "";
	update_post_meta($post_id,"ct_price_plan1_listitem1_key",$ct_price_plan1_listitem1);
	$ct_price_plan1_listitem2=isset($_POST['ct_price_plan1_listitem2']) ? $_POST['ct_price_plan1_listitem2'] : "";
	update_post_meta($post_id,"ct_price_plan1_listitem2_key",$ct_price_plan1_listitem2);
	$ct_price_plan1_listitem3=isset($_POST['ct_price_plan1_listitem3']) ? $_POST['ct_price_plan1_listitem3'] : "";
	update_post_meta($post_id,"ct_price_plan1_listitem3_key",$ct_price_plan1_listitem3);

	$ct_price_plan1_listitem4=isset($_POST['ct_price_plan1_listitem4']) ? $_POST['ct_price_plan1_listitem4'] : "";
	update_post_meta($post_id,"ct_price_plan1_listitem4_key",$ct_price_plan1_listitem4);

	$ct_price_plan1_listitem5=isset($_POST['ct_price_plan1_listitem5']) ? $_POST['ct_price_plan1_listitem5'] : "";
	update_post_meta($post_id,"ct_price_plan1_listitem5_key",$ct_price_plan1_listitem5);
	$ct_price_plan1_btntxt=isset($_POST['ct_price_plan1_btntxt']) ? $_POST['ct_price_plan1_btntxt'] : "";
	update_post_meta($post_id,"ct_price_plan1_btntxt_key",$ct_price_plan1_btntxt);
	$ct_price_plan1_btnurl=isset($_POST['ct_price_plan1_btnurl']) ? $_POST['ct_price_plan1_btnurl'] : "";
	update_post_meta($post_id,"ct_price_plan1_btnurl_key",$ct_price_plan1_btnurl);	
}
add_action("save_post","ct_save_price_plan1_metabox_value",10,2);
function ct_price_plan2_call($post){ ?>
	<table>
	<tr>
		<td><?php $ct_price_plan2_title= get_post_meta(get_the_ID(),"ct_price_plan2_title_key",true); ?>
		<input type="text" name="ct_price_plan2_title" value="<?php echo $ct_price_plan2_title; ?>" placeholder="title" size="30">
		</td>
		<td><?php $price_plan2_currency_icon= get_post_meta(get_the_ID(),"ct_price_plan2_currency_icon_key",true); ?>
		<input type="text" name="price_plan2_currency_icon" value="<?php echo $price_plan2_currency_icon; ?>" placeholder="currency icon-class" size="30">
		</td>
		<td><?php $ct_price_plan2_amount= get_post_meta(get_the_ID(),"ct_price_plan2_amount_key",true); ?>
		<input type="number" name="ct_price_plan2_amount" value="<?php echo $ct_price_plan2_amount; ?>" placeholder="amount" size="30">
		</td>
	</tr>
	<tr>
		<td>
		<a href="#" class="cpt_upload_image_button_plan2           
		button button-secondary"><?php _e('Upload Image'); ?></a>
		<?php $ct_price_plan2_img=get_post_meta(get_the_ID(),"ct_price_plan2_img_key",true); ?>
		<input type="hidden" name="ct_price_plan2_img_key" id="ct_price_plan2_img_key" value="<?php echo $ct_price_plan2_img; ?>" />
		<small> <img src=" <?php echo $ct_price_plan2_img; ?>" heigth="40px" width="30px"> 
		</small>
		</td>
		<td><?php $ct_price_plan2_btntxt= get_post_meta(get_the_ID(),"ct_price_plan2_btntxt_key",true); ?>
		<input type="text" name="ct_price_plan2_btntxt" value="<?php echo $ct_price_plan2_btntxt; ?>" placeholder="button text" size="30">
		</td>
		<td><?php $ct_price_plan2_btnurl= get_post_meta(get_the_ID(),"ct_price_plan2_btnurl_key",true); ?>
		<input type="url" name="ct_price_plan2_btnurl" value="<?php echo $ct_price_plan2_btnurl; ?>" placeholder="button link" size="30">
		</td>
		
	</tr>
	<tr>
		<td><?php $ct_price_plan2_listitem1= get_post_meta(get_the_ID(),"ct_price_plan2_listitem1_key",true); ?>
		<input type="text" name="ct_price_plan2_listitem1" value="<?php echo $ct_price_plan2_listitem1; ?>" placeholder="list-item1" size="30">
		</td>
		<td><?php $ct_price_plan2_listitem2= get_post_meta(get_the_ID(),"ct_price_plan2_listitem2_key",true); ?>
		<input type="text" name="ct_price_plan2_listitem2" value="<?php echo $ct_price_plan2_listitem2; ?>" placeholder="list-item2" size="30">
		</td>
		<td><?php $ct_price_plan2_listitem3= get_post_meta(get_the_ID(),"ct_price_plan2_listitem3_key",true); ?>
		<input type="text" name="ct_price_plan2_listitem3" value="<?php echo $ct_price_plan2_listitem3; ?>" placeholder="list-item3" size="30">
		</td>
		</tr>
		<tr>
		<td><?php $ct_price_plan2_listitem4= get_post_meta(get_the_ID(),"ct_price_plan2_listitem4_key",true); ?>
		<input type="text" name="ct_price_plan2_listitem4" value="<?php echo $ct_price_plan2_listitem4; ?>" placeholder="list-item4" size="30">
		</td>
		<td><?php $ct_price_plan2_listitem5= get_post_meta(get_the_ID(),"ct_price_plan2_listitem5_key",true); ?>
		<input type="text" name="ct_price_plan2_listitem5" value="<?php echo $ct_price_plan2_listitem5; ?>" placeholder="list-item5" size="30">
		</td>
	</tr>
</table>
<?php 
}
function ct_save_price_plan2_metabox_value($post_id, $post){
	$ct_price_plan2_title=isset($_POST['ct_price_plan2_title']) ? $_POST['ct_price_plan2_title'] : "";
	update_post_meta($post_id,"ct_price_plan2_title_key",$ct_price_plan2_title);
	$price_plan2_currency_icon=isset($_POST['price_plan2_currency_icon']) ? $_POST['price_plan2_currency_icon'] : "";
	update_post_meta($post_id,"ct_price_plan2_currency_icon_key",$price_plan2_currency_icon);
	$ct_price_plan2_amount=isset($_POST['ct_price_plan2_amount']) ? $_POST['ct_price_plan2_amount'] : "";
	update_post_meta($post_id,"ct_price_plan2_amount_key",$ct_price_plan2_amount);
	if(!empty($_POST['ct_price_plan2_img_key'])){
		if (array_key_exists('ct_price_plan2_img_key', $_POST)) {
			update_post_meta(get_the_ID(),
				'ct_price_plan2_img_key',
				$_POST['ct_price_plan2_img_key']
			);
		}
	}
	$ct_price_plan2_listitem1=isset($_POST['ct_price_plan2_listitem1']) ? $_POST['ct_price_plan2_listitem1'] : "";
	update_post_meta($post_id,"ct_price_plan2_listitem1_key",$ct_price_plan2_listitem1);
	$ct_price_plan2_listitem2=isset($_POST['ct_price_plan2_listitem2']) ? $_POST['ct_price_plan2_listitem2'] : "";
	update_post_meta($post_id,"ct_price_plan2_listitem2_key",$ct_price_plan2_listitem2);
	$ct_price_plan2_listitem3=isset($_POST['ct_price_plan2_listitem3']) ? $_POST['ct_price_plan2_listitem3'] : "";
	update_post_meta($post_id,"ct_price_plan2_listitem3_key",$ct_price_plan2_listitem3);

	$ct_price_plan2_listitem4=isset($_POST['ct_price_plan2_listitem4']) ? $_POST['ct_price_plan2_listitem4'] : "";
	update_post_meta($post_id,"ct_price_plan2_listitem4_key",$ct_price_plan2_listitem4);

	$ct_price_plan2_listitem5=isset($_POST['ct_price_plan2_listitem5']) ? $_POST['ct_price_plan2_listitem5'] : "";
	update_post_meta($post_id,"ct_price_plan2_listitem5_key",$ct_price_plan2_listitem5);
	$ct_price_plan2_btntxt=isset($_POST['ct_price_plan2_btntxt']) ? $_POST['ct_price_plan2_btntxt'] : "";
	update_post_meta($post_id,"ct_price_plan2_btntxt_key",$ct_price_plan2_btntxt);
	$ct_price_plan2_btnurl=isset($_POST['ct_price_plan2_btnurl']) ? $_POST['ct_price_plan2_btnurl'] : "";
	update_post_meta($post_id,"ct_price_plan2_btnurl_key",$ct_price_plan2_btnurl);	
}
add_action("save_post","ct_save_price_plan2_metabox_value",10,2);

function ct_price_plan3_call($post){ ?>
	<table>
	<tr>
		<td><?php $ct_price_plan3_title= get_post_meta(get_the_ID(),"ct_price_plan3_title_key",true); ?>
		<input type="text" name="ct_price_plan3_title" value="<?php echo $ct_price_plan3_title; ?>" placeholder="title" size="30">
		</td>
		<td><?php $price_plan3_currency_icon= get_post_meta(get_the_ID(),"ct_price_plan3_currency_icon_key",true); ?>
		<input type="text" name="price_plan3_currency_icon" value="<?php echo $price_plan3_currency_icon; ?>" placeholder="currency icon-class" size="30">
		</td>
		<td><?php $ct_price_plan3_amount= get_post_meta(get_the_ID(),"ct_price_plan3_amount_key",true); ?>
		<input type="number" name="ct_price_plan3_amount" value="<?php echo $ct_price_plan3_amount; ?>" placeholder="amount" size="30">
		</td>
	</tr>
	<tr>
		<td>
		<a href="#" class="cpt_upload_image_button_plan3           
		button button-secondary"><?php _e('Upload Image'); ?></a>
		<?php $ct_price_plan3_img=get_post_meta(get_the_ID(),"ct_price_plan3_img_key",true); ?>
		<input type="hidden" name="ct_price_plan3_img_key" id="ct_price_plan3_img_key" value="<?php echo $ct_price_plan3_img; ?>" />
		<small> <img src=" <?php echo $ct_price_plan3_img; ?>" heigth="40px" width="30px"> 
		</small>
		</td>
		<td><?php $ct_price_plan3_btntxt= get_post_meta(get_the_ID(),"ct_price_plan3_btntxt_key",true); ?>
		<input type="text" name="ct_price_plan3_btntxt" value="<?php echo $ct_price_plan3_btntxt; ?>" placeholder="button text" size="30">
		</td>
		<td><?php $ct_price_plan3_btnurl= get_post_meta(get_the_ID(),"ct_price_plan3_btnurl_key",true); ?>
		<input type="url" name="ct_price_plan3_btnurl" value="<?php echo $ct_price_plan3_btnurl; ?>" placeholder="button link" size="30">
		</td>
	</tr>
	<tr>
		<td><?php $ct_price_plan3_listitem1= get_post_meta(get_the_ID(),"ct_price_plan3_listitem1_key",true); ?>
		<input type="text" name="ct_price_plan3_listitem1" value="<?php echo $ct_price_plan3_listitem1; ?>" placeholder="list-item1" size="30">
		</td>
		<td><?php $ct_price_plan3_listitem2= get_post_meta(get_the_ID(),"ct_price_plan3_listitem2_key",true); ?>
		<input type="text" name="ct_price_plan3_listitem2" value="<?php echo $ct_price_plan3_listitem2; ?>" placeholder="list-item2" size="30">
		</td>
		<td><?php $ct_price_plan3_listitem3= get_post_meta(get_the_ID(),"ct_price_plan3_listitem3_key",true); ?>
		<input type="text" name="ct_price_plan3_listitem3" value="<?php echo $ct_price_plan3_listitem3; ?>" placeholder="list-item3" size="30">
		</td>
		</tr>
		<tr>
		<td><?php $ct_price_plan3_listitem4= get_post_meta(get_the_ID(),"ct_price_plan3_listitem4_key",true); ?>
		<input type="text" name="ct_price_plan3_listitem4" value="<?php echo $ct_price_plan3_listitem4; ?>" placeholder="list-item4" size="30">
		</td>
		<td><?php $ct_price_plan3_listitem5= get_post_meta(get_the_ID(),"ct_price_plan3_listitem5_key",true); ?>
		<input type="text" name="ct_price_plan3_listitem5" value="<?php echo $ct_price_plan3_listitem5; ?>" placeholder="list-item5" size="30">
		</td>
	</tr>
</table>
<?php 
}
function ct_save_price_plan3_metabox_value($post_id, $post){
	$ct_price_plan3_title=isset($_POST['ct_price_plan3_title']) ? $_POST['ct_price_plan3_title'] : "";
	update_post_meta($post_id,"ct_price_plan3_title_key",$ct_price_plan3_title);
	$price_plan3_currency_icon=isset($_POST['price_plan3_currency_icon']) ? $_POST['price_plan3_currency_icon'] : "";
	update_post_meta($post_id,"ct_price_plan3_currency_icon_key",$price_plan3_currency_icon);
	$ct_price_plan3_amount=isset($_POST['ct_price_plan3_amount']) ? $_POST['ct_price_plan3_amount'] : "";
	update_post_meta($post_id,"ct_price_plan3_amount_key",$ct_price_plan3_amount);
	if(!empty($_POST['ct_price_plan3_img_key'])){
		if (array_key_exists('ct_price_plan3_img_key', $_POST)) {
			update_post_meta(get_the_ID(),
				'ct_price_plan3_img_key',
				$_POST['ct_price_plan3_img_key']
			);
		}
	}
	$ct_price_plan3_listitem1=isset($_POST['ct_price_plan3_listitem1']) ? $_POST['ct_price_plan3_listitem1'] : "";
	update_post_meta($post_id,"ct_price_plan3_listitem1_key",$ct_price_plan3_listitem1);
	$ct_price_plan3_listitem2=isset($_POST['ct_price_plan3_listitem2']) ? $_POST['ct_price_plan3_listitem2'] : "";
	update_post_meta($post_id,"ct_price_plan3_listitem2_key",$ct_price_plan3_listitem2);
	$ct_price_plan3_listitem3=isset($_POST['ct_price_plan3_listitem3']) ? $_POST['ct_price_plan3_listitem3'] : "";
	update_post_meta($post_id,"ct_price_plan3_listitem3_key",$ct_price_plan3_listitem3);

	$ct_price_plan3_listitem4=isset($_POST['ct_price_plan3_listitem4']) ? $_POST['ct_price_plan3_listitem4'] : "";
	update_post_meta($post_id,"ct_price_plan3_listitem4_key",$ct_price_plan3_listitem4);

	$ct_price_plan3_listitem5=isset($_POST['ct_price_plan3_listitem5']) ? $_POST['ct_price_plan3_listitem5'] : "";
	update_post_meta($post_id,"ct_price_plan3_listitem5_key",$ct_price_plan3_listitem5);

	$ct_price_plan3_btntxt=isset($_POST['ct_price_plan3_btntxt']) ? $_POST['ct_price_plan3_btntxt'] : "";
	update_post_meta($post_id,"ct_price_plan3_btntxt_key",$ct_price_plan3_btntxt);

	$ct_price_plan3_btnurl=isset($_POST['ct_price_plan3_btnurl']) ? $_POST['ct_price_plan3_btnurl'] : "";
	update_post_meta($post_id,"ct_price_plan3_btnurl_key",$ct_price_plan3_btnurl);	
}
add_action("save_post","ct_save_price_plan3_metabox_value",10,2);

function ct_price_plan4_call($post){ ?>
	<table>
	<tr>
		<td><?php $ct_price_plan4_title= get_post_meta(get_the_ID(),"ct_price_plan4_title_key",true); ?>
		<input type="text" name="ct_price_plan4_title" value="<?php echo $ct_price_plan4_title; ?>" placeholder="title" size="30">
		</td>
		<td><?php $price_plan4_currency_icon= get_post_meta(get_the_ID(),"ct_price_plan4_currency_icon_key",true); ?>
		<input type="text" name="price_plan4_currency_icon" value="<?php echo $price_plan4_currency_icon; ?>" placeholder="currency icon-class" size="30">
		</td>
		<td><?php $ct_price_plan4_amount= get_post_meta(get_the_ID(),"ct_price_plan4_amount_key",true); ?>
		<input type="number" name="ct_price_plan4_amount" value="<?php echo $ct_price_plan4_amount; ?>" placeholder="amount" size="30">
		</td>
	</tr>
	<tr>
		<td>
		<a href="#" class="cpt_upload_image_button_plan4           
		button button-secondary"><?php _e('Upload Image'); ?></a>
		<?php $ct_price_plan4_img=get_post_meta(get_the_ID(),"ct_price_plan4_img_key",true); ?>
		<input type="hidden" name="ct_price_plan4_img_key" id="ct_price_plan4_img_key" value="<?php echo $ct_price_plan4_img; ?>" />
		<small> <img src=" <?php echo $ct_price_plan4_img; ?>" heigth="40px" width="30px"> 
		</small>
		</td>
		<td><?php $ct_price_plan4_btntxt= get_post_meta(get_the_ID(),"ct_price_plan4_btntxt_key",true); ?>
		<input type="text" name="ct_price_plan4_btntxt" value="<?php echo $ct_price_plan4_btntxt; ?>" placeholder="button text" size="30">
		</td>
		<td><?php $ct_price_plan4_btnurl= get_post_meta(get_the_ID(),"ct_price_plan4_btnurl_key",true); ?>
		<input type="url" name="ct_price_plan4_btnurl" value="<?php echo $ct_price_plan4_btnurl; ?>" placeholder="button link" size="30">
		</td>
		
	</tr>
	<tr>
		<td><?php $ct_price_plan4_listitem1= get_post_meta(get_the_ID(),"ct_price_plan4_listitem1_key",true); ?>
		<input type="text" name="ct_price_plan4_listitem1" value="<?php echo $ct_price_plan4_listitem1; ?>" placeholder="list-item1" size="30">
		</td>
		<td><?php $ct_price_plan4_listitem2= get_post_meta(get_the_ID(),"ct_price_plan4_listitem2_key",true); ?>
		<input type="text" name="ct_price_plan4_listitem2" value="<?php echo $ct_price_plan4_listitem2; ?>" placeholder="list-item2" size="30">
		</td>
		<td><?php $ct_price_plan4_listitem3= get_post_meta(get_the_ID(),"ct_price_plan4_listitem3_key",true); ?>
		<input type="text" name="ct_price_plan4_listitem3" value="<?php echo $ct_price_plan4_listitem3; ?>" placeholder="list-item3" size="30">
		</td>
		</tr>
		<tr>
		<td><?php $ct_price_plan4_listitem4= get_post_meta(get_the_ID(),"ct_price_plan4_listitem4_key",true); ?>
		<input type="text" name="ct_price_plan4_listitem4" value="<?php echo $ct_price_plan4_listitem4; ?>" placeholder="list-item4" size="30">
		</td>
		<td><?php $ct_price_plan4_listitem5= get_post_meta(get_the_ID(),"ct_price_plan4_listitem5_key",true); ?>
		<input type="text" name="ct_price_plan4_listitem5" value="<?php echo $ct_price_plan4_listitem5; ?>" placeholder="list-item5" size="30">
		</td>
	</tr>
</table>
<?php 
}
function ct_save_price_plan4_metabox_value($post_id, $post){
	$ct_price_plan4_title=isset($_POST['ct_price_plan4_title']) ? $_POST['ct_price_plan4_title'] : "";
	update_post_meta($post_id,"ct_price_plan4_title_key",$ct_price_plan4_title);
	$price_plan4_currency_icon=isset($_POST['price_plan4_currency_icon']) ? $_POST['price_plan4_currency_icon'] : "";
	update_post_meta($post_id,"ct_price_plan4_currency_icon_key",$price_plan4_currency_icon);
	$ct_price_plan4_amount=isset($_POST['ct_price_plan4_amount']) ? $_POST['ct_price_plan4_amount'] : "";
	update_post_meta($post_id,"ct_price_plan4_amount_key",$ct_price_plan4_amount);
	if(!empty($_POST['ct_price_plan4_img_key'])){
		if (array_key_exists('ct_price_plan4_img_key', $_POST)) {
			update_post_meta(get_the_ID(),
				'ct_price_plan4_img_key',
				$_POST['ct_price_plan4_img_key']
			);
		}
	}
	$ct_price_plan4_listitem1=isset($_POST['ct_price_plan4_listitem1']) ? $_POST['ct_price_plan4_listitem1'] : "";
	update_post_meta($post_id,"ct_price_plan4_listitem1_key",$ct_price_plan4_listitem1);
	$ct_price_plan4_listitem2=isset($_POST['ct_price_plan4_listitem2']) ? $_POST['ct_price_plan4_listitem2'] : "";
	update_post_meta($post_id,"ct_price_plan4_listitem2_key",$ct_price_plan4_listitem2);
	$ct_price_plan4_listitem3=isset($_POST['ct_price_plan4_listitem3']) ? $_POST['ct_price_plan4_listitem3'] : "";
	update_post_meta($post_id,"ct_price_plan4_listitem3_key",$ct_price_plan4_listitem3);

	$ct_price_plan4_listitem4=isset($_POST['ct_price_plan4_listitem4']) ? $_POST['ct_price_plan4_listitem4'] : "";
	update_post_meta($post_id,"ct_price_plan4_listitem4_key",$ct_price_plan4_listitem4);

	$ct_price_plan4_listitem5=isset($_POST['ct_price_plan4_listitem5']) ? $_POST['ct_price_plan4_listitem5'] : "";
	update_post_meta($post_id,"ct_price_plan4_listitem5_key",$ct_price_plan4_listitem5);
	$ct_price_plan4_btntxt=isset($_POST['ct_price_plan4_btntxt']) ? $_POST['ct_price_plan4_btntxt'] : "";
	update_post_meta($post_id,"ct_price_plan4_btntxt_key",$ct_price_plan4_btntxt);
	$ct_price_plan4_btnurl=isset($_POST['ct_price_plan4_btnurl']) ? $_POST['ct_price_plan4_btnurl'] : "";
	update_post_meta($post_id,"ct_price_plan4_btnurl_key",$ct_price_plan4_btnurl);	
}
add_action("save_post","ct_save_price_plan4_metabox_value",10,2);

function ct_price_status_call($post){
 wp_nonce_field( 'ct_price_statuskey', 'ct_price_statuskey_nonce' );
 $value = get_post_meta( get_the_ID(), 'ct_price_statuskey', true ); 
 ?>
 <table>
 	<tr>
 		<td ><input type="radio" class="radioBtnClass" name="price_statusbtn" id="price_active" value="Active" <?php checked( $value, 'Active' ); ?> > <label for="price_active" class="rlable">Active</label>
 		
 			<input type="radio" class="radioBtnClass" name="price_statusbtn" id="price_deactive" value="Deactive" <?php checked( $value, 'Deactive' ); ?> > <label for="price_deactive" >Deactive</label>
 		</td>
 	</tr>
 	<tr>
 		<td >
 			<label for="price_statusbtn" class="error" style="display: none;"></label>
 		</td>

 	</tr>
 </table>
<?php
}
function ct_save_price_status_metabox_value($post_id, $post){
	if ( !isset( $_POST['ct_price_statuskey_nonce'] ) ) {
		return;
	}
        // Verify that the nonce is valid.
	if ( !wp_verify_nonce( $_POST['ct_price_statuskey_nonce'], 'ct_price_statuskey' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
        // Check the user's permissions.
	if ( !current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
        // Sanitize user input.
	$new_meta_value = ( isset( $_POST['price_statusbtn'] ) ? sanitize_html_class( $_POST['price_statusbtn'] ) : '' );
	global $wpdb;
	$meta_key = 'ct_price_statuskey';
	$data = $wpdb->get_results($wpdb->prepare( "SELECT meta_value, post_id FROM $wpdb->postmeta WHERE meta_value = 'Active'", $meta_key) , ARRAY_N  );
	if($new_meta_value == 'Active') {
		foreach ($data as $key => $postid) {
			echo update_post_meta( $postid[1], 'ct_price_statuskey', 'Deactive' );
		}
	}
	update_post_meta( $post_id, 'ct_price_statuskey', $new_meta_value );
}
add_action("save_post","ct_save_price_status_metabox_value",10,2);
// for shortcode notice
function general_pricing_admin_notice(){
    global $typenow;
    if ( $typenow == 'price' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Use <strong> [pricing] </strong> shortcode for display this Custom Post Type.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_pricing_admin_notice');
//******** shortcode *********
add_shortcode( 'pricing', 'display_price_shortcode' );
function display_price_shortcode(){?>
<!-- ======= Pricing Section ======= -->
<section id="pricing" class="pricing">
  <div class="container" data-aos="fade-up">
    <?php
    $query = new WP_Query( array( 'post_type' => 'price'));
    if( $query->have_posts() ) { 
      while ( $query->have_posts() ) { $query->the_post();
		 $the_query = new WP_Query('showposts=1'); 
        wp_nonce_field( 'ct_price_statuskey', 'ct_price_statuskey_nonce');
        $value = get_post_meta( get_the_ID(), 'ct_price_statuskey', true );
        if($value=='Active'){
          $postid = get_the_ID();
//$value = get_post_meta( $postid, 'ct_price_statuskey', true );
          ?>
          <header class="section-header">
            <h3><?php the_title(); ?></h3>
            <p><?php echo get_post_meta($postid, 'ct_price_subtitle_key', true );?></p>
          </header>
          <div class="row gy-4" data-aos="fade-left"><?php $plan1_title = get_post_meta($postid, 'ct_price_plan1_title_key', true );
          if(!empty($plan1_title)){ ?>
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="100">
              <div class="box">
                <h3 style="color: #07d5c0;"><?php echo $plan1_title;?></h3>
                <div class="price"><sup><i class="<?php echo get_post_meta($postid, 'ct_price_plan1_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta(get_the_ID(), 'ct_price_plan1_amount_key', true );?><span> / mo</span>
                </div>
                <img src="<?php echo get_post_meta(get_the_ID(), 'ct_price_plan1_img_key',true)?>" class="img-fluid" alt="">
                <ul>
                  <li><?php echo get_post_meta($postid, 'ct_price_plan1_listitem1_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem2_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem3_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem4_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan1_listitem5_key', true );?></li>
                </ul>
                <a href="<?php echo get_post_meta( $postid, 'ct_price_plan1_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan1_btntxt_key', true );?></a>
              </div>
            </div>
            <?php 
          }
          ?>
          <?php  $plan2_title = get_post_meta( $postid, 'ct_price_plan2_title_key', true );
          if(!empty($plan2_title)){
            ?>
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="200">
              <div class="box">
                <h3 style="color: #65c600;"><?php echo $plan2_title; ?></h3>
                <div class="price"><sup><i class="<?php echo get_post_meta( $postid, 'ct_price_plan2_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta( $postid, 'ct_price_plan2_amount_key', true );?><span> / mo</span>
                </div>
                <img 
                src="<?php echo get_post_meta(get_the_ID(),'ct_price_plan2_img_key', true)?>" class="img-fluid" alt="">
                <ul>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem1_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem2_key', true );?></li>
                  <li><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem3_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem4_key', true );?></li>
                  <li class="na"><?php echo get_post_meta( $postid, 'ct_price_plan2_listitem5_key', true );?></li>
                </ul>
                <a href="<?php echo get_post_meta( $postid, 'ct_price_plan2_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan2_btntxt_key', true );?></a>
              </div>
            </div>
            <?php 
          }
          ?> 
          <?php  $plan3_title = get_post_meta( $postid, 'ct_price_plan3_title_key', true );
          if(!empty($plan3_title)){
           ?>         
           <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="300">
            <div class="box">
              <h3 style="color: #ff901c;"><?php echo get_post_meta( $postid, 'ct_price_plan3_title_key', true );?></h3>
              <div class="price"><sup><i class="<?php echo get_post_meta( $postid, 'ct_price_plan3_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta( $postid, 'ct_price_plan3_amount_key', true );?><span> / mo</span>
              </div>
              <img src="<?php echo get_post_meta($postid, 'ct_price_plan3_img_key', true)?>" class="img-fluid" alt="">
              <ul>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem1_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem2_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem3_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem4_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan3_listitem5_key', true );?></li>
              </ul>
              <a href="<?php echo get_post_meta( $postid, 'ct_price_plan3_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan3_btntxt_key', true );?></a>
            </div>
          </div>
          <?php 
        }
        ?>
        <?php $plan4_title = get_post_meta( $postid, 'ct_price_plan4_title_key', true );
        if(!empty($plan4_title)){ ?>
          <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="400">
            <div class="box">
              <h3 style="color: #ff0071;"><?php echo get_post_meta( $postid, 'ct_price_plan4_title_key', true );?></h3>
              <div class="price"><sup><i class="<?php echo get_post_meta( $postid, 'ct_price_plan4_currency_icon_key', true );?>"></i></sup><?php echo get_post_meta( $postid, 'ct_price_plan4_amount_key', true );?><span> / mo</span>
              </div>
              <img src="<?php echo get_post_meta($postid, 'ct_price_plan4_img_key', true)?>" class="img-fluid" alt="">
              <ul>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem1_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem2_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem3_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem4_key', true );?></li>
                <li><?php echo get_post_meta( $postid, 'ct_price_plan4_listitem5_key', true );?></li>
              </ul>
              <a href="<?php echo get_post_meta( $postid, 'ct_price_plan4_btnurl_key', true );?>" class="btn-buy"><?php echo get_post_meta( $postid, 'ct_price_plan4_btntxt_key', true );?></a>
            </div>
          </div>
          <?php 
        }
        ?>
      </div>
    <?php }wp_reset_postdata();
  }
}
?>
</div>
</section><!-- End Pricing Section -->
<?php
}
?>

