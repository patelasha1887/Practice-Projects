<?php 
get_header(); 
?>
<main id="main">

<!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
    <h2>single.php</h2>
    <!-- ======= Blog Single Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">
        <div class="row">
          
          <div class="col-lg-8 entries">
            <?php 
            if(have_posts()){
                  while (have_posts()) {
                    // code...
                    the_post();
                    ?>
            <article class="entry entry-single">
              <div class="entry-img">
                <p> <?php the_post_thumbnail('blog-banner-image'); ?></p>
              </div>
              <h2 class="entry-title">
              <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
              </h2>
              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center">
                    <i class="bi bi-person"></i> 
                    <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>" >
                      <?php the_author(); ?></a>
                  </li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="<?php the_permalink(); ?>">
                    <?php the_time('F j,Y g:i a'); ?> </a>
                  </li>
                  <li class="d-flex align-items-center">
                    <i class="bi bi-chat-dots"></i> 
                    <a href="<?php the_permalink(); ?>"><?php echo get_comments_number(); ?> Comments</a>
                  </li>
                </ul>
              </div>
              <div class="entry-content">
                <p>
                  <?php the_content(); ?>
                </p>                
              </div>
              <div class="entry-footer">
                <i class="bi bi-folder"></i>
                <ul class="cats">
                  <li><a href="#">
                    <?php 
                    $categories= get_the_category();//get post category specific category
                    $separator = ",";
                    $catoptions= '';
                    foreach($categories as $cat){
                    $catoptions .= "<a href='".get_category_link($cat->term_id)."'/>".$cat->cat_name."</a>".$separator;           
                    }
                    echo trim($catoptions,$separator);
                    ?></a>
                  </li>
                </ul>

                <i class="bi bi-tags"></i>
                <ul class="tags">
                  <li><a href="#">Creative</a></li>
                  <li><a href="#">Tips</a></li>
                  <li><a href="#">Marketing</a></li>
                </ul>
              </div>
            </article><!-- End blog entry -->
          <?php
              }
            }
          ?>
            <div class="blog-author d-flex align-items-center">
              <?php
   $get_author_id = get_the_author_meta('ID');
   $get_author_gravatar = get_avatar_url($get_author_id, array('size' => 450));
      echo '<img src="'.$get_author_gravatar.'" alt="'.get_the_title().'" class="rounded-circle float-left" />';
   
?>
              <div>
                <h4><?php the_author(); ?></h4>
                <div class="social-links">
                  <?php if ( get_the_author_meta('twitter') ) : ?>
                      <a href="http://www.twitter.com/<?php the_author_meta('twitter'); ?>" title="Twitter">
                        <i class="bi bi-twitter"></i></a>
                  <?php endif; ?>
                  <?php if ( get_the_author_meta('facebook') ) : ?>
                      <a href="http://www.facebook.com/<?php the_author_meta('facebook'); ?>" title="Facebook">
                        <i class="bi bi-facebook"></i></a>
                  <?php endif; ?>
                  <?php if ( get_the_author_meta('instagram') ) : ?>
                      <a href="http://plus.google.com/<?php the_author_meta('instagram'); ?>" title="Instagram"><i class="biu bi-instagram"></i></a>
                  <?php endif; ?>
                  <?php if ( get_the_author_meta('linkedin') ) : ?>
                      <a href="http://www.linkedin.com/in/<?php the_author_meta('linkedin'); ?>" title="Linkedin"><i class="bi bi-linkedin"></i></a>
                  <?php endif; ?>
                </div>
                <p>
                  <?php   the_author_meta('description'); ?>
                </p>
              </div>
            </div><!-- End blog author bio -->

            <div class="blog-comments">
              <div class="reply-form">
                <?php comments_template();?>
              </div>
            </div><!-- End blog comments -->
          </div><!-- End blog entries list -->
          <div class="col-lg-4">
          <?php get_sidebar();?>
          </div><!-- End blog sidebar -->
        </div>
      </div>
    </section><!-- End Blog Single Section -->
  </main><!-- End #main -->


<?php 
get_footer(); 
?>