<?php

function custom_add_stylesandscripts(){
	//stylesheets
	wp_enqueue_style('main-css', get_stylesheet_uri());
	wp_enqueue_style('aos.css',get_template_directory_uri().'/assets/vendor/aos/aos.css');
	wp_enqueue_style('bootstrap.min.css',get_template_directory_uri().'/assets/vendor/bootstrap/css/bootstrap.min.css');
	wp_enqueue_style('bootstrap-icons.css',get_template_directory_uri().'/assets/vendor/bootstrap-icons/bootstrap-icons.css');
	wp_enqueue_style('glightbox.min.css',get_template_directory_uri().'/assets/vendor/glightbox/css/glightbox.min.css');
	wp_enqueue_style('remixicon.css',get_template_directory_uri().'/assets/vendor/remixicon/remixicon.css');
	wp_enqueue_style('swiper-bundle.min.css',get_template_directory_uri().'/assets/vendor/swiper/swiper-bundle.min.css');
	wp_enqueue_style('main-style.css',get_template_directory_uri().'/assets/css/style.css');
	//Javascripts
	wp_enqueue_script('purecounter_vanilla.js', get_template_directory_uri().'/assets/vendor/purecounter/purecounter_vanilla.js',array(),'1.1',true);
	wp_enqueue_script('aos.js', get_template_directory_uri().'/assets/vendor/aos/aos.js',array(),'1.1',true);
	wp_enqueue_script('bootstrap.bundle.min.js', get_template_directory_uri().'/assets/vendor/bootstrap/js/bootstrap.bundle.min.js',array(),'1.1',true);
	wp_enqueue_script('glightbox.min.js', get_template_directory_uri().'/assets/vendor/glightbox/js/glightbox.min.js',array(),'1.1',true);
	wp_enqueue_script('isotope.pkgd.min.js', get_template_directory_uri().'/assets/vendor/isotope-layout/isotope.pkgd.min.js',array(),'1.1',true);
	wp_enqueue_script('swiper-bundle.min.js', get_template_directory_uri().'/assets/vendor/swiper/swiper-bundle.min.js',array(),'1.1',true);
	wp_enqueue_script('validate.js', get_template_directory_uri().'/assets/vendor/php-email-form/validate.js',array(),'1.1',true);
	wp_enqueue_script('main.js', get_template_directory_uri().'/assets/js/main.js',array(),'1.1',true);
	
}//attach with hook
add_action("wp_enqueue_scripts","custom_add_stylesandscripts");
//banner js for loading media library
function cp_include_script() {
    if ( ! did_action( 'wp_enqueue_media' ) ) {
        wp_enqueue_media();
    }
    wp_enqueue_script( 'ct_js_banner.js', get_template_directory_uri().'/assets/js/ct_js_banner.js', array('jquery'), null, false );
    wp_enqueue_script( 'ct_js_price.js', get_template_directory_uri().'/assets/js/ct_js_price.js', array('jquery'), null, false );
}
add_action( 'admin_enqueue_scripts', 'cp_include_script' );
//menu register code
function register_navigation_menu(){
	register_nav_menus(
		array(
			'primary-menu'=>__('Primary Menu'),
			'footer-menu'=>__('Footer Menu')
		)
	);
}
	//attach with action hook
add_action('init','register_navigation_menu');
//navbar menu class on<li> and <a>
// add_filter('nav_menu_link_attributes','navmenu_aTag_class');
// function navmenu_aTag_class($attr){
// 	$$attr['class']='nav-link scrollto';//<li> $attr
// 	return $$attr;
// }
//navbar menu class on<li> and <a>
add_filter('nav_menu_css_class','navmenu_li_class',10,4);
function navmenu_li_class($classes,$item,$args,$depth){
	$classes[]='nav-link dropdown';//<li> classes
	return $classes;
}
	//add custom logo
function theme_cutom_logo_setup(){
	$defaults=array(
		'height'=>50,
		'width'=> 180,
		'flex-height'=>true,
		'flex-width'=>true,
		'header-text'=>array('site-title','site-description'),
		);
	add_theme_support('custom-logo',$defaults);
}
add_action('after_setup_theme','theme_cutom_logo_setup');

//sidebar
function register_custom_sidebar(){
	register_sidebar(array(
		'name'=>__('Primary Sidebar 1','webdevelopment2k23'),
		'id'=>'primary-sidebar1',
		'before_widget'=>'<aside id="%1$s" class="footer %2$s">',
		'after_widget'=>'</aside>',
		'before_title'=>'<h4 class="footer-top">',
		'after_title'=>'</h4>'
	));
	register_sidebar(array(
		'name'=>__('Primary Sidebar 2','webdevelopment2k23'),
		'id'=>'primary-sidebar2',
		'before_widget'=>'<aside id="%1$s" class="footer %2$s">',
		'after_widget'=>'</aside>',
		'before_title'=>'<h4 class="footer-top">',
		'after_title'=>'</h4>'
	));
	register_sidebar(array(
		'name'=>__('Blog Sidebar','webdevelopment2k23'),
		'id'=>'blog-sidebar',
		'before_widget'=>'<aside id="%1$s" class="%2$s">',
		'after_widget'=>'</aside>',
		'before_title'=>'<h3 class="wp-block-heading">',
		'after_title'=>'</h3>'
	));

}// attach with action hook
add_action("widgets_init","register_custom_sidebar");
// footer sidebars
function ct_register_footer_sidebars(){
$args=array(
	'name' => __('Footer 1','customtheme'),  
	'id' => 'ct-sidebar-id',
	'description' => 'Logo section',
	'class' => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
);
$args2=array(
	'name' => __('Footer 2','customtheme'),  
	'id' => 'ct-sidebar-id2',
	'description' => 'default side bar2',
	'class' => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
);
$args3=array(
	'name' => __('Footer 3','customtheme'),  
	'id' => 'ct-sidebar-id3',
	'description' => 'default side bar2',
	'class' => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
);
$args4=array(
	'name' => __('Footer 4','customtheme'),  
	'id' => 'ct-sidebar-id4',
	'description' => 'default side bar2',
	'class' => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
);
$subfooter_args=array(
	'name' => __('Sub Footer','customtheme'),  
	'id' => 'ct-sidebar-subfooter',
	'description' => 'Copy right sub footer',
	'class' => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
);
$sociallink_args=array(
	'name' => __('Social Links','customtheme'),  
	'id' => 'ct-sidebar-sociallink',
	'description' =>'Add Social Links',
	'class' => '',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>',
);
$blogsidebar_args=array(
	'name' => __('Blog SideBar','customtheme'),  
	'id' => 'ct-sidebar-blogsidebar',
	'before_widget' => '<li id="%1$s" class="widget %2$s">',
	'after_widget'  => '</li>',
	'before_title'  => '<h2 class="widgettitle">',
	'after_title'   => '</h2>'
);
register_sidebar($args);
register_sidebar($args2);
register_sidebar($args3);
register_sidebar($args4);
register_sidebar($sociallink_args);
}
add_action('widgets_init','ct_register_footer_sidebars');
//for footer section bgimg
function themeName_customize_register($wp_customize) {
// Add Settings
$wp_customize->add_setting('customizer_footer_setting', array(
    'transport'         => 'refresh',
    'height'         => 325,
));
// Add Section
$wp_customize->add_section('footer_section', array(
    'title'             => 'Footer', 
    'priority'          => 70,
));    
// Add Controls
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'customizer_setting_control', array(
    'label'             => 'Set Footer Background Image',
    'section'           => 'footer_section',
    'settings'          => 'customizer_footer_setting',    
)));   
}
add_action('customize_register', 'themeName_customize_register');
//post thumbnails
function post_thumbnail_img_add(){
	add_theme_support("post-thumbnails");
	//image size
	add_image_size('small-image',355,260,true);
	add_image_size('blog-banner-image',736,552,true);
	add_image_size('about-image',588,418,true);//about img
	//post formats
	add_image_size('banner-image',539,438,true);
	add_theme_support("post-formats",array("aside","gallery","link"));
}
add_action("after_setup_theme","post_thumbnail_img_add");
//theme customizer panel
function customtheme_customize_panel_register($wp_customize){
	$wp_customize->add_section('main_section',array(
		'title' => "Custom Theme WebDevelopment",
		'description'=>'testing',
		'priority'=>120,
	));
	//=================
	// = Text Input
	//=================
	$wp_customize->add_setting('footer_txtbox',array(
		'default' => 'this is my sample textbox text',
		'capability' => 'edit_theme_options',
		'type' => 'option',

	));
	$wp_customize->add_control('footer_txt_control',array(
		'label' => "Enter your text",
		'section' => 'main_section',
		'settings' => 'footer_txtbox',
	));
	//=================
	// = footer copyright link btn
	//=================
	$wp_customize->add_setting('footer_link',array(
		'default' => 'copy right text',
		'capability' => 'edit_theme_options',
		'type' => 'option',
	));
	$wp_customize->add_control('footer_link_control',array(
		'label' => "Footer Link Text",
		'section' => 'main_section',
		'settings' => 'footer_link',
	));

	//  =============================
	//  = Page Dropdown             =
	//  =============================
	$wp_customize->add_setting('footer_page_dropdown', array(
	'capability'     => 'edit_theme_options',
	'type'           => 'option',

	));

	$wp_customize->add_control('footer_page_drpdown_control', array(
	'label'      => 'Footer Link',
	'section'    => 'main_section',
	'type'    => 'dropdown-pages',
	'settings'   => 'footer_page_dropdown',
	));

	//  =============================
	//  = Image Upload              =
	//  =============================
	$wp_customize->add_setting('custom_theme_panel_img_upload', array(
	'default'           => get_bloginfo("template_url").'/assets/img/values-2.png',
	'capability'        => 'edit_theme_options',
	'type'           => 'option',

	));

	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize, 'image_upload_test', array(
	'label'    => 'Choose Image',
	'section'  => 'main_section',
	'settings' => 'custom_theme_panel_img_upload',
	)));

	//  =============================
	//  = Color Picker              =
	//  =============================
	$wp_customize->add_setting('custom_theme_link_color_picker', array(
	'default'           => '#000',
	'sanitize_callback' => 'sanitize_hex_color',
	'capability'        => 'edit_theme_options',
	'type'           => 'option',
	));

	$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'link_color_control', array(
	'label'    => 'Select Menu Button Background color',
	'section'  => 'main_section',
	'settings' => 'custom_theme_link_color_picker',
	)));

	
}
add_action('customize_register','customtheme_customize_panel_register');

function admin_social_media_icons( $contactmethods ) {
    // Add social media
    $contactmethods['twitter'] = 'Twitter';
    $contactmethods['facebook'] = 'Facebook';
    $contactmethods['instagram'] = 'Instagram';
    $contactmethods['linkedin'] = 'Linkedin';

    return $contactmethods;
}
add_filter('user_contactmethods','admin_social_media_icons',10,1);
?>
<?php require (get_template_directory().'/cpt-pages/testimonials.php');?>
<?php require (get_template_directory().'/cpt-pages/services.php');?>
<?php require (get_template_directory().'/cpt-pages/portfolio.php');?>
<?php require (get_template_directory().'/cpt-pages/team.php');?>
<?php require (get_template_directory().'/cpt-pages/clients.php');?>
<?php require (get_template_directory().'/cpt-pages/banner.php');?>
<?php require (get_template_directory().'/cpt-pages/pricecpt.php');?>
