<?php 
get_header(); 
?>
<h6>page.php</h6>
  <main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
    <?php
	//$query = new WP_Query( array( 'post_type' => 'page','post_status'=>'publish'));
   if( have_posts() ) { 
    while (have_posts() ) { 
      the_post();
			?>		
    <section class="inner-page">
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <?php the_content(); ?>
      <!-- <div class="col-sm-4"> -->
      <?php //get_search_form();?>
      <!-- </div> -->
    </section>
	<?php
		}
	}
	?>
  </main><!-- End #main -->

<?php 
get_footer(); 
?>