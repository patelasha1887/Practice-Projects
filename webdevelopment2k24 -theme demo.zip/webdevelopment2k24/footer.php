
  <!-- ======= Footer ======= -->
<footer id="footer" class="footer">
  <div class="footer-top">
    <div class="container-fluid " style="background-image: url('<?php echo esc_url( get_theme_mod( 'customizer_footer_setting' ) ); ?>'); width:100%">
      <div class="row gy-3 footer-row1">
        <div class="col-lg-6 footer-info">
          <?php 
              $custom_logo_id = get_theme_mod( 'custom_logo' );
              $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
              ?> 
              <img src="<?php echo $image[0]; ?>" alt="" >
        <?php if(is_active_sidebar('ct-sidebar-id')){
        dynamic_sidebar('ct-sidebar-id');
        }
      ?>
      <div class="social-links">
        <?php dynamic_sidebar('ct-sidebar-sociallink'); ?>
      </div>
    </div>
      </div>
      <div class="row gy-4 footer-row2">
        <div class="col-md-4 footer-links"> 
          <?php if(is_active_sidebar('ct-sidebar-id2')){
        dynamic_sidebar('ct-sidebar-id2');
        }
      ?>
        </div>
        <div class="col-md-4 footer-links"> 
          <?php if(is_active_sidebar('ct-sidebar-id3')){
        dynamic_sidebar('ct-sidebar-id3');
        }
      ?>
        </div>
        <div class="col-md-4 footer-contact"> 
          <?php if(is_active_sidebar('ct-sidebar-id4')){
        dynamic_sidebar('ct-sidebar-id4');
        }
      ?>
        </div>
      </div>    
    </div>
  </div>
    <div class="container">
      <div class="copyright">
        &copy;<strong><span><?php echo get_option('footer_txtbox');?></span></strong>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/flexstart-bootstrap-startup-template/ -->
        <?php $pagelink= get_option('footer_page_dropdown');?>
        Designed by <a href="<?php echo get_the_permalink($pagelink); ?>">
          <?php echo get_option('footer_link');?></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<?php wp_footer(); ?>
</body>

</html>