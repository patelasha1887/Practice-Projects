<?php 
get_header(); 
?>
<main id="main">

<!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
    <h2>single-team.php</h2>
    <!-- ======= Blog Single Section ======= -->
    <section id="team" class="team">

      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <h2>Team</h2>
          <p>Our hard working team</p>
        </header>
        <div class="row gy-4">
          <?php
            //$dbquery= new wp_query(array('post_type'=>'team','post_status'=>'publish'));?>
          <?php 
            if(have_posts()){
              while (have_posts()) {
                the_post();
              ?>
          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <?php the_post_thumbnail('small-image'); ?>
                <div class="social">
                  <a href="<?php the_field('twitter'); ?>"><i class="bi bi-twitter"></i></a>
                  <a href="<?php the_field('facebook'); ?>"><i class="bi bi-facebook"></i></a>
                  <a href="<?php the_field('instagram'); ?>"><i class="bi bi-instagram"></i></a>
                  <a href="<?php the_field('linkedin'); ?>"><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
                <span><?php the_field('designation'); ?></span>
                <p><?php the_content(); ?></p>
              </div>
            </div>
          </div>
          <?php
               }
            }
          ?>
        </div>
      </div>

    </section><!-- End Team Section -->
  </main><!-- End #main -->
<?php 
get_footer(); 
?>