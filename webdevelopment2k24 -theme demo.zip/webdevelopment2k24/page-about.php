<?php 
get_header(); 
?>
  <h6>about-page.php</h6>
  <main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
    <section id="about" class="about">

      <div class="container" data-aos="fade-up">
        <div class="row gx-0">
          <?php
  if(have_posts()){
    while (have_posts()) {
      // code...
      the_post();
      ?>
          <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="200">
            <div class="content">
              <h2><?php the_title(); ?></h2>
              <p>
                <?php the_content(); ?>
              </p>
            </div>
          </div>

          <div class="col-lg-6 d-flex align-items-center" data-aos="zoom-out" data-aos-delay="200" >
            <p><?php the_post_thumbnail('about-image'); ?></p>
          </div>
          <?php
    }
  }
  ?>
        </div>
      </div>

    </section><!-- End About Section -->
    		
	
  </main><!-- End #main -->
  


<?php 
get_footer(); 
?>