<?php 
get_header(); 
?>
<h6>404.php</h6>
  <main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<section class="inner-page">
<div class="container">
      <div class="row">
      <div class="alert alert-danger">
      
<h4>Page Not Found</h4>
</div>
</section>
get_footer(); 