<?php get_header(); ?>

<!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php single_post_title(); ?></li>
        </ol>
        <h2><?php single_post_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->  
<?php
  $dbquery= new wp_query(array('post_type'=>'post','post_status'=>'publish'));
?>
<!-- ends -->
<h2>archive.php</h2>
<?php 
	if(is_author()){
		echo "author archive";
	}elseif (is_category()) {
		echo "category archive";
	}elseif (is_day()) {
		echo "day archive";
	}elseif (is_month()) {
		echo "month archive";
	}elseif (is_year()) {
		echo "year archive";
	}
?>
    <!-- ======= Recent Blog Posts Section ======= -->
    <section id="recent-blog-posts" class="recent-blog-posts">

      <div class="container" data-aos="fade-up">

        <header class="section-header">
          <p>Recent posts form our Blog</p>
        </header>

        <div class="row">
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
                get_template_part("template-parts/content",get_post_format());
                
              }
            }
          ?>
        </div>
      </div>

    </section><!-- End Recent Blog Posts Section -->

   
  </main><!-- End #main -->
<?php get_footer(); ?>
