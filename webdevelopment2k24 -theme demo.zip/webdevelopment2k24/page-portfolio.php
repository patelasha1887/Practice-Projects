<?php 
get_header();
the_post();
?>
<h6>page-portfolio.php</h6>
  <main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">

      <div class="container" data-aos="fade-up">
        <header class="section-header">          
          <h2>Portfolio</h2>
          <p>Check our latest work</p>
        </header>
        <div class="row" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <?php
                  $terms = get_terms('portfolio_categories');
                  foreach ($terms as $term) {?>
                    <li data-filter=".<?php echo $term->slug;?>"><?php echo $term->name;?></li>
               <?php   }
              ?>
              <!-- <li data-filter=".filter-app">App</li>
              <li data-filter=".filter-card">Card</li>
              <li data-filter=".filter-web">Web</li> -->
            </ul>
          </div>
        </div>

        <div class="row gy-4 portfolio-container" data-aos="fade-up" data-aos-delay="200">
          <?php
            $args=array(
              'post_type' => 'portfolio',
              'posts_per_page' => 8,
              'post_status' => 'publish'
            );
            $query=new wp_query($args);
            while($query->have_posts()){
              $query->the_post();
              $termsArray = get_the_terms($post->ID,'portfolio_categories');
              $termsSlug = "";
              foreach ($termsArray as $term) {
                $termsSlug.=$term->slug.'';
              }
               ?>
          <div class="col-lg-4 col-md-6 portfolio-item <?php echo $termsSlug;?>">
            <div class="portfolio-wrap">
              <img src="<?php the_post_thumbnail_url();?>" class="img-fluid" alt="">
              <div class="portfolio-info">
                <h4><?php echo get_the_title();?></h4>
                <p><?php echo $termsSlug;?>
              </p>
                <div class="portfolio-links">
                  <a href="<?php the_post_thumbnail_url();?>" data-gallery="portfolioGallery" class="portfokio-lightbox" title="App 1"><i class="bi bi-plus"></i></a>
                  <a href="<?php echo get_post_meta(get_the_ID(),'ct_portfolio_url_key',true); ?>" title="More Details"><i class="bi bi-link"></i></a>
                </div>
              </div>
            </div>
          </div>
          <?php    
            }
          ?>
        </div>

      </div>

    </section><!-- End Portfolio Section -->
</main>

<?php
get_footer();
?>