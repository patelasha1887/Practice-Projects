<?php 
get_header();
the_post();
?>
<h6>page-service.php</h6>
  <main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <p>Services</p>
        </header>       
        <div class="row gy-4">
          <?php
            $dbquery= new wp_query(array('post_type'=>'services','post_status'=>'publish'));?>
          <?php 
            if($dbquery->have_posts()){
              while ($dbquery->have_posts()) {
                $dbquery->the_post();
              ?>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="service-box blue">
              <i class="ri-discuss-line icon"></i>
              <h3><?php the_title(); ?></h3>
              <p><?php echo get_the_excerpt(); ?></p>
              <a href="<?php the_permalink(); ?>" class="read-more"><span>Read More</span> <i class="bi bi-arrow-right"></i></a>
            </div>
          </div>
          <?php
               }
            }
          ?>
        </div>
      </div>
    </section><!-- End Services Section -->
</main>

<?php
get_footer();
?>