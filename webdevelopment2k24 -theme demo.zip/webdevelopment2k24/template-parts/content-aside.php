<!-- <h6>content-aside.php</h6> -->
<div class="col-lg-4">
  <div class="post-box">
    <div class="post-img">
        <h6>post-format=>aside</h6>
        <?php 
            if(has_post_thumbnail()){
              the_post_thumbnail('small-image');
            }
            else{ 
        ?>
              <img src="<?php echo get_template_directory_uri()."/assets/img/no-img.jpg";?>" >
              <?php    
                }
              ?>
    </div>
    <span class="post-date"><?php the_time('F j,Y g:i a'); ?> |
      <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>" ><?php the_author(); ?></a> |<?php 
      $categories= get_the_category();//get post category specific category
      $separator = ",";
      $catoptions= '';
      foreach($categories as $cat){
      $catoptions .= "<a href='".get_category_link($cat->term_id)."'/>".$cat->cat_name."</a>".$separator;           
      }
      echo trim($catoptions,$separator);
      ?>
      <!-- <p>post-format=>aside</p> -->
    </span>
    <h3 class="post-title"><?php the_title(); ?></h3>
    <a href="<?php the_permalink(); ?>" class="readmore stretched-link mt-auto"><span>Read More</span><i class="bi bi-arrow-right"></i></a>
  </div>
</div>