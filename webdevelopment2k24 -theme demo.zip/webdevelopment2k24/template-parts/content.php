<!-- <h2>content.php</h2> -->
<div class="col-lg-4">
  <div class="post-box">
    <div class="post-img">
        <p> <?php the_post_thumbnail('small-image'); ?></p>
    </div>
    <span class="post-date"><?php the_time('F j,Y g:i a'); ?> |
      <a href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>" ><?php the_author(); ?></a> |<?php $categories = get_the_category(); if ( ! empty( $categories ) ) { echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>'; } ?>
    </span>
    <a href="<?php the_permalink(); ?>"><h3 class="post-title"><?php the_title(); ?></h3></a>
    <a href="<?php the_permalink(); ?>" class="readmore stretched-link mt-auto"><span>Read More</span><i class="bi bi-arrow-right"></i></a>
  </div>
</div>