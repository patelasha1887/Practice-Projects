            <div class="sidebar">              
            	<h2>sidebar.php</h2>
            	<?php if(is_active_sidebar('blog-sidebar')) {?>
              <!-- <h3 class="sidebar-title">Search</h3> -->
              <div class="sidebar-item">
                <?php dynamic_sidebar('blog-sidebar');?> 
                
              </div><!-- End sidebar search formn-->
              <?php }?>
              <div class="sidebar-item">
              	<h3>Image from Customizer Panel</h3>
              	<img src="<?php echo get_option('custom_theme_panel_img_upload'); ?>" height="150px" width="150px" />
              </div>
               <div>
      <?php get_search_form();?>
      </div>
              

            </div><!-- End sidebar -->