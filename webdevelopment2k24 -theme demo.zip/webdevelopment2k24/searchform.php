<form method="get" action="<?php echo home_url('/');?>" >
          <input type="text" name="s" style="width:50%" class="form-control" placeholder="Enter text">
          <button type="submit"><i class="bi bi-search"></i></button>
</form>
