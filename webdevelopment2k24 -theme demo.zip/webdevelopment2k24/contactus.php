<?php get_header(); 
/* Template Name: Contact Us */
?>
<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="<?php echo get_home_url(); ?>">Home</a></li>
          <li><?php the_title(); ?></li>
        </ol>
        <h2><?php the_title(); ?></h2>
      </div>
    </section><!-- End Breadcrumbs -->
<section id="contact" class="contact">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <p>Get In Touch</p>
        </header>
        <div class="row gy-4">
          <div class="col-lg-6">
            <div class="row gy-4">
              <div class="col-md-6">
                <div class="info-box">
                  <?php
                    if( have_rows('address_group') ){
                      while( have_rows('address_group') ){ 
                        the_row();?>
                  <i class="<?php echo get_sub_field('address_icon'); ?>"></i>
                  <h3><?php echo get_sub_field('address_title'); ?></h3>
                  <p><?php echo get_sub_field('address_des'); ?></p>
                  <?php    
                        }
                    }

                  ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box">
                  <?php
                    if( have_rows('phone_group') ){
                      while( have_rows('phone_group') ){ 
                        the_row();?>
                  <i class="<?php echo get_sub_field('phone_icon'); ?>"></i>
                  <h3><?php echo get_sub_field('phone_title'); ?></h3>
                  <p><?php echo get_sub_field('phone_des'); ?></p>
                  <?php    
                        }
                    }

                  ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box">
                  <?php
                    if( have_rows('email_group') ){
                      while( have_rows('email_group') ){ 
                        the_row();?>
                  <i class="<?php echo get_sub_field('email_icon'); ?>"></i>
                  <h3><?php echo get_sub_field('email_title'); ?></h3>
                  <p><?php echo get_sub_field('email_des'); ?></p>
                  <?php    
                        }
                    }

                  ?>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box">
                  <?php
                    if( have_rows('time_group') ){
                      while( have_rows('time_group') ){ 
                        the_row();?>
                  <i class="<?php echo get_sub_field('time_icon'); ?>"></i>
                  <h3><?php echo get_sub_field('time_title'); ?></h3>
                  <p><?php echo get_sub_field('time_des'); ?></p>
                  <?php    
                        }
                    }
                  ?>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <?php echo do_shortcode( '[my_cf_form]' ); ?>
          </div>
        </div>
      </div>
    </section><!-- End Contact Section -->
</main>
<?php get_footer(); ?>