-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2024 at 06:21 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `selfprojectdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `catname` varchar(191) NOT NULL,
  `catdescription` mediumtext NOT NULL,
  `chktrending` tinyint(4) NOT NULL DEFAULT 0,
  `chkstatus` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `catname`, `catdescription`, `chktrending`, `chkstatus`, `created_at`) VALUES
(2, 'marraige gift88888', 'marraige gift description4444    ', 1, 1, '2023-06-17 06:07:55'),
(3, 'Anniversary Gift', ' Birthday Gift new Description', 1, 0, '2023-06-17 06:10:12'),
(4, 'Appriciation Gift', ' marraige gift new Description', 1, 1, '2023-06-17 06:11:30'),
(5, 'Birthday Gift old', 'Birthday Gift old   Description', 1, 1, '2023-06-17 06:12:45'),
(6, 'wedding gift', ' Birthday Gift123 Description 123', 1, 0, '2023-06-17 06:14:33');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` varchar(198) NOT NULL,
  `name` varchar(198) NOT NULL,
  `small_description` varchar(198) NOT NULL,
  `long_description` varchar(198) NOT NULL,
  `price` int(60) NOT NULL,
  `offer_price` int(60) NOT NULL,
  `tax` int(60) NOT NULL,
  `quantity` int(60) NOT NULL,
  `image` varchar(198) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `name`, `small_description`, `long_description`, `price`, `offer_price`, `tax`, `quantity`, `image`, `status`, `created_at`) VALUES
(1, 'marraige gift', 'Ring', 'aaa																																																						', 'ddddd', 500, 400, 10, 3, '1688404252.png', 1, '2023-07-01 05:36:53'),
(2, 'marraige gift', 'Watch', 'small decription of productsssss																											', 'long decription of productsssss long decription of productsssss long decription of productssssslong decription of productssssslong decription of productsssss', 299, 250, 40, 1, '1688404332.png  ', 1, '2023-07-01 05:38:49'),
(3, 'Birthday Gift', 'Watch', 'small decription of productsssss									', 'long decription of productsssss long decription of productsssss long decription of productssssslong decription of productssssslong decription of productsssss', 299, 250, 40, 1, '0 ', 0, '2023-07-01 05:39:07'),
(4, 'Anniversary Gift', 'Mobile M31', 'aasasas									', 'ssdsd\r\nds\r\nd', 15000, 10000, 10, 20, '1688320742jpg ', 1, '2023-07-02 17:59:02'),
(5, 'Appriciation Gift', 'Iphone', 'dsdsd																											', 'hhghghghghghg\r\nghghghgh', 120000, 50000, 15, 30, '', 0, '2023-07-02 18:02:34'),
(6, 'Birthday Gift', 'MAC book', 'sdsdsd									', 'fffffffffff\r\ngggggggg\r\nhhhhhh', 500000, 100000, 20, 1, '', 0, '2023-07-02 18:07:00'),
(7, 'wedding gift', 'MAC book', 'dsdsdsd									', 'jjjjjjjjjjjjjj\r\nkkkkkkkkkkk', 500000, 100000, 5, 3, '', 0, '2023-07-02 18:10:02'),
(8, 'Birthday Gift old', 'Purse', 'sdsdsds									', 'OOOOOOOOO\r\nPPPPPPP', 250, 200, 3, 50, '', 0, '2023-07-02 18:12:12'),
(9, 'marraige gift', 'Nackless', 'aaaaa									', 'dddddd\r\nhhhhhh', 500, 400, 5, 60, '', 1, '2023-07-02 18:15:53'),
(10, 'Birthday Gift', 'clothes', 'aaa									', 'adadada\r\nsssss', 600, 500, 20, 3, '', 0, '2023-07-03 15:55:31'),
(11, 'Appriciation Gift', 'Iphone', 'iphone 15 pro max', 'ssadsddadad', 1000000, 50000, 8, 1, '1712721057.jpg', 1, '2024-04-10 03:50:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `password` varchar(191) NOT NULL,
  `role_as` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `role_as`, `created_at`) VALUES
(4, 'admin', 'admin@gmail.com', '12345879', 'admin@123', 1, '2023-06-24 16:15:11'),
(6, 'vijay', 'v@gmail.com', '123456666', 'v123', 0, '2023-06-24 16:15:11'),
(7, 'admin2', 'a@gmail.com', '1326556556', 'a1233', 0, '2023-06-24 16:15:11'),
(9, 'asha', 'asha@gmail.com', '1234566666', 'asha@123', 0, '2023-06-24 16:15:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
